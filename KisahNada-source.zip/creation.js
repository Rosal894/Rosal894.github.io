/* A focused creation workspace; all results come from the user's real Library. */
let studioSearch = "", studioLiked = false, preparingStoryLyrics = false;
const creatorPreviousRender = render;
render = function () {
  creatorPreviousRender();
  bindCreationWorkspace();
};

function creationResults() {
  const songs = projects.filter(p => p.type !== "video");
  const filtered = songs.filter(p => (!studioLiked || p.liked) && `${p.title} ${p.genre} ${p.lyrics || ""}`.toLowerCase().includes(studioSearch.toLowerCase()));
  return `<section class="creation-results" aria-label="Hasil lagu"><div class="results-heading"><div><span class="eyebrow">KOLEKSI PRIBADIMU</span><h2>Lagu terbarumu <span class="result-count">${songs.length}</span></h2></div><button class="text-btn" id="studio-library">Library ↗</button></div><div class="results-toolbar"><div class="result-tabs"><button data-studio-filter="all" class="${!studioLiked ? "active" : ""}" aria-pressed="${!studioLiked}">Semua</button><button data-studio-filter="liked" class="${studioLiked ? "active" : ""}" aria-pressed="${studioLiked}">♡ Disukai</button></div><input id="studio-search" type="search" placeholder="Cari lagumu…" aria-label="Cari lagu pribadi" value="${esc(studioSearch)}"></div>${filtered.length ? `<div class="studio-song-list">${filtered.slice(0, 12).map(p => {
    const label = p.type === "demo" ? "Demo instrumental" : p.type === "spoken" ? "Narasi sintetis" : p.origin === "local-singing-ai" ? "Nyanyian ACE-Step" : p.type === "audio-tool" ? "Audio diproses" : "Audio tersimpan";
    return `<article class="studio-song"><img src="assets/cover-${Number.isInteger(p.art) && p.art >= 0 && p.art < 6 ? p.art : 0}.svg" alt="Sampul ${esc(p.title)}"><div class="studio-song-info"><h3>${esc(p.title)}</h3><p>${esc(p.genre || "Musik pribadi")} · ${label}</p><small>${new Date(p.created).toLocaleDateString("id-ID")}</small></div><div class="studio-song-actions"><button data-play="${esc(p.id)}" aria-label="Putar ${esc(p.title)}">▶</button><button data-like="${esc(p.id)}" aria-label="Sukai ${esc(p.title)}" aria-pressed="${!!p.liked}">${p.liked ? "♥" : "♡"}</button><button data-download="${esc(p.id)}" aria-label="Unduh ${esc(p.title)}">↓</button></div></article>`;
  }).join("")}</div>` : songs.length ? '<div class="studio-empty compact"><span>⌕</span><h3>Belum ada yang cocok.</h3><p>Coba kata lain atau filter Semua.</p></div>' : `<div class="studio-empty"><div class="empty-record" aria-hidden="true"><i></i><span>k♪</span></div><h3>Lagu pertamamu dimulai di sini.</h3><p>Satu cerita kecil bisa menjadi lagu yang ingin kamu putar lagi.</p><div class="empty-wave" aria-hidden="true">${[12, 22, 37, 21, 45, 29, 54, 35, 18, 41, 27, 49, 24, 38, 15, 26, 12].map(h => `<i style="height:${h}px"></i>`).join("")}</div><span class="muted">Hasil yang kamu buat akan muncul di sini.</span></div>`}<div class="creation-readiness"><div><span class="readiness-dot ${caps.localSinging ? "ready" : ""}"></span><b>${caps.localSinging ? "Model nyanyian terpasang" : "Siapkan mesin nyanyianmu"}</b></div><p>${caps.localSinging ? "Mulai dengan lagu 30 detik. Dengarkan hasil untuk menilai vokal dan lirik." : "Pasang model ACE-Step sekali untuk mencoba lagu bernyanyi di komputer ini."}</p><button class="chip" id="studio-model-setup">${caps.desktopModelSetup ? "↓ Pasang / periksa model" : "Lihat status AI"}</button></div></section>`;
}

renderSong = function () {
  const currentStep = draft.mode === "lyrics" ? 2 : 1;
  return `<section class="creator-intro"><div><div class="eyebrow">KISAHNADA · CREATE STUDIO</div><h1>Ceritamu punya <em>nadanya sendiri.</em></h1><p>Dari ide pertama sampai lagu yang ingin kamu simpan.</p></div><div class="creator-badge"><span>✦</span> Ruang berkaryamu</div></section><div class="creation-workspace"><section class="editor creator-editor"><div class="creator-card-heading"><div class="creator-mark">♫</div><div><h2>Buat lagu baru</h2><p>Mulai dari cerita, lirik, atau momenmu.</p></div></div><div class="editor-tabs" role="tablist" aria-label="Sumber lagu">${[["description", "✎", "Cerita"], ["lyrics", "≡", "Lirik"], ["image", "▧", "Foto & video"], ["remix", "≋", "Remix"]].map(([id, icon, name]) => `<button class="tab ${draft.mode === id ? "active" : ""}" role="tab" aria-selected="${draft.mode === id}" data-mode="${id}"><span>${icon}</span>${name}</button>`).join("")}</div><div class="editor-body"><div class="creator-steps" aria-label="Tahap membuat lagu"><span class="${currentStep === 1 ? "current" : "done"}"><i>1</i> Ide</span><b>—</b><span class="${currentStep === 2 ? "current" : ""}"><i>2</i> Lirik</span><b>—</b><span><i>3</i> Lagu</span></div>${songBody()}${creationFooter()}</div></section>${creationResults()}</div><section class="creator-ideas"><div class="section-heading"><h2>Mulai dari satu suasana.</h2><span class="muted">Ide untuk kamu ubah sesukamu</span></div><div class="idea-grid">${[["♡", "Cerita tentang kita", "Pop · hangat · romantis", 0], ["↗", "Langkah yang baru", "Rock · berani · penuh semangat", 1], ["⌂", "Rindu untuk pulang", "Folk · akustik · nostalgia", 2]].map(([icon, title, desc, i]) => `<button class="idea-card" data-creator-idea="${i}"><span>${icon}</span><div><b>${title}</b><small>${desc}</small></div><i>↗</i></button>`).join("")}</div></section>`;
};

function bindCreationWorkspace() {
  if (state.page !== "song") return;
  if ($('.duration-field label')) $('.duration-field label').textContent = "Durasi lagu";
  if ($('label[for="song-title"]')) $('label[for="song-title"]').innerHTML = 'Judul lagu <small>(opsional)</small>';
  on("#studio-library", "click", () => go("library"));
  on("#studio-model-setup", "click", () => caps.desktopModelSetup ? desktopSongSetup() : freeSettings());
  on("#studio-search", "input", event => {
    const cursor = event.target.selectionStart;
    studioSearch = event.target.value;
    render();
    $("#studio-search").focus();
    try { $("#studio-search").setSelectionRange(cursor, cursor); } catch {}
  });
  all("[data-studio-filter]", button => button.onclick = () => { studioLiked = button.dataset.studioFilter === "liked"; render(); });
  all("[data-creator-idea]", button => button.onclick = () => {
    const i = Number(button.dataset.creatorIdea);
    draft.story = prompts[i];
    draft.genre = ["Pop", "Rock", "Folk"][i];
    draft.tags = [["Love"], ["Encourage"], ["Bittersweet"]][i];
    draft.mode = "description";
    persist();
    render();
    $("#story").focus();
  });
  if (caps.freeOnly !== false && draft.mode === "description") {
    const button = $("#create-song");
    button.textContent = draft.vocal === "Instrumental" ? "✦ Buat musik instrumental AI" : "✦ Lanjutkan cerita menjadi lagu";
    button.onclick = () => draft.vocal === "Instrumental" ? createLocalSinging() : createStorySong();
    if ($(".create-note") && caps.localSinging)
      $(".create-note").textContent = "Tinjau lirik dahulu, lalu lanjutkan menjadi lagu bernyanyi.";
  }
}

function reviewStoryLyrics(result, snapshot, allowRewrite = false) {
  const isAI = result.origin === "groq" || result.origin === "local-ai";
  modal("Sebelum jadi lagu, buat kata-katanya terasa milikmu.", `<p class="muted">${isAI ? "Draf dibuat dengan AI. Periksa fakta dan ubah kata yang kamu inginkan." : "Ini lirik yang sudah kamu tulis atau pilih. Kamu bisa menyuntingnya sebelum dinyanyikan."}</p><label class="field-label" for="story-lyric-review">Lirik lagu <small>maksimal 4.096 karakter</small></label><textarea class="text-input lyric-review" id="story-lyric-review" maxlength="4096" rows="12">${esc(result.lyrics)}</textarea><div id="story-lyric-error" class="error" role="alert"></div>`, `<button class="primary full" id="accept-story-song">♫ Gunakan lirik & buat lagu</button>${allowRewrite ? '<button class="chip" id="rewrite-story-lyrics" style="margin-top:12px">✧ Buat lirik baru dari cerita</button>' : ""}`);
  $("#accept-story-song").onclick = () => {
    const lyrics = $("#story-lyric-review").value.trim();
    if (!lyrics || lyrics.length > 4096) return $("#story-lyric-error").textContent = "Masukkan lirik 1–4.096 karakter.";
    if (draft.story !== snapshot.story) return $("#story-lyric-error").textContent = "Ceritamu berubah saat lirik disiapkan. Tutup dan mulai lagi agar tetap sesuai.";
    draft.lyrics = lyrics;
    draft.mode = "lyrics";
    persist();
    $("#modal").close();
    go("song");
    createLocalSinging();
  };
  on("#rewrite-story-lyrics", "click", () => { $("#modal").close(); createStorySong(true); });
}

async function createStorySong(rewrite = false) {
  if (preparingStoryLyrics) return;
  if (!caps.localSinging) return toast("Pasang model nyanyian terlebih dahulu.");
  if (draft.vocal === "My Voice") return toast("Kloning suara belum didukung. Pilih Male, Female, atau Random.");
  if (!draft.story.trim()) return generationError("Ceritakan ide lagumu terlebih dahulu.");
  const snapshot = {story: draft.story, style: draft.style, tags: [...draft.tags], lyrics: "", title: draft.title};
  if (draft.lyrics.trim() && !rewrite) return reviewStoryLyrics({lyrics: draft.lyrics, origin: "existing"}, snapshot, true);
  const kind = caps.groqLyrics ? "groq-lyrics" : caps.localLyrics ? "free-lyrics" : null;
  if (!kind) {
    modal("Pilih cara menyiapkan lirik.", '<p class="muted">Lirik AI belum terhubung. Kamu bisa menulis sendiri atau memulai dari draf template berbasis aturan.</p>', '<button class="primary full" id="write-story-lyrics">Tulis lirik sendiri</button><button class="chip" id="template-story-lyrics" style="margin-top:12px">Buat draf template · bukan AI</button>');
    $("#write-story-lyrics").onclick = () => { $("#modal").close(); go("song", "lyrics"); };
    $("#template-story-lyrics").onclick = () => { $("#modal").close(); freeLyricAction(false); };
    return;
  }
  const button = $("#create-song");
  preparingStoryLyrics = true;
  button.disabled = true;
  const body = new FormData();
  body.append("spec", JSON.stringify(snapshot));
  try {
    const result = await startServerJob(kind, body, text => { if (button.isConnected) button.textContent = text; });
    reviewStoryLyrics(result, snapshot);
  } catch (error) { generationError(error.message); toast(error.message); }
  finally {
    preparingStoryLyrics = false;
    if (button.isConnected) { button.disabled = !caps.localSinging; button.textContent = "✦ Lanjutkan cerita menjadi lagu"; }
  }
}

if ($("#app").children.length) render();
