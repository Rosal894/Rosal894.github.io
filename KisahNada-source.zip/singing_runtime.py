"""Compatibility contract for the pinned ACE-Step CPU worker."""
import json
import os
from pathlib import Path
import subprocess

SOURCE_COMMIT = "ca1e85fe9430179831e6bc6be790c332190a3866"
SOURCE_SHA256 = "b464c11f00af00e1e089a09f58a03962f803c080f116fd0517dbe5ec839706b3"
WORKER_PYTHON = (3, 12)  # Upstream requires >=3.11,<3.13.


def require_worker_python(executable):
    result = subprocess.run(
        [str(executable), "-c", "import json,sys; print(json.dumps(list(sys.version_info[:2])))"],
        check=True, capture_output=True, text=True, timeout=30,
        **({"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}),
    )
    version = json.loads(result.stdout)
    if version != list(WORKER_PYTHON):
        raise RuntimeError("Runtime nyanyian memerlukan Python 3.12 yang disertakan pada installer terbaru. Runtime utama aplikasi tidak digunakan untuk ACE-Step.")
    return version


def runtime_marker_valid(path):
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
        return (
            value.get("protocol") == 1
            and value.get("python") == list(WORKER_PYTHON)
            and value.get("source_commit") == SOURCE_COMMIT
            and value.get("source_sha256") == SOURCE_SHA256
            and value.get("cpu_imports_verified") is True
        )
    except (OSError, ValueError, TypeError, AttributeError):
        return False
