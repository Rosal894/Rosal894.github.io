/* Last-version free-first studio. Synthetic speech is never labelled AI singing. */
let freeVoices = [],
  freeVoicesLoaded = false,
  freeVoiceSearch = "",
  freeVoiceLanguage = "id",
  freePreviewURL = null;
const previousFreeRender = render;
render = function () {
  previousFreeRender();
  enhanceFree();
};
const previousCoverView = renderCover;
renderCover = function () {
  if (caps.freeOnly === false) return previousCoverView();
  const languages = [...new Set(freeVoices.map((v) => v.language))],
    filtered = freeVoices.filter(
      (v) =>
        (!freeVoiceLanguage || v.language === freeVoiceLanguage) &&
        `${v.name} ${v.language}`
          .toLowerCase()
          .includes(freeVoiceSearch.toLowerCase()),
    );
  return `${intro("FREE VOICE STUDIO", "More voices. <em>No API bill.</em>", "Pilih profil sintetis terpasang, dengarkan, lalu gunakan untuk narasi bermusik.")}<div class="notice">Suara eSpeak-NG ini mekanis, bukan penyanyi asli, kloning, atau nyanyian AI. Setiap suara dasar memiliki lima variasi karakter. Pelafalan dan aksen bergantung bahasa profil.</div><div class="voice-toolbar"><input class="text-input" id="free-voice-search" type="search" placeholder="Cari bahasa atau karakter…" value="${esc(freeVoiceSearch)}"><select class="text-input" id="free-language"><option value="">Semua bahasa</option>${languages.map((l) => `<option value="${esc(l)}" ${l === freeVoiceLanguage ? "selected" : ""}>${esc(languageName(l))} · ${esc(l)}</option>`).join("")}</select></div><div class="section-heading"><h2>${freeVoicesLoaded ? filtered.length + " profil suara" : "Memuat katalog…"}</h2><span class="tag">${freeVoices.length} PROFIL TERPASANG</span></div><label class="field-label" for="voice-preview-text">Kalimat preview</label><input id="voice-preview-text" class="text-input" maxlength="200" value="${esc(draft.previewText || "Dalam nada, cerita kita akan selalu ada.")}" style="margin-bottom:18px"><div class="voice-grid free-voice-grid">${filtered
    .slice(0, 40)
    .map(
      (v, i) =>
        `<article class="voice-tile ${draft.freeVoice === v.id ? "selected" : ""}"><span class="face">${["🌿", "☀️", "🌸", "🌙", "🍃"][i % 5]}</span><b>${esc(v.name)}</b><small>${esc(languageName(v.language))} · suara sintetis</small><div class="chip-row"><button class="chip" data-free-preview="${esc(v.id)}" aria-label="Preview ${esc(v.name)}">▶ Preview</button><button class="chip ${draft.freeVoice === v.id ? "selected" : ""}" data-free-voice="${esc(v.id)}">${draft.freeVoice === v.id ? "✓ Dipilih" : "Pilih"}</button></div></article>`,
    )
    .join(
      "",
    )}</div>${filtered.length > 40 ? '<p class="muted">Menampilkan 40 profil pertama. Pilih bahasa atau gunakan pencarian.</p>' : ""}${freeVoicesLoaded && !freeVoices.length ? '<div class="notice">Mesin suara belum aktif. Jalankan server dengan virtual environment gratis yang disiapkan.</div>' : ""}<section class="editor"><div class="editor-body"><label class="field-label" for="free-spoken-lyrics">Teks narasi / lirik</label><textarea class="text-input" id="free-spoken-lyrics" rows="6" maxlength="5000" placeholder="Tuliskan kata yang ingin diberi suara…">${esc(draft.lyrics || draft.story)}</textarea><p class="muted">Keluaran berupa spoken-word/narasi dengan musik, bukan lirik yang dinyanyikan.</p><button class="primary full" id="free-spoken-create">♫ Buat narasi bermusik · gratis</button><div class="error" id="free-error" role="alert"></div></div></section>`;
};
function languageName(code) {
  try {
    return new Intl.DisplayNames(["id"], { type: "language" }).of(code) || code;
  } catch {
    return code;
  }
}
async function loadFreeVoices() {
  try {
    const r = await fetch("/api/free/voices");
    if (!r.ok) throw Error();
    freeVoices = (await r.json()).voices || [];
    if (!draft.freeVoice)
      draft.freeVoice =
        freeVoices.find((v) => v.language === "id" && v.style === "Natural")
          ?.id || freeVoices[0]?.id;
  } catch {
    freeVoices = [];
  } finally {
    freeVoicesLoaded = true;
    if (state.page === "cover") render();
    else enhanceFree();
  }
}
async function previewVoice(id) {
  const text =
    $("#voice-preview-text")?.value ||
    "Dalam nada, cerita kita akan selalu ada.";
  try {
    const blob = await (
      await serverFetch("/api/free/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, voiceId: id }),
      })
    ).blob();
    if (freePreviewURL) URL.revokeObjectURL(freePreviewURL);
    freePreviewURL = URL.createObjectURL(blob);
    modal(
      "Listen to a little possibility.",
      `<p class="muted">${esc(freeVoices.find((v) => v.id === id)?.name)} · sintetis, bukan penyanyi AI.</p><audio controls autoplay style="width:100%" src="${freePreviewURL}"></audio>`,
      '<button class="primary full" id="download-free-preview">Unduh preview WAV ↓</button>',
    );
    $("#download-free-preview").onclick = () =>
      download(blob, "kisahnada-voice-preview.wav");
    $("#modal").addEventListener("close", () => $("#modal audio")?.pause(), {
      once: true,
    });
  } catch (e) {
    toast(e.message);
  }
}
async function freeLyricAction(ai) {
  const useGroq = ai === "groq";
  if (!draft.story.trim() && !draft.lyrics.trim())
    return toast("Tuliskan cerita atau lirik awal.");
  const data = new FormData();
  data.append(
    "spec",
    JSON.stringify({
      story: draft.story,
      lyrics: draft.lyrics,
      style: draft.style,
      tags: draft.tags,
      title: draft.title,
    }),
  );
  try {
    const result = await startServerJob(
      useGroq ? "groq-lyrics" : ai ? "free-lyrics" : "template-lyrics",
      data,
    );
    modal(
      useGroq ? "Lirik dari Groq." : ai ? "Lirik dari model lokal." : "Draf awal untuk ceritamu.",
      `<div class="notice">${useGroq ? "Dibuat melalui Groq sesuai kuota akun. Tinjau fakta dan kata sebelum digunakan." : ai ? "Dibuat dengan model lokal. Tinjau fakta dan pilihan kata." : "Dibuat dengan aturan/template, bukan inferensi AI. Tinjau dan ubah agar personal."}</div><div class="result-lyrics">${esc(result.lyrics)}</div>`,
      '<button class="primary full" id="accept-free-lyrics">Gunakan lirik ini ↗</button>',
    );
    $("#accept-free-lyrics").onclick = () => {
      draft.lyrics = result.lyrics;
      draft.mode = "lyrics";
      persist();
      $("#modal").close();
      go("song");
    };
  } catch (e) {
    toast(e.message);
  }
}
async function desktopSongSetup() {
  if (!(await ensureAccount())) return;
  modal("Pasang mesin nyanyian AI.", '<div class="notice">ACE-Step membuat vokal bernyanyi dari lirik. Sekali pemasangan, aplikasi akan mengunduh runtime CPU dan model resmi berukuran banyak GB. Perlu internet, ruang disk, dan RAM memadai. Tidak ada API berbayar. Kecepatan/kualitas perangkat Anda perlu diuji.</div><p class="muted" id="song-setup-status" role="status">Memeriksa status…</p>', '<button class="primary full" id="song-setup-start">Unduh dan pasang model AI</button>');
  const button = $("#song-setup-start"), status = $("#song-setup-status");
  let watching = false;
  async function watch() {
    if (watching) return;
    watching = true;
    try {
      while ($("#song-setup-status") === status && $("#modal").open) {
        const info = await (await serverFetch("/api/desktop/song-setup")).json();
        status.textContent = info.message;
        button.disabled = info.state === "running" || info.state === "succeeded";
        button.textContent = info.state === "running" ? "Pemasangan berlangsung…" : info.state === "failed" ? "Coba lagi" : info.state === "succeeded" ? "Model terpasang" : "Unduh dan pasang model AI";
        if (info.state === "succeeded") {
          caps = await (await fetch("/api/capabilities")).json();
          render();
        }
        if (info.state === "succeeded") break;
        await new Promise(resolve => setTimeout(resolve, 1500));
      }
    } catch (error) { status.textContent = error.message; }
    finally { watching = false; }
  }
  button.onclick = async () => {
    button.disabled = true;
    try {
      await serverFetch("/api/desktop/song-setup", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({confirmDownload: true})});
      watch();
    } catch (error) { status.textContent = error.message; button.disabled = false; }
  };
  watch();
}
async function createSpokenSong() {
  const text = $("#free-spoken-lyrics")?.value || draft.lyrics || draft.story;
  if (!text.trim()) return toast("Tuliskan teks terlebih dahulu.");
  if (text.length > 5000) return toast("Narasi maksimal 5.000 karakter.");
  if (!draft.freeVoice) return toast("Pilih profil suara dahulu.");
  const button = $("#free-spoken-create");
  if (button) button.disabled = true;
  try {
    const genre = draft.genre === "Random" ? "Pop" : draft.genre,
      bed = await synthesize({ ...draft, genre }),
      data = new FormData();
    data.append(
      "spec",
      JSON.stringify({
        title: draft.title || "Cerita dalam nada",
        lyrics: text,
        story: draft.story,
        genre,
        tags: draft.tags,
        freeVoice: draft.freeVoice,
      }),
    );
    data.append("audio", bed, "instrumental.wav");
    const result = await startServerJob("spoken-song", data, (t) => {
      if (button?.isConnected) button.textContent = t;
    });
    await importServerProject(result.project);
    $("#modal").close();
    state.libraryType = "My Song";
    state.filter = "All";
    go("library");
    playProject(projects.find((p) => p.id === result.project.id));
    toast("Narasi bermusik selesai. Spoken-word sintetis, bukan nyanyian AI.");
  } catch (e) {
    if ($("#free-error")) $("#free-error").textContent = e.message;
    else toast(e.message);
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = "♫ Buat narasi bermusik · gratis";
    }
  }
}
async function createLocalSinging() {
  if (!caps.localSinging)
    return toast("Model nyanyian ACE-Step belum tersedia.");
  if (draft.vocal !== "Instrumental" && !draft.lyrics.trim())
    return toast("Masukkan lirik pada tab Lyrics.");
  if (draft.vocal === "My Voice")
    return toast("Kloning suara belum didukung model ini.");
  const button = $("#create-song");
  button.disabled = true;
  const body = new FormData();
  body.append(
    "spec",
    JSON.stringify({
      title: draft.title || "Lagu baruku",
      story: draft.story,
      lyrics: draft.lyrics,
      style: draft.style,
      genre: draft.genre,
      vocal: draft.vocal,
      tags: draft.tags,
      songSeconds: draft.songSeconds || 30,
    }),
  );
  try {
    const result = await startServerJob("free-song", body, (text) => {
      if (button.isConnected) button.textContent = text;
    });
    await importServerProject(result.project);
    state.libraryType = "My Song";
    state.filter = "All";
    go("library");
    playProject(projects.find((p) => p.id === result.project.id));
    toast(
      "Model menghasilkan audio. Dengarkan untuk memeriksa vokal dan kecocokan lirik.",
    );
  } catch (e) {
    generationError(e.message);
    toast(e.message);
  } finally {
    if (button.isConnected) {
      button.disabled = !caps.localSinging;
      button.textContent = "♫ Buat lagu bernyanyi AI";
    }
  }
}
function freeSettings() {
  modal(
    "Gratis, dengan batas yang jelas.",
    `<div class="eyebrow">LOCAL FIRST · GROQ OPSIONAL</div><div class="notice">Mode gratis ${caps.freeOnly === false ? "tidak dikunci" : "dikunci di server"}. Integrasi berbayar ${caps.freeOnly === false ? "mengikuti konfirmasi biaya" : "diblokir"}. Groq hanya diaktifkan setelah pemilik mengonfirmasi paket gratis akunnya.</div><p class="muted">✓ Instrumental lokal<br>✓ ${caps.voiceProfileCount || freeVoices.length} profil eSpeak-NG dalam ${caps.voiceLanguageCount || 0} bahasa; lima variasi per suara dasar<br>✓ Narasi sintetis + musik yang bisa diunduh<br>✓ Draf template (bukan AI)<br>✓ Slideshow, Glow Up, efek remix, Library dan cadangan</p><div class="notice">Groq untuk lirik: ${caps.groqLyrics ? "dikonfigurasi untuk paket gratis; perlu uji nyata" : caps.groqConfigured ? "menunggu konfirmasi paket gratis pemilik" : "API key belum diisi"}.<br>Lirik AI lokal: ${caps.localLyrics ? "runtime dan file terdeteksi; hasil tetap perlu diuji" : "bobot model belum terunduh"}.<br>Nyanyian ACE-Step: ${caps.localSinging ? "bobot terpasang; hasil dan kualitas perlu diuji" : "bobot belum terunduh/terverifikasi"}.</div><p class="muted">Suara artis, kloning suara, dan video generatif belum tersedia. Tanpa biaya API tidak menjamin perangkat atau hosting gratis selamanya.</p>`,
  );
}
function enhanceFree() {
  if (caps.freeOnly === false || !$("#app").children.length) return;
  $("#settings").onclick = freeSettings;
  all('[data-page="cover"]', (b) => {
    const icon = b.querySelector(".nav-icon");
    b.replaceChildren(icon, document.createTextNode("Voices"));
  });
  if (state.page === "cover") $("#breadcrumb").textContent = "Voices · gratis";
  if ($(".topbar .status"))
    $(".topbar .status").innerHTML = "<i></i> Free local studio";
  if (
    state.page === "song" &&
    ["description", "lyrics"].includes(draft.mode) &&
    !$("#free-creation")
  ) {
    const box = document.createElement("section");
    box.id = "free-creation";
    box.className = "free-creation";
    box.innerHTML = `<div class="field-label">✦ Bantu tulis lirik <small>lokal / paket gratis Groq</small></div><div class="chip-row"><button class="chip" id="groq-lyrics" ${caps.groqLyrics ? "" : "disabled"}>✧ Lirik AI · Groq ${caps.groqLyrics ? "· siap diuji" : "· belum terhubung"}</button><button class="chip" id="template-lyrics">✎ Draf template · gratis</button><button class="chip" id="local-ai-lyrics" ${caps.localLyrics ? "" : "disabled"}>✧ AI lokal ${caps.localLyrics ? "· siap" : "· model belum terunduh"}</button><button class="chip" id="to-free-voices">♫ Narasi + musik</button></div><p class="muted">Groq mengirim cerita/lirik ke penyedia sesuai kuota paket akun. ACE-Step menghasilkan nyanyian lokal setelah model terpasang. Draf template bukan AI.</p>`;
    $(".create-area").before(box);
    $("#template-lyrics").onclick = () => freeLyricAction(false);
    $("#groq-lyrics").onclick = () => freeLyricAction("groq");
    $("#local-ai-lyrics").onclick = () => freeLyricAction(true);
    if (caps.desktopModelSetup) {
      const setup = document.createElement("button");
      setup.className = "chip";
      setup.id = "desktop-song-setup";
      setup.textContent = caps.localSinging ? "✓ Mesin nyanyian AI terpasang" : "↓ Pasang mesin nyanyian AI";
      setup.onclick = desktopSongSetup;
      box.querySelector(".chip-row").append(setup);
    }
    $("#to-free-voices").onclick = () => go("cover");
    if ($("#demo-mode"))
      $("#demo-mode").closest("label").classList.add("hidden");
    const duration = $(".duration-field");
    if (duration) {
      duration.classList.remove("hidden");
      duration.querySelector("label").textContent =
        "Durasi lagu · ACE-Step lokal";
      duration.querySelector("small").textContent =
        "CPU tanpa GPU; mulai 30 detik. Kecepatan dan kualitas perlu diuji.";
    }
    const create = $("#create-song");
    create.innerHTML = "♫ Buat lagu bernyanyi AI";
    create.disabled = !caps.localSinging;
    create.title = caps.localSinging
      ? "Jalankan model nyanyian lokal"
      : "Bobot ACE-Step belum tersedia; unduhan perlu diizinkan";
    create.onclick = createLocalSinging;
    if ($(".create-note"))
      $(".create-note").textContent = caps.localSinging
        ? "Model ACE-Step terpasang; keberhasilan baru dinyatakan setelah menghasilkan audio."
        : "Nyanyian AI belum aktif: bobot ACE-Step belum terunduh. Tidak ada narasi sebagai pengganti.";
    const b = document.createElement("button");
    b.id = "create-instrumental";
    b.className = "chip";
    b.style.marginTop = "12px";
    b.textContent = "Coba instrumental lokal · tanpa nyanyian";
    b.onclick = () => {
      if (!draft.story.trim() && !draft.lyrics.trim())
        return toast("Tuliskan cerita atau lirik awal.");
      runGeneration("song", true, "#create-instrumental");
    };
    create.after(b);
    if ($("#improve-lyrics")) {
      $("#improve-lyrics").textContent =
        "✎ Perbaiki struktur · template gratis";
      $("#improve-lyrics").onclick = () => freeLyricAction(false);
    }
  }
  if (state.page === "cover") {
    on("#free-voice-search", "input", (e) => {
      const pos = e.target.selectionStart;
      freeVoiceSearch = e.target.value;
      render();
      $("#free-voice-search").focus();
      $("#free-voice-search").setSelectionRange(pos, pos);
    });
    on("#free-language", "change", (e) => {
      freeVoiceLanguage = e.target.value;
      render();
    });
    on("#voice-preview-text", "input", (e) => {
      draft.previewText = e.target.value;
      persist();
    });
    on("#free-spoken-lyrics", "input", (e) => {
      draft.lyrics = e.target.value;
      persist();
    });
    all(
      "[data-free-preview]",
      (b) => (b.onclick = () => previewVoice(b.dataset.freePreview)),
    );
    all(
      "[data-free-voice]",
      (b) =>
        (b.onclick = () => {
          draft.freeVoice = b.dataset.freeVoice;
          persist();
          render();
        }),
    );
    on("#free-spoken-create", "click", createSpokenSong);
  }
}
loadFreeVoices();
if ($("#app").children.length) enhanceFree();
