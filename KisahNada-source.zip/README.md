# KisahNada — versi terakhir dipulihkan

Studio musik pribadi dengan UI asli yang responsif. Versi terbit tahap awal dipertahankan sebagai dasar tampilan, kemudian fitur terakhir dari percakapan dipulihkan dengan izin pengguna. Cadangan sebelum penggabungan ada di `/workspace/recovery/KisahNada-versi-terbit-sebelum-pemulihan.zip` beserta manifest hash berkas. Jangan menganggap cadangan lama itu sebagai versi aplikasi aktif.

## Jalankan

Pengguna Windows: tersedia jalur **installer `.exe` tanpa WSL**, lihat [panduan Windows desktop](docs/WINDOWS_EXE.md). [Panduan WSL](docs/PANDUAN_WINDOWS.md) dipertahankan sebagai alternatif pengembangan.

```sh
./scripts/setup-free.sh
.venv/bin/python server.py
```

Port 8001, loopback secara default (`PORT` dapat mengganti). FFmpeg/FFprobe diperlukan untuk DSP dan renderer server. Fitur lokal tidak memerlukan API key; lirik melalui Groq memerlukan key akun dengan paket gratis yang dikonfirmasi pemilik. GitHub Pages dapat menyajikan frontend statis, tetapi akun/job/model Python memerlukan server sendiri. Tidak ada deployment publik yang dilakukan.

## Status fitur

- Studio 0.3: editor dan hasil lagu satu halaman, pencarian/filter koleksi, serta alur cerita → tinjau lirik → nyanyian ketika model tersedia. Lihat [catatan studio](docs/CREATION_STUDIO.md). Tampilan Song.ai terkini belum dapat diperiksa karena akses jaringan diblokir.

- Description maksimal 500 kata; Lyrics 12.000 karakter; maksimal 10 tag mood/genre; draft browser bertahan setelah reload.
- **Tombol utama: nyanyian AI ACE-Step**. Tidak aktif sampai checkpoint terunduh dan terverifikasi. Jalur CPU sudah dipasang dan API inferensinya dapat diimpor, tetapi **belum ada hasil nyanyian nyata yang lolos uji**. Lihat [status model](docs/SINGING_MODEL.md).
- Tombol terpisah: demo instrumental WAV lokal 24 detik. Ini synthesizer, bukan nyanyian AI.
- Voice Studio gratis: 705 profil eSpeak-NG dalam 140 bahasa, lima variasi pitch/range per suara dasar, termasuk lima profil Indonesia. Preview dan unduhan WAV bekerja. Ini suara mekanis, bukan suara penyanyi/kloning.
- Narasi/spoken-word sintetis + instrumental: diproses lokal dan disimpan/diunduh, secara eksplisit bukan nyanyian.
- Penyusun draf lirik berbasis aturan/template, dilabeli **bukan AI**, dengan peninjauan sebelum menerima. Qwen lokal tersedia setelah bobot GGUF terverifikasi; bobot belum tersedia.
- Lirik AI Groq: adapter dan tombol disiapkan, diblokir sampai key dan konfirmasi paket gratis tersedia. Inferensi produksi belum diuji; tidak ada retry/fallback berbayar. Lihat [pengaturan Groq](docs/GROQ_LYRICS.md).
- Slideshow foto WebM browser; renderer server menggabungkan JPEG/PNG/WebP dan klip video, efek Ken Burns/Fade/Slide serta soundtrack. 1280×720, 24 fps, 3–6 detik per scene. Audio asli klip tidak dipertahankan; soundtrack pilihan dipakai. Renderer server menolak SVG, renderer browser mendukungnya.
- Vocal Glow Up lokal: noise reduction, EQ, kompresi dan normalisasi; efek remix lokal: EQ/echo/tempo. Bukan model generatif.
- Library IndexedDB: playback, unduh, suka, filter, detail JSON, dan hapus dengan konfirmasi.
- Akun server: daftar/masuk/keluar, password PBKDF2-SHA256 + salt (600.000 iterasi), session cookie HttpOnly/SameSite Strict, pembatasan percobaan masuk.
- Cadangan manual tiap karya, pemulihan ke browser, hapus cadangan terpisah, isolasi proyek antar akun, kuota 1 GB/akun. Browser lokal tetap menyimpan karya setelah keluar akun; gunakan perangkat pribadi.
- Antrean persisten SQLite, satu worker, maksimal dua job aktif per akun/delapan global; riwayat/pemulihan hasil. Job terputus saat restart ditandai gagal dan tidak diulang otomatis.
- Workspace berisi template inspirasi, bukan feed video komunitas atau statistik tren nyata.

## Gratis sebagai default

`KISAHNADA_FREE_ONLY=1` default server memblokir quote/job API berbayar, meskipun kredensial dan paid-enabled tersimpan. Tidak ada fallback otomatis ke layanan berbayar. Hosting, listrik dan perangkat tetap memerlukan sumber daya; gratis selamanya tidak dijamin.

Adapter opsional OpenAI (lirik/foto/video), ElevenLabs Music (lagu/stem) dan gateway berlisensi tetap tersedia sebagai kode kompatibilitas, namun diblokir mode gratis. Tidak ada pembelian/generasi berbiaya dilakukan. My Voice/AI Cover, Hum to song, AI remix, vision lokal dan video generatif belum tersedia dalam mode gratis. Tidak ada suara selebritas dibundel atau izin diasumsikan.

Lihat [mode gratis](docs/FREE_MODE.md), [model nyanyian](docs/SINGING_MODEL.md), [integrasi berbayar opsional](docs/AI_SERVICES.md), serta [atribusi](THIRD_PARTY_NOTICES.md).

## Data dan hosting

`KISAHNADA_DATA_DIR` default `.studio/` berisi akun/session, metadata job dan media. Direktori diabaikan Git serta diblokir dari HTTP. Gunakan disk persisten dan cadangkan database beserta `files/` bersama-sama saat server dihentikan. Jangan membagikan snapshot berisi data pribadi/session produksi. Penyimpanan server belum terenkripsi pada tingkat aplikasi; gunakan disk terenkripsi bila diperlukan.

Akun server berbeda dari akun penyedia AI; belum ada reset password email/OAuth atau sinkronisasi cloud terkelola. Upload foto/audio/sampel di frontend berada di memori sesi sampai diproses/disimpan. Sampel suara bukan model kloning yang sudah dilatih.

Server standard-library ini ditujukan untuk studio pribadi. Sebelum akses jaringan, gunakan reverse proxy HTTPS, `KISAHNADA_SECURE_COOKIE=1`, storage persisten, kontrol pendaftaran, monitoring dan pengujian beban. `KISAHNADA_HOST=0.0.0.0` hanya jika memang ingin membuka jaringan. Publikasi lingkungan pengembangan tidak sama dengan publikasi situs.

## Validasi

```sh
node --check app.js
node --check studio.js
node --check free.js
.venv/bin/python -m unittest discover -s tests -v
# dengan server utama port 8001:
node tests/browser.cjs
# server uji terisolasi dibuat/dihentikan otomatis:
node tests/free-browser.cjs
```

Tes memakai FFmpeg, Pillow (fixture PNG), Playwright dan Chromium dari lingkungan. Tes CPU mengimpor API ACE-Step nyata; itu bukan inferensi model. Tes suara/DSP/video memakai audio nyata. Transport penyedia opsional memakai fixture, bukan panggilan berbayar. Model lirik/nyanyian belum diverifikasi melalui hasil inferensi nyata.
