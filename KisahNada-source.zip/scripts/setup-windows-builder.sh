#!/bin/sh
# Local Debian tooling only; does not install WSL or modify system packages.
set -eu
cd "$(dirname "$0")/.."
kn_tools="$PWD/.local/windows-build/tooling"
mkdir -p "$kn_tools/apt-lists/partial" "$kn_tools/apt-cache/archives/partial" "$kn_tools/apt-empty"
printf '%s\n' 'deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main' > "$kn_tools/sources.list"
set -- -o "Dir::Etc::sourceparts=$kn_tools/apt-empty" -o "Dir::Etc::parts=$kn_tools/apt-empty" -o "Dir::Etc::sourcelist=$kn_tools/sources.list" -o "Dir::State::lists=$kn_tools/apt-lists" -o "Dir::Cache=$kn_tools/apt-cache"
/usr/bin/apt-get "$@" update
cd "$kn_tools"
/usr/bin/apt-get "$@" download nsis=3.11-1 nsis-common=3.11-1
for kn_deb in nsis_3.11-1_*.deb nsis-common_3.11-1_*.deb; do
  dpkg-deb -x "$kn_deb" "$kn_tools/nsis"
done
NSISDIR="$kn_tools/nsis/usr/share/nsis" "$kn_tools/nsis/usr/bin/makensis" -VERSION
