"""Official Qwen GGUF download, pinned API revision and SHA256 LFS."""

import hashlib
import json
import re
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = "Qwen/Qwen2.5-1.5B-Instruct-GGUF"
FILENAME = "qwen2.5-1.5b-instruct-q4_k_m.gguf"
try:
    with urllib.request.urlopen(
        "https://huggingface.co/api/models/" + REPO + "?blobs=true", timeout=30
    ) as r:
        m = json.load(r)
    revision = m.get("sha", "")
    if not re.fullmatch("[a-f0-9]{40}", revision):
        raise ValueError("Commit model tidak valid.")
    entry = next(x for x in m["siblings"] if x["rfilename"] == FILENAME)
    expected = entry["lfs"]["sha256"]
    size = entry["lfs"]["size"]
    if not re.fullmatch("[a-f0-9]{64}", expected) or not 1024**2 < size < 2 * 1024**3:
        raise ValueError("Metadata checksum/ukuran tidak valid.")
    folder = ROOT / ".models"
    folder.mkdir(exist_ok=True)
    target = folder / "lyrics.gguf"
    partial = folder / "lyrics.gguf.partial"
    if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest() == expected:
        print("Model sudah terverifikasi.")
        raise SystemExit(0)
    try:
        h = hashlib.sha256()
        count = 0
        with urllib.request.urlopen(
            "https://huggingface.co/" + REPO + "/resolve/" + revision + "/" + FILENAME,
            timeout=45,
        ) as r, partial.open("wb") as out:
            if not r.url.startswith("https://"):
                raise ValueError("HTTPS diperlukan.")
            while chunk := r.read(1024 * 1024):
                count += len(chunk)
                if count > size:
                    raise ValueError("Unduhan melebihi ukuran resmi.")
                out.write(chunk)
                h.update(chunk)
        if count != size or h.hexdigest() != expected:
            raise ValueError("Checksum model tidak sesuai.")
        partial.replace(target)
        (folder / "lyrics-model.json").write_text(
            json.dumps(
                {
                    "repository": REPO,
                    "filename": FILENAME,
                    "revision": revision,
                    "sha256": expected,
                    "license": "Apache-2.0",
                },
                indent=2,
            )
        )
        print("Bobot lirik lokal terverifikasi; inferensi perlu diuji.")
    finally:
        partial.unlink(missing_ok=True)
except (urllib.error.URLError, ValueError, KeyError, StopIteration) as error:
    raise SystemExit(
        "Model belum dapat diunduh: "
        + str(error)
        + ". Izinkan domain model melalui pengaturan jaringan; jangan melewati proxy/TLS."
    )
