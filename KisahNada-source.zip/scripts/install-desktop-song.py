"""Install Windows CPU ACE-Step using bundled Python, with no user terminal steps."""
import hashlib
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HOME = Path(os.environ["KISAHNADA_DESKTOP_HOME"])
RUNTIME = Path(os.environ["KISAHNADA_SONG_PYTHON"])
COMMIT = "ca1e85fe9430179831e6bc6be790c332190a3866"
SHA256 = "b464c11f00af00e1e089a09f58a03962f803c080f116fd0517dbe5ec839706b3"
SOURCE = HOME / "src/ace"


def command(args):
    subprocess.run(args, check=True, creationflags=subprocess.CREATE_NO_WINDOW)


def install():
    if sys.platform != "win32":
        raise RuntimeError("This installer is for Windows only")
    if not RUNTIME.exists():
        print("Memasang runtime Python nyanyian…", flush=True)
        command([sys.executable, "-m", "venv", str(RUNTIME.parent.parent)])
    if not SOURCE.exists():
        print("Mengunduh source ACE-Step resmi…", flush=True)
        SOURCE.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "source.tar.gz"
            with urllib.request.urlopen("https://codeload.github.com/ace-step/ACE-Step-1.5/tar.gz/" + COMMIT, timeout=90) as response:
                path.write_bytes(response.read(50 * 1024**2))
            if hashlib.sha256(path.read_bytes()).hexdigest() != SHA256:
                raise RuntimeError("Checksum source tidak sesuai")
            staging = SOURCE.with_name("ace-partial")
            if staging.exists():
                shutil.rmtree(staging)
            staging.mkdir(parents=True)
            prefix = "ACE-Step-1.5-" + COMMIT + "/"
            with tarfile.open(path) as archive:
                for info in archive:
                    if not info.isfile() or not info.name.startswith(prefix):
                        continue
                    relative = info.name[len(prefix):]
                    if "/" in relative and not relative.startswith("acestep/"):
                        continue
                    target = (staging / relative).resolve()
                    if not target.is_relative_to(staging.resolve()):
                        raise RuntimeError("Source archive path tidak valid")
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with archive.extractfile(info) as src, target.open("wb") as dst:
                        shutil.copyfileobj(src, dst)
            staging.rename(SOURCE)
    print("Memasang PyTorch CPU; unduhan besar, biarkan aplikasi terbuka…", flush=True)
    command([str(RUNTIME), "-m", "pip", "install", "--disable-pip-version-check", "--retries", "0", "--index-url", "https://download.pytorch.org/whl/cpu", "torch==2.10.0+cpu", "torchaudio==2.10.0+cpu"])
    requirements = [line for line in (ROOT / "requirements-song.txt").read_text().splitlines() if line and not line.startswith(("torch==", "torchaudio==", "#"))]
    print("Memasang dependency nyanyian Windows…", flush=True)
    command([str(RUNTIME), "-m", "pip", "install", "--disable-pip-version-check", "--retries", "0", *requirements])
    command([str(RUNTIME), "-m", "pip", "install", "--no-deps", "--retries", "0", str(SOURCE)])
    command([str(RUNTIME), "-c", "from acestep.handler import AceStepHandler; from acestep.inference import generate_music; print('API model berhasil dimuat; melanjutkan unduhan bobot…')"])
    command([sys.executable, "-u", str(ROOT / "scripts/download-song.py")])


if __name__ == "__main__":
    HOME.mkdir(parents=True, exist_ok=True)
    with (HOME / "song-install.log").open("a", encoding="utf-8") as log:
        # The parent captures progress and writes it to its persistent log as well.
        try:
            install()
        except Exception as error:
            log.write(type(error).__name__ + ": " + str(error) + "\n")
            print("Pemasangan gagal:", type(error).__name__, str(error), flush=True)
            sys.exit(1)
