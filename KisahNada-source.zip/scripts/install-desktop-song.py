"""Install Windows CPU ACE-Step using bundled Python, with no user terminal steps."""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from singing_runtime import SOURCE_COMMIT, SOURCE_SHA256, require_worker_python

DESKTOP_HOME = Path(os.environ["KISAHNADA_DESKTOP_HOME"])
RUNTIME = Path(os.environ["KISAHNADA_SONG_PYTHON"])
BASE_PYTHON = Path(os.environ["KISAHNADA_SONG_BASE_PYTHON"])
READY_MARKER = Path(os.environ["KISAHNADA_SONG_RUNTIME_MARKER"])
COMMIT = SOURCE_COMMIT
SHA256 = SOURCE_SHA256
SOURCE = DESKTOP_HOME / "src/ace-cpu312"


def command(args):
    subprocess.run(args, check=True, creationflags=subprocess.CREATE_NO_WINDOW)


def install():
    if sys.platform != "win32":
        raise RuntimeError("This installer is for Windows only")
    require_worker_python(BASE_PYTHON)
    READY_MARKER.unlink(missing_ok=True)
    if not RUNTIME.exists():
        print("Memasang runtime Python nyanyian…", flush=True)
        command([str(BASE_PYTHON), "-m", "venv", str(RUNTIME.parent.parent)])
    require_worker_python(RUNTIME)
    if not SOURCE.exists():
        print("Mengunduh source ACE-Step resmi…", flush=True)
        SOURCE.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "source.tar.gz"
            with urllib.request.urlopen("https://codeload.github.com/ace-step/ACE-Step-1.5/tar.gz/" + COMMIT, timeout=90) as response:
                path.write_bytes(response.read(50 * 1024**2))
            if hashlib.sha256(path.read_bytes()).hexdigest() != SHA256:
                raise RuntimeError("Checksum source tidak sesuai")
            staging = SOURCE.with_name("ace-partial")
            if staging.exists():
                shutil.rmtree(staging)
            staging.mkdir(parents=True)
            prefix = "ACE-Step-1.5-" + COMMIT + "/"
            with tarfile.open(path) as archive:
                for info in archive:
                    if not info.isfile() or not info.name.startswith(prefix):
                        continue
                    relative = info.name[len(prefix):]
                    if "/" in relative and not relative.startswith(("acestep/", "openrouter/")):
                        continue
                    target = (staging / relative).resolve()
                    if not target.is_relative_to(staging.resolve()):
                        raise RuntimeError("Source archive path tidak valid")
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with archive.extractfile(info) as src, target.open("wb") as dst:
                        shutil.copyfileobj(src, dst)
            staging.rename(SOURCE)
    print("Memasang PyTorch CPU; unduhan besar, biarkan aplikasi terbuka…", flush=True)
    command([str(RUNTIME), "-m", "pip", "install", "--disable-pip-version-check", "--retries", "0", "--index-url", "https://download.pytorch.org/whl/cpu", "torch==2.10.0+cpu", "torchaudio==2.10.0+cpu"])
    requirements = [line for line in (ROOT / "requirements-song.txt").read_text().splitlines() if line and not line.startswith(("torch==", "torchaudio==", "#"))]
    print("Memasang dependency nyanyian Windows…", flush=True)
    command([str(RUNTIME), "-m", "pip", "install", "--disable-pip-version-check", "--retries", "0", *requirements])
    command([str(RUNTIME), "-m", "pip", "install", "--no-deps", "--retries", "0", str(SOURCE)])
    command([str(RUNTIME), "-c", "from acestep.handler import AceStepHandler; from acestep.inference import generate_music; print('API model berhasil dimuat; melanjutkan unduhan bobot…')"])
    command([sys.executable, "-u", str(ROOT / "scripts/download-song.py")])
    READY_MARKER.write_text(json.dumps({"protocol": 1, "python": [3, 12], "source_commit": COMMIT, "source_sha256": SHA256, "cpu_imports_verified": True}), encoding="utf-8")
    from song_engine import singing_files_available
    if not singing_files_available():
        READY_MARKER.unlink(missing_ok=True)
        raise RuntimeError("Pemeriksaan akhir runtime/checkpoint belum berhasil.")


if __name__ == "__main__":
    DESKTOP_HOME.mkdir(parents=True, exist_ok=True)
    with (DESKTOP_HOME / "song-install.log").open("a", encoding="utf-8") as log:
        # The parent captures progress and writes it to its persistent log as well.
        try:
            install()
        except Exception as error:
            log.write(type(error).__name__ + ": " + str(error) + "\n")
            print("Pemasangan gagal:", type(error).__name__, str(error), flush=True)
            sys.exit(1)
