"""Build a real Windows installer on Linux using NSIS and pinned native components."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / ".local/windows-build"
PAYLOAD = BUILD / "payload"
TOOL = BUILD / "tooling/nsis/usr"
OUTPUT = Path("/workspace/artifacts/KisahNada-Setup.exe")


def extract(archive, directory, prefix=""):
    with zipfile.ZipFile(archive) as source:
        for info in source.infolist():
            if info.is_dir() or not info.filename.startswith(prefix):
                continue
            name = info.filename[len(prefix):]
            target = (directory / name).resolve()
            if not target.is_relative_to(directory.resolve()):
                raise ValueError("Unsafe archive path")
            target.parent.mkdir(parents=True, exist_ok=True)
            with source.open(info) as stream, target.open("wb") as output:
                shutil.copyfileobj(stream, output)


def build():
    subprocess.run([os.sys.executable, str(ROOT / "scripts/fetch-windows.py")], check=True)
    if PAYLOAD.exists():
        shutil.rmtree(PAYLOAD)
    PAYLOAD.mkdir(parents=True)
    print("Extracting bundled Python and speech…", flush=True)
    extract(BUILD / "downloads/python.zip", PAYLOAD / "runtime", "tools/")
    extract(BUILD / "downloads/espeak.whl", PAYLOAD / "runtime/Lib/site-packages")
    with zipfile.ZipFile(BUILD / "downloads/msvc.zip") as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            name = Path(info.filename).name
            if name.lower().endswith(".dll"):
                target = PAYLOAD / "runtime" / name
            elif "license" in name.lower() or "copying" in name.lower():
                target = PAYLOAD / "licenses" / ("MSVC-" + name)
            else:
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read(info))
    print("Extracting FFmpeg and FFprobe…", flush=True)
    with zipfile.ZipFile(BUILD / "downloads/ffmpeg.zip") as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            name = Path(info.filename).name
            if not (name == "LICENSE.txt" or "/bin/" in info.filename and (name in ("ffmpeg.exe", "ffprobe.exe") or name.lower().endswith(".dll"))):
                continue
            target = PAYLOAD / ("licenses/FFmpeg-GPL-3.0.txt" if name == "LICENSE.txt" else "bin/" + name)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)
    app = PAYLOAD / "app"
    app.mkdir()
    for path in ROOT.iterdir():
        if path.is_file() and path.suffix in (".py", ".html", ".css", ".js", ".txt", ".md"):
            shutil.copy2(path, app / path.name)
    for folder in ("assets", "scripts", "docs"):
        shutil.copytree(ROOT / folder, app / folder, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    shutil.copy2(ROOT / "packaging/windows/desktop.py", PAYLOAD / "desktop.py")
    shutil.copy2(ROOT / "packaging/windows/MULAI_DI_SINI.txt", PAYLOAD / "MULAI_DI_SINI.txt")
    shutil.copy2(ROOT / "packaging/windows/dependencies.lock.json", PAYLOAD / "dependencies.lock.json")
    shutil.copy2(ROOT / "THIRD_PARTY_NOTICES.md", PAYLOAD / "licenses/THIRD_PARTY_NOTICES.md")
    env = {**os.environ, "NSISDIR": str(TOOL / "share/nsis")}
    command = [str(TOOL / "bin/makensis"), "-V2", "-DPAYLOAD=" + str(PAYLOAD)]
    subprocess.run([*command, str(ROOT / "packaging/windows/launcher.nsi")], env=env, check=True)
    manifest = {str(p.relative_to(PAYLOAD)).replace("\\", "/"): hashlib.sha256(p.read_bytes()).hexdigest() for p in PAYLOAD.rglob("*") if p.is_file()}
    (PAYLOAD / "payload-sha256.json").write_text(json.dumps(manifest, indent=2))
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    print("Compressing Windows setup…", flush=True)
    subprocess.run([*command, "-DOUTPUT=" + str(OUTPUT), str(ROOT / "packaging/windows/setup.nsi")], env=env, check=True)
    digest = hashlib.sha256(OUTPUT.read_bytes()).hexdigest()
    OUTPUT.with_suffix(".exe.sha256").write_text(digest + "  " + OUTPUT.name + "\n")
    print(json.dumps({"installer": str(OUTPUT), "bytes": OUTPUT.stat().st_size, "sha256": digest}), flush=True)


if __name__ == "__main__":
    build()
