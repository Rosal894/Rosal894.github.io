"""Pinned official Linux-x64 CPU runtime; strict SHA256."""

import hashlib
import platform
import tarfile
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
URL = "https://github.com/ggml-org/llama.cpp/releases/download/b11960/llama-b11960-bin-ubuntu-x64.tar.gz"
SHA256 = "31cc3a6bc638ac6c48dc4b1b74888f1eaadf3d14227c1e5f67daf9a49541d97a"
if platform.system() != "Linux" or platform.machine() not in ("x86_64", "AMD64"):
    raise SystemExit("Gunakan runtime resmi sesuai OS dan set KISAHNADA_LLAMA_CLI.")
root = ROOT / ".local/llama"
root.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory() as temp:
    path = Path(temp) / "runtime.tar.gz"
    h = hashlib.sha256()
    with urllib.request.urlopen(URL, timeout=45) as response, path.open("wb") as out:
        while chunk := response.read(1024 * 1024):
            out.write(chunk)
            h.update(chunk)
    if h.hexdigest() != SHA256:
        raise SystemExit("Checksum runtime tidak sesuai; artefak tidak dipakai.")
    with tarfile.open(path) as tar:
        tar.extractall(root, filter="data")
link = root / "llama-cli"
if not link.exists():
    link.symlink_to("llama-b11960/llama-cli")
print("Runtime CPU terverifikasi. Bobot GGUF dipasang terpisah.")
