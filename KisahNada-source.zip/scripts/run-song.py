"""Offline direct inference with verified local ACE-Step checkpoints."""

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODEL_ROOT = Path(os.environ.get("KISAHNADA_SONG_HOME", str(ROOT / ".models/acestep")))
os.environ.update(
    HF_HUB_OFFLINE="1",
    TRANSFORMERS_OFFLINE="1",
    ACESTEP_CHECKPOINTS_DIR=str(MODEL_ROOT / "checkpoints"),
    ACESTEP_DEVICE="cpu",
    ACESTEP_INIT_LLM="false",
    TOKENIZERS_PARALLELISM="false",
)


def run(request_path, output_dir):
    sys.path.insert(0, str(ROOT))
    from song_engine import singing_files_available

    if not singing_files_available():
        raise RuntimeError("Verified singing checkpoints are not installed.")
    spec = json.loads(Path(request_path).read_text())
    import torch

    torch.set_num_threads(4)
    torch.set_num_interop_threads(1)
    from acestep.handler import AceStepHandler
    from acestep.inference import generate_music, GenerationParams, GenerationConfig

    handler = AceStepHandler()
    message, ok = handler.initialize_service(
        project_root=str(MODEL_ROOT),
        config_path="acestep-v15-turbo",
        device="cpu",
        use_flash_attention=False,
        compile_model=False,
        offload_to_cpu=False,
        offload_dit_to_cpu=False,
        use_mlx_dit=False,
    )
    if not ok:
        raise RuntimeError("ACE-Step initialization failed: " + str(message))
    params = GenerationParams(
        caption=spec["caption"],
        lyrics=spec["lyrics"],
        instrumental=spec.get("instrumental", False),
        vocal_language="id",
        duration=spec["seconds"],
        bpm=spec.get("bpm", 92),
        timesignature="4",
        inference_steps=8,
        thinking=False,
        use_cot_metas=False,
        use_cot_caption=False,
        use_cot_language=False,
    )
    config = GenerationConfig(
        batch_size=1, allow_lm_batch=False, use_random_seed=True, audio_format="wav"
    )
    result = generate_music(
        dit_handler=handler,
        llm_handler=None,
        params=params,
        config=config,
        save_dir=str(output_dir),
    )
    if not result.success or not result.audios or not result.audios[0].get("path"):
        raise RuntimeError(
            "ACE-Step did not produce audio: "
            + str(result.error or result.status_message)
        )
    path = Path(result.audios[0]["path"]).resolve()
    if not path.is_relative_to(Path(output_dir).resolve()) or not path.is_file():
        raise RuntimeError("Unexpected output path.")
    (Path(output_dir) / "result.json").write_text(
        json.dumps(
            {"path": str(path), "source": "ACE-Step 1.5", "seconds": spec["seconds"]}
        )
    )


if __name__ == "__main__":
    run(sys.argv[1], Path(sys.argv[2]))
