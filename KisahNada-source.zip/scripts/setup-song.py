"""Install the pinned, previously tested CPU-only ACE-Step inference environment."""

import hashlib
import os
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMMIT = "ca1e85fe9430179831e6bc6be790c332190a3866"
SHA256 = "b464c11f00af00e1e089a09f58a03962f803c080f116fd0517dbe5ec839706b3"
SOURCE = ROOT / ".local/ace-step-src" / ("ACE-Step-1.5-" + COMMIT)
PYTHON = ROOT / ".venv-song/bin/python"
if not SOURCE.exists():
    SOURCE.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as temp:
        archive = Path(temp) / "source.tar.gz"
        with urllib.request.urlopen(
            "https://codeload.github.com/ace-step/ACE-Step-1.5/tar.gz/" + COMMIT,
            timeout=45,
        ) as response, archive.open("wb") as out:
            while chunk := response.read(1024 * 1024):
                out.write(chunk)
        if hashlib.sha256(archive.read_bytes()).hexdigest() != SHA256:
            raise SystemExit("Checksum source tidak sesuai; pemasangan dihentikan.")
        with tarfile.open(archive) as tar:
            tar.extractall(SOURCE.parent, filter="data")
if not PYTHON.exists():
    subprocess.run(
        [
            sys.executable,
            "-m",
            "venv",
            "--system-site-packages",
            str(PYTHON.parent.parent),
        ],
        check=True,
    )
env = {**os.environ, "UV_NATIVE_TLS": "1"}
subprocess.run(
    [
        "uv",
        "pip",
        "install",
        "--python",
        str(PYTHON),
        "--index-url",
        "https://download.pytorch.org/whl/cpu",
        "torch==2.10.0+cpu",
        "torchaudio==2.10.0+cpu",
    ],
    env=env,
    check=True,
)
requirements = [
    x
    for x in (ROOT / "requirements-song.txt").read_text().splitlines()
    if x and not x.startswith(("torch==", "torchaudio==", "#"))
]
subprocess.run(
    ["uv", "pip", "install", "--python", str(PYTHON), *requirements],
    env=env,
    check=True,
)
# Unified upstream pins CUDA on Linux; keep the supported CPU inference override
# isolated and do not install CUDA, vLLM, training-only or Gradio dependencies.
subprocess.run(
    ["uv", "pip", "install", "--python", str(PYTHON), "--no-deps", str(SOURCE)],
    env=env,
    check=True,
)
subprocess.run(
    [
        str(PYTHON),
        "-c",
        'from acestep.handler import AceStepHandler; from acestep.inference import generate_music; import torch; assert not torch.cuda.is_available(); print("ACE-Step CPU imports OK; singing weights/inference validated separately.")',
    ],
    check=True,
)
