"""Official checkpoint download with revision, SHA256 LFS/Git blob verification."""

import hashlib
import json
import os
import re
import shutil
import urllib.error
import urllib.request
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
REPO = "ACE-Step/Ace-Step1.5"
TARGET = Path(os.environ.get("KISAHNADA_SONG_HOME", str(ROOT / ".models/acestep"))) / "checkpoints"
REQUIRED = ("acestep-v15-turbo", "vae", "Qwen3-Embedding-0.6B", "acestep-5Hz-lm-1.7B")
try:
    with urllib.request.urlopen(
        "https://huggingface.co/api/models/" + REPO + "?blobs=true", timeout=30
    ) as response:
        metadata = json.load(response)
    revision = metadata.get("sha", "")
    if not re.fullmatch("[0-9a-f]{40}", revision):
        raise ValueError("Revision model tidak valid.")
    entries = []
    for item in metadata["siblings"]:
        name = item["rfilename"]
        parts = PurePosixPath(name)
        if parts.is_absolute() or ".." in parts.parts:
            raise ValueError("Path tidak aman.")
        if len(parts.parts) > 1 and parts.parts[0] not in REQUIRED:
            continue
        if name.endswith((".md", ".gitattributes")):
            continue
        lfs = item.get("lfs")
        size = (lfs or {}).get("size", item.get("size"))
        checksum = (lfs or {}).get("sha256", item.get("blobId"))
        if (
            not isinstance(size, int)
            or size < 0
            or not isinstance(checksum, str)
            or not re.fullmatch("[a-f0-9]{64}" if lfs else "[a-f0-9]{40}", checksum)
        ):
            raise ValueError("Metadata integritas tidak lengkap: " + name)
        entries.append(
            {
                "path": name,
                "size": size,
                "digest": checksum,
                "algorithm": "sha256" if lfs else "git-sha1",
            }
        )
    if not entries or any(
        not any(e["path"].startswith(folder + "/") for e in entries)
        for folder in REQUIRED
    ):
        raise ValueError("Komponen model tidak lengkap.")
    total = sum(e["size"] for e in entries)
    if total > 20 * 1024**3:
        raise ValueError("Model melebihi batas unduhan 20 GB.")
    TARGET.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(TARGET).free < total + 2 * 1024**3:
        raise ValueError("Ruang disk tidak cukup.")
    print(
        f"Official revision {revision}: {len(entries)} files, {total/1024**3:.2f} GiB.",
        flush=True,
    )

    def digest(path, e):
        h = (
            hashlib.sha256()
            if e["algorithm"] == "sha256"
            else hashlib.sha1(b"blob " + str(e["size"]).encode() + b"\0")
        )
        with path.open("rb") as f:
            while chunk := f.read(1024 * 1024):
                h.update(chunk)
        return h.hexdigest()

    for i, e in enumerate(entries):
        path = TARGET / e["path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        if (
            path.exists()
            and path.stat().st_size == e["size"]
            and digest(path, e) == e["digest"]
        ):
            print("Verified cache:", e["path"], flush=True)
            continue
        partial = path.with_name(path.name + ".partial")
        try:
            print(f'[{i+1}/{len(entries)}] Download {e["path"]}', flush=True)
            count = 0
            with urllib.request.urlopen(
                "https://huggingface.co/"
                + REPO
                + "/resolve/"
                + revision
                + "/"
                + e["path"],
                timeout=60,
            ) as response, partial.open("wb") as out:
                if not response.url.startswith("https://"):
                    raise ValueError("HTTPS diperlukan.")
                while chunk := response.read(1024 * 1024):
                    count += len(chunk)
                    if count > e["size"]:
                        raise ValueError("Ukuran melebihi metadata resmi.")
                    out.write(chunk)
            if count != e["size"] or digest(partial, e) != e["digest"]:
                raise ValueError("Checksum tidak cocok: " + e["path"])
            partial.replace(path)
        finally:
            partial.unlink(missing_ok=True)
    marker = {
        "repository": REPO,
        "revision": revision,
        "files": entries,
        "license": "MIT",
        "inferenceMode": "CPU DiT-only; unused LM weights retained for upstream main-component checks",
    }
    tmp = TARGET / "verified-model.json.partial"
    tmp.write_text(json.dumps(marker, indent=2))
    tmp.replace(TARGET / "verified-model.json")
    print(
        "All checkpoints verified; actual singing inference must still be evaluated.",
        flush=True,
    )
except (urllib.error.URLError, ValueError, KeyError) as error:
    raise SystemExit(
        "Unduhan model belum berhasil: "
        + str(error)
        + ". Tidak mencoba mirror atau menonaktifkan TLS/checksum."
    )
