#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
if [ ! -d .venv ]; then python3 -m venv --system-site-packages .venv; fi
.venv/bin/python -m pip install --disable-pip-version-check -r requirements-free.txt
printf '%s\n' 'Runtime suara gratis siap. Mulai dengan .venv/bin/python server.py. Model nyanyian/lirik dipasang dan diverifikasi terpisah.'
