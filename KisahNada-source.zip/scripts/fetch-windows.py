"""Fetch pinned Windows components over verified TLS; reject any hash drift."""
import base64
import hashlib
import json
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / ".local/windows-build/downloads"


def fetch(item):
    name, meta = item
    target = CACHE / (name + (".whl" if name == "espeak" else ".zip"))
    algorithm = "sha512" if "sha512_base64" in meta else "sha256"
    expected = base64.b64decode(meta["sha512_base64"]).hex() if algorithm == "sha512" else meta["sha256"]

    def digest(path):
        h = hashlib.new(algorithm)
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    if target.exists() and digest(target) == expected:
        print(name, "verified cache", flush=True)
        return
    partial = target.with_suffix(".partial")
    count = 0
    try:
        with urllib.request.urlopen(meta["url"], timeout=90) as response, partial.open("wb") as stream:
            if not response.url.startswith("https://"):
                raise ValueError("HTTPS required")
            for chunk in iter(lambda: response.read(1024 * 1024), b""):
                count += len(chunk)
                if count > 300 * 1024**2:
                    raise ValueError("Component exceeds 300 MB")
                stream.write(chunk)
        if digest(partial) != expected:
            raise ValueError(name + " checksum mismatch; upstream changed, review before updating lock")
        partial.replace(target)
        print(name, count, "bytes, hash verified", flush=True)
    finally:
        partial.unlink(missing_ok=True)


if __name__ == "__main__":
    CACHE.mkdir(parents=True, exist_ok=True)
    lock = json.loads((ROOT / "packaging/windows/dependencies.lock.json").read_text())
    with ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(fetch, lock.items()))
