# Studio pembuatan lagu 0.3

Pengguna meminta pengalaman yang mirip Song.ai. Halaman `https://song.ai` tidak dapat diakses dari jaringan cloud (proxy 403), sehingga tampilan/fitur terkini situs tersebut belum diverifikasi. Rancangan ini mengikuti pola studio musik serta contoh layar yang pengguna berikan sebelumnya, dengan identitas KisahNada. Tidak ada logo, aset, suara atau mesin milik Song.ai yang disalin.

Halaman AI Song sekarang menampilkan editor Cerita/Lirik/Foto & video/Remix berdampingan dengan koleksi nyata pengguna. Panel hasil berisi pencarian, filter Disukai, playback dan unduhan; tidak ada lagu komunitas atau statistik tren palsu. Ide suasana mengisi contoh prompt yang dapat disunting. Tema gelap/terang tetap mengikuti preferensi yang disimpan.

Pada mode Cerita, jika model nyanyian tersedia, pengguna dapat meninjau lirik yang sudah ada atau membuat lirik melalui Groq/Qwen yang benar-benar dikonfigurasi. Lirik tampil dalam editor tinjauan dan tidak mengganti draf sampai diterima. Cerita yang berubah saat tinjauan terbuka ditolak sebelum generasi. Kegagalan penyedia tidak berubah menjadi hasil template otomatis. Jika layanan lirik AI belum tersedia, pengguna dapat memilih menulis sendiri atau draf aturan yang jelas dilabeli bukan AI. My Voice tetap belum didukung.

Bug pengikatan tombol diperbaiki: handler dasar memakai `onclick` untuk Create Song/Improve Lyrics, agar handler studio yang menggantikannya tidak berjalan bersamaan dengan demo instrumental lama. Regresi browser memeriksa pembatalan, penyuntingan, cerita berubah, kegagalan kuota, dan tidak adanya proyek demo tambahan dari klik alur AI.

Nyanyian nyata tetap bergantung pada model ACE-Step yang terpasang. Versi 0.3 memperbaiki tampilan/alur; tidak membuktikan kesetaraan kualitas dengan Song.ai, kloning suara, atau nyanyian Windows yang belum diuji. Pemasang Windows tetap terbundel, tanpa WSL; model besar diunduh terpisah setelah konfirmasi.

Validasi: `node tests/creation-browser.cjs` menggunakan proyek demo WAV nyata untuk Library/search/like/download, serta transport tiruan untuk alur AI. `node tests/free-browser.cjs` memeriksa regresi fitur lokal. Screenshot empty state di `/workspace/artifacts/KisahNada-Studio-v0.3-dark.png` dan `KisahNada-Studio-v0.3-light.png`. Uji transport bukan inferensi model.
