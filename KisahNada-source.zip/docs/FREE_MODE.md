# Mode gratis

Default server `KISAHNADA_FREE_ONLY=1` menolak setiap permintaan quote/job ke integrasi berbayar. Fitur lokal tidak membutuhkan kartu, token, langganan, atau trial. Lirik Groq opsional memerlukan key akun serta konfirmasi paket gratis pemilik; lihat [GROQ_LYRICS.md](GROQ_LYRICS.md). Server tidak dapat memeriksa tagihan akun Groq. Runtime/hosting tetap memerlukan sumber daya.

Saat pemulihan versi terakhir, eSpeak-NG 1.52.0 dipasang ulang melalui `espeakng-loader==0.2.4`. Katalog yang diuji memiliki 705 profil, 140 bahasa dan lima variasi per suara dasar. Ini bukan 705 penyanyi. Bahasa Indonesia memiliki lima profil. Preview WAV dan narasi + musik bekerja, dengan label spoken-word yang jujur.

Penyusun lirik aturan/template mempertahankan kata pengguna sebagai verse dan menambahkan struktur. Hasil tidak disebut AI dan perlu ditinjau sebelum mengganti lirik.

Untuk AI lirik lokal, runtime resmi llama.cpp build b11960 dipasang di `.local/llama/llama-cli`. SHA256 arsip dikunci pada `scripts/install-llama.py`. Bobot Qwen2.5-1.5B-Instruct Q4_K_M belum terunduh; AI-lokal dinonaktifkan sampai berkas model tersedia. Inferensi lirik nyata belum diuji.

```sh
./scripts/setup-free.sh
python3 scripts/install-llama.py
# hanya setelah jaringan model benar-benar mengizinkan:
python3 scripts/download-lyrics.py
.venv/bin/python server.py
```

Installer Qwen memverifikasi revision resmi, ukuran, dan SHA256 LFS sebelum menyimpan `.models/lyrics.gguf`. Batas generasi 384 token, konteks 2048, empat thread dan empat menit. Tidak mengirim teks ke API berbayar bila model tidak tersedia.

Nyanyian AI memakai jalur ACE-Step tersendiri, bukan eSpeak atau pitch-shifting. Lihat [SINGING_MODEL.md](SINGING_MODEL.md). Nyanyian, kloning, vision dan video generatif tidak boleh diklaim selesai dari keberhasilan demo atau unit test.
