# Pilihan gratis: Groq untuk lirik, ACE-Step untuk nyanyian

Groq memproses teks lirik; Groq bukan generator audio bernyanyi. ACE-Step dijalankan sendiri untuk audio bernyanyi, tanpa biaya API. Bobot ACE-Step belum terpasang dan inferensi nyanyian belum diuji. Hosting/perangkat tetap membutuhkan sumber daya. Tidak ada janji layanan gratis selamanya.

Koneksi Groq sudah disiapkan, tetapi belum diuji pada akun nyata. Buat akun di https://console.groq.com/ dan periksa paket gratis, model yang tersedia, serta kuota di dashboard akun. Tidak ada angka kuota yang diasumsikan tetap. Key gratis saat pendaftaran bukan jaminan seluruh pemakaian bebas biaya.

Masukkan key sebagai **secret server** `KISAHNADA_GROQ_KEY` di pengaturan lingkungan, bukan di chat, browser, source code atau Git. Nama alternatif `GROQ_API_KEY` didukung bila sudah tersedia. Setelah memastikan akun menggunakan paket gratis tanpa penagihan otomatis, pemilik dapat mengatur `KISAHNADA_GROQ_FREE_PLAN_CONFIRMED=1`. Default `0` memblokir permintaan. Aplikasi tidak dapat memeriksa paket/tagihan akun Groq; konfirmasi tersebut merupakan pengaturan pemilik, bukan batas invoice dari penyedia.

Domain runtime yang diperlukan: `api.groq.com`. Model default `llama-3.3-70b-versatile`; ketersediaannya pada akun belum diuji. Bila perlu, atur `KISAHNADA_GROQ_MODEL` ke model teks yang tersedia dalam paket gratis akun. Restart server setelah mengubah konfigurasi. Menyimpan draf lingkungan tidak menerapkan perubahan ke runtime.

Tombol **Lirik AI · Groq** mengirim cerita/lirik dan gaya pilihan ke Groq. Foto, video dan audio tidak dikirim oleh adapter ini. Lirik asli tetap tersimpan sampai pengguna menerima hasil. Output ditandai `origin: groq`. API key hanya berada di server dan tidak muncul dalam endpoint kemampuan.

Tidak ada retry otomatis. Kuota 429, pembayaran 402, akses ditolak, timeout, respons terpotong/tidak valid menghentikan permintaan dengan pesan jelas, tanpa fallback ke template atau penyedia berbayar. Redirect ditolak dan TLS tetap diverifikasi. `KISAHNADA_FREE_ONLY=1` dan `KISAHNADA_PAID_ENABLED=0` tetap dipertahankan untuk integrasi berbayar lainnya. Jangan menambahkan kartu/mengaktifkan paket berbayar demi melewati batas.

Tes protokol memakai transport tiruan dan menguji guard, kegagalan kuota, sanitasi key, serta route server. Itu bukan bukti inferensi produksi. Uji satu cerita nyata baru dilakukan setelah jaringan dan key paket gratis siap, lalu tinjau kualitas/fakta lirik.

Referensi: [cookbook resmi Groq](https://github.com/groq/groq-api-cookbook), [dashboard dan batas akun](https://console.groq.com/), [ACE-Step resmi](https://github.com/ace-step/ACE-Step-1.5).
