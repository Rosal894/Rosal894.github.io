# Integrasi berbayar opsional — diblokir secara default

Pengguna memilih gratis. Jangan mengaktifkan pengeluaran, membeli akun atau memakai trial untuk melewati batas. `KISAHNADA_FREE_ONLY=1` adalah default dan menolak job integrasi berbayar meskipun ada key. Fitur lokal tidak memerlukan key; adapter lirik Groq terpisah memerlukan key dan konfirmasi paket gratis, dijelaskan di [GROQ_LYRICS.md](GROQ_LYRICS.md).

Kode kompatibilitas menyediakan OpenAI Chat Completions untuk lirik/foto, Sora 2 untuk video, ElevenLabs Music `music_v1` untuk komposisi dan stem separation, serta gateway berlisensi untuk fitur tambahan. Adapter tersebut belum diuji pada akun produksi; tes memakai transport tiruan. Speech-to-speech tidak dijadikan bukti kloning nyanyian. Tidak ada suara selebritas dibundel.

Harga terkini belum diverifikasi. Referensi resmi:

- https://openai.com/api/pricing/
- https://elevenlabs.io/pricing/api

Jika pengguna kelak secara eksplisit beralih kembali ke berbayar, diperlukan `KISAHNADA_FREE_ONLY=0`, `KISAHNADA_PAID_ENABLED=1`, key aman di server, `KISAHNADA_DAILY_LIMIT_USD` dan `KISAHNADA_PRICES` yang disetujui. Jangan menaruh key di Git/chat/browser. Tarif `song/cover/hum/split` dalam USD/menit; `lyrics/story` USD/request; `video` USD/detik. Tarif per-request LLM perlu konservatif terhadap batas token/foto. Semua fitur nonterkonfigurasi tetap tidak aktif.

Quote per job ditampilkan sebelum dispatch, kedaluwarsa dalam 10 menit, sekali pakai dan terikat input/berkas/akun. Reservasi harian berlaku global seluruh server dalam transaksi SQLite. Ini estimasi internal, bukan batas invoice penyedia; atur juga limit penyedia. Job gagal tetap dihitung karena mungkin sudah ditagih; tidak ada retry otomatis.

Gateway opsional: `KISAHNADA_AI_GATEWAY` HTTPS atau HTTP loopback, `KISAHNADA_AI_TOKEN` opsional, `KISAHNADA_AI_FEATURES` daftar route. POST `<base>/<kind>` multipart `spec` JSON, `audio`, `voice`, `media`. Keluaran audio/video bytes, lyrics/story JSON, split ZIP maksimal 12 audio/150 MB terurai. Gateway harus menjalankan model nyata, menjaga izin suara dan otorisasi. Redirect ditolak agar kredensial tidak diteruskan ke host lain.
