# Menyimpan dan menjalankan KisahNada di Windows

Panduan ini untuk Windows 11 atau Windows 10 yang mendukung WSL 2, memakai Ubuntu 24.04. Kode sudah diuji di Linux cloud; belum dijalankan pada komputer Windows Anda. Panduan ini tidak berarti aplikasi sudah terpasang di komputer Anda.

## 1. Apa yang sudah disimpan

Kode terbaru, tampilan, adapter Groq, pengujian dan dokumentasi berada di repositori kerja. ZIP `KisahNada-versi-terakhir.zip` berisi source code dan panduan. ZIP tidak berisi API key, akun/media pribadi, virtualenv, atau bobot model. Runtime harus dipasang ulang di komputer baru. Draf pengaturan cloud disimpan terpisah.

Cloud Codex dan komputer Windows Anda adalah dua mesin berbeda. Server cloud tidak menjadi server komputer Anda. Saat panduan ini menyebut alamat browser lokal, alamat tersebut baru berlaku setelah server berjalan di Ubuntu WSL pada komputer Anda.

Belum ada alamat web publik aplikasi. GitHub Pages saja tidak menjalankan backend Python, akun, antrean atau model AI. Menyimpan kode, memublikasikan lingkungan Codex, dan menyediakan website publik adalah tindakan berbeda. Tidak ada push GitHub atau penerbitan situs dilakukan dalam proses penyimpanan ini.

## 2. Pasang Ubuntu WSL sekali saja

Buka menu Start Windows, cari **PowerShell**, klik kanan lalu **Run as administrator**. Jalankan:

```powershell
wsl --install -d Ubuntu-24.04
```

Ikuti permintaan restart jika muncul. Buka **Ubuntu 24.04** dari menu Start, lalu buat nama pengguna dan password Linux. Saat mengetik password di terminal Linux, karakter memang tidak ditampilkan.

Jika WSL/Ubuntu sudah terpasang, jangan memasang ulang atau menghapus distro. Cek dengan `wsl --list --verbose` di PowerShell dan gunakan Ubuntu yang ada. Jika perintah WSL gagal, catat pesan kesalahannya; jangan menghapus data/distro untuk mencoba ulang. Referensi Microsoft: https://learn.microsoft.com/windows/wsl/install.

Di terminal **Ubuntu**, jalankan per baris:

```sh
sudo apt update
sudo apt install -y python3 python3-venv python3-pip ffmpeg unzip libgomp1
```

## 3. Salin kode terbaru ke komputer

Ambil ZIP source terbaru dari berkas hasil percakapan/lingkungan. Folder `/workspace` yang disebut di chat berada di cloud, bukan folder Windows. Jika antarmuka tidak menyediakan unduhan berkas ZIP, langkah transfer ini belum selesai; jangan mengetik `/workspace/...` di komputer Windows dan berharap berkasnya ada di sana.

Simpan ZIP pada folder Windows `C:\KisahNada` dengan nama tepat `KisahNada-versi-terakhir.zip`. Buat folder tersebut melalui File Explorer jika belum ada.

Di terminal Ubuntu, jalankan:

```sh
mkdir -p ~/KisahNada
unzip /mnt/c/KisahNada/KisahNada-versi-terakhir.zip -d ~/KisahNada
cd ~/KisahNada
sh scripts/setup-free.sh
```

Gunakan folder tujuan kosong saat pemasangan pertama. Jika sudah punya instalasi lama, cadangkan dahulu; jangan menimpa file akun/media. Menjalankan server dari folder home Linux membantu menghindari masalah izin dan kinerja filesystem Windows.

## 4. Jalankan dan buka aplikasi

Tetap di terminal Ubuntu, di folder `~/KisahNada`:

```sh
KISAHNADA_FREE_ONLY=1 KISAHNADA_PAID_ENABLED=0 .venv/bin/python server.py
```

Biarkan terminal terbuka. Setelah server berhasil berjalan tanpa traceback, buka Edge atau Chrome **di Windows**, lalu ketik alamat `http://localhost:8001` di bilah alamat browser. Ini adalah alamat server WSL pada komputer Anda, bukan tautan preview cloud.

Jika muncul "address already in use", periksa apakah terminal lain sudah menjalankan aplikasi. Jangan memulai beberapa server. Untuk berhenti, tekan **Ctrl+C** pada terminal server. Untuk membuka lagi pada hari lain: buka Ubuntu, ketik `cd ~/KisahNada`, lalu jalankan perintah server di atas. Memasang dependency tidak perlu diulang setiap kali.

Jika browser tidak tersambung, pastikan terminal tidak ditutup, tidak ada traceback, dan Anda menjalankan server pada mesin Windows/WSL yang sama. Jika forwarding localhost WSL bermasalah, rujuk https://learn.microsoft.com/windows/wsl/networking; jangan menganggap server cloud otomatis bisa dibuka di Windows.

## 5. Fitur yang bisa dicoba terlebih dahulu

- Tulis cerita maksimal 500 kata, pilih mood/genre, lalu coba **Draf template**. Ini penyusun berbasis aturan, bukan AI.
- Buat **demo instrumental** dari tombol terpisah; ini bukan nyanyian AI.
- Buka menu **Voices**, pilih bahasa Indonesia, tekan **Preview**, lalu unduh WAV.
- Coba narasi bermusik, slideshow, Glow Up atau efek remix lokal. Pemrosesan server meminta daftar/masuk akun KisahNada; akun ini berbeda dari Groq.
- Buka **Library** untuk memainkan atau mengunduh hasil yang benar-benar selesai dibuat.

705 profil suara adalah variasi suara sintetis eSpeak-NG dalam 140 bahasa, bukan 705 penyanyi. Suara artis, My Voice/kloning nyanyian, dan video generatif belum tersedia. Tombol nyanyian AI tetap nonaktif selama bobot belum lengkap.

## 6. Aktifkan lirik AI Groq secara terpisah

1. Buka https://console.groq.com/ di browser, daftar/masuk dan periksa paket gratis serta kuotanya. Jangan aktifkan layanan berbayar untuk melewati batas.
2. Buat API key. Jangan kirim key ke chat atau simpan ke source code.
3. Hentikan server dengan Ctrl+C. Di **terminal Ubuntu lokal**, jalankan:

```sh
read -rsp 'Tempel API key Groq lalu Enter: ' KISAHNADA_GROQ_KEY
printf '\n'
export KISAHNADA_GROQ_KEY
```

Prompt tidak menampilkan karakter key dan tidak menaruh nilainya dalam riwayat perintah. Setelah memastikan akun memakai paket gratis tanpa penagihan otomatis, jalankan:

```sh
export KISAHNADA_GROQ_FREE_PLAN_CONFIRMED=1
KISAHNADA_FREE_ONLY=1 KISAHNADA_PAID_ENABLED=0 .venv/bin/python server.py
```

Muat ulang halaman aplikasi. Tombol **Lirik AI · Groq** siap dicoba bila key dan konfirmasi terbaca. Coba satu cerita pendek, tinjau hasil, lalu pilih **Gunakan lirik ini**. Konfigurasi terdeteksi belum membuktikan key/model/kuota valid. Jika ditolak, baca pesan; tidak ada retry atau fallback berbayar otomatis.

Key yang dimasukkan cara ini hanya bertahan dalam sesi terminal, bukan disimpan permanen. Masukkan kembali saat membuka sesi Ubuntu baru. Server tidak otomatis membaca file `.env`. Aplikasi tidak dapat memeriksa tagihan akun Groq; flag konfirmasi bukan batas invoice.

Untuk **cloud Codex**, jalurnya berbeda: masukkan key sebagai secret `KISAHNADA_GROQ_KEY` di pengaturan lingkungan cloud. Draf sudah memuat domain Groq dan empat domain model Hugging Face. Tinjau/simpan pengaturan, lalu publikasikan lingkungan melalui produk jika diperlukan. Penyimpanan draf saja belum membuat jaringan/key runtime aktif. Key cloud tidak otomatis ikut ke komputer Windows. Lihat [GROQ_LYRICS.md](GROQ_LYRICS.md).

## 7. Nyanyian AI membutuhkan model ACE-Step

Groq menghasilkan teks, bukan audio bernyanyi. ACE-Step adalah mesin nyanyian yang dipilih. Source/runtime CPU telah diuji dapat diimpor di cloud, tetapi bobot belum terunduh dan belum ada hasil nyanyian nyata yang diverifikasi. Unduhan model cloud saat ini belum diizinkan oleh kebijakan jaringan aktif; domainnya baru ada dalam draf.

Jika ingin memasangnya **di komputer Windows/WSL**, pastikan ruang disk dan RAM memadai; dependency dan bobot memerlukan banyak GB. Kecepatan CPU dan kualitas pada perangkat Anda belum diukur. Perintah lanjutan, dari Ubuntu di folder aplikasi:

```sh
. .venv/bin/activate
python -m pip install uv
python scripts/setup-song.py
python scripts/download-song.py
```

Gunakan Python 3.12 pada jalur Ubuntu 24.04. Downloader memverifikasi file resmi; jangan membuat marker sukses sendiri jika gagal. Jika berhasil, restart server dan mulai dengan lirik pendek serta durasi 30 detik. Hasil perlu didengarkan dan diuji playback/download sebelum fitur disebut selesai. My Voice tidak didukung adapter ini. Detail: [SINGING_MODEL.md](SINGING_MODEL.md).

## 8. Simpan karya dan lanjutkan pengembangan

Unduh karya penting dari Library. Penyimpanan browser berada di profil browser; jangan membersihkan site data sebelum membuat cadangan. Cadangan server berada di folder `.studio` pada instalasi terkait. Hentikan server sebelum menyalin keseluruhan `.studio` agar database dan media konsisten. ZIP source tidak membawa cadangan karya.

Untuk melanjutkan bersama Codex, buka percakapan/lingkungan proyek yang sama dan jelaskan langkah terakhir beserta pesan error jika ada. Jangan kirim password atau API key. Setelah Anda menyiapkan key/jaringan, tahap berikutnya adalah memeriksa koneksi Groq, mengunduh model ACE-Step, lalu menguji satu lagu Indonesia sampai bisa diputar dan diunduh.
