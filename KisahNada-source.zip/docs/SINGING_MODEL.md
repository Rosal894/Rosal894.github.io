# Nyanyian nyata ACE-Step 1.5 — status belum selesai

Tujuannya adalah audio lagu **bernyanyi dari lirik**. Tidak ada fallback narasi/instrumental yang disajikan sebagai nyanyian AI.

- Source resmi dikunci pada commit `ca1e85fe9430179831e6bc6be790c332190a3866`.
- SHA256 arsip source: `b464c11f00af00e1e089a09f58a03962f803c080f116fd0517dbe5ec839706b3`.
- Runtime CPU dipasang terpisah di `.venv-song`: PyTorch/torchaudio `2.10.0+cpu`, Transformers `4.57.6`, Diffusers `0.37.0`; versi lain pada `requirements-song.txt`.
- Import API `AceStepHandler`, `GenerationParams`, `GenerationConfig`, `generate_music` berhasil pada CPU. **Ini belum membuktikan model memuat checkpoint atau menghasilkan nyanyian**.
- Upstream mendokumentasikan CPU inference-only/DiT-only: https://github.com/ace-step/ACE-Step-1.5/blob/ca1e85fe9430179831e6bc6be790c332190a3866/docs/en/INSTALL.md#cpu-only-mode

Installer memakai override CPU pada deklarasi unified upstream yang mengunci CUDA untuk Linux, lalu memasang source `--no-deps`. Ini runtime inferensi langsung, bukan training/vLLM/Gradio lengkap. Tidak perlu membeli GPU untuk percobaan awal, tetapi kecepatan, RAM nyata dan kualitas belum diukur.

## Model dan jaringan

Repositori resmi: `ACE-Step/Ace-Step1.5`. Komponen utama: DiT `acestep-v15-turbo`, VAE, Qwen3 embedding, dan LM 1.7B yang diperlukan pemeriksaan integritas main-checkpoint upstream. LM tersebut tidak dijalankan dalam jalur CPU DiT-only.

Snapshot terbit terbaru saat pemulihan hanya membawa versi aplikasi awal dan tidak membawa pengaturan model/kode terakhir. Dengan izin pengguna, fitur terakhir dipulihkan kembali; versi terbit awal dicadangkan di `/workspace/recovery/`. Domain unduhan dan instruksi setup disimpan pada **draf baru**, bukan diasumsikan aktif pada jaringan instance. Periksa `environment_status` dan respons sebenarnya setelah konfigurasi diterapkan. Simpan/publikasi draf dan runtime adalah hal berbeda.

```sh
python3 scripts/setup-song.py
# setelah jaringan model benar-benar diizinkan:
python3 scripts/download-song.py
.venv/bin/python server.py
```

Downloader mengunci revision resmi, memeriksa disk/batas 20 GB, memverifikasi SHA256 LFS atau Git blob hash setiap file, menolak path tidak aman, lalu menulis marker hanya setelah semua berkas terverifikasi. File parsial tidak dipakai. Tidak ada mirror untuk melewati penolakan proxy, tidak ada TLS/checksum yang dimatikan. Jangan membuat marker palsu.

Checkpoint tersimpan di `.models/acestep/checkpoints/`; source/runtime/weights diabaikan Git. Runner memakai mode offline, bahasa `id`, satu WAV, delapan diffusion steps, tanpa LM/flash-attention/kompilasi, empat thread CPU dan timeout 30 menit. Group subprocess dihentikan pada timeout. Audio diperiksa format/durasi/path sebelum masuk Library.

Masukkan lirik maksimal 4.096 karakter; mulai 30 detik. Male/Female/Random adalah arahan caption, bukan jaminan timbre tertentu. My Voice tidak didukung jalur ini dan ditolak dengan penjelasan. Bila model lirik juga belum terpasang, cerita belum otomatis menjadi lirik; tulis lirik sendiri atau gunakan template yang dilabeli non-AI.

## Kriteria selesai

1. Seluruh checkpoint diunduh dan lolos integritas.
2. Model benar-benar dimuat tanpa OOM/dependensi tersembunyi.
3. Lirik Indonesia menghasilkan audio dengan vokal bernyanyi.
4. Hasil didengarkan untuk memeriksa kejelasan/pelafalan/kecocokan kata; metadata saja tidak cukup.
5. Alur aplikasi playback, simpan dan download hasil nyata diuji.

Kelima kriteria belum dinyatakan terpenuhi. Tidak ada klaim aplikasi sempurna atau contoh nyanyian yang belum dibuat.
