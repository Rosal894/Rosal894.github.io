"""Actual local ACE-Step singing; no speech/instrumental fallback."""

import json
import math
import os
import signal
import subprocess
import tempfile
from pathlib import Path
from storage import Problem

ROOT = Path(__file__).resolve().parent
MODEL_HOME = Path(os.environ.get("KISAHNADA_SONG_HOME", str(ROOT / ".models/acestep")))
CHECKPOINTS = MODEL_HOME / "checkpoints"
PYTHON = Path(os.environ.get("KISAHNADA_SONG_PYTHON", str(ROOT / ".venv-song/bin/python")))
REQUIRED = ("acestep-v15-turbo", "vae", "Qwen3-Embedding-0.6B", "acestep-5Hz-lm-1.7B")


def singing_files_available():
    marker = CHECKPOINTS / "verified-model.json"
    if not PYTHON.exists() or not marker.exists():
        return False
    try:
        m = json.loads(marker.read_text())
        files = m["files"]
        if m.get("repository") != "ACE-Step/Ace-Step1.5" or not files:
            return False
        for folder in REQUIRED:
            if not any(
                x["path"].startswith(folder + "/")
                and x["path"].endswith((".safetensors", ".bin"))
                for x in files
            ):
                return False
        for info in files:
            p = (CHECKPOINTS / info["path"]).resolve()
            if (
                not p.is_relative_to(CHECKPOINTS.resolve())
                or not p.is_file()
                or p.stat().st_size != info["size"]
            ):
                return False
        return True
    except (OSError, ValueError, KeyError, TypeError):
        return False


def compose_request(spec):
    if spec.get("vocal") == "My Voice":
        raise Problem(
            "Kloning My Voice belum didukung model ini. Pilih Male, Female, Random, atau Instrumental."
        )
    lyrics = spec.get("lyrics", "").strip()
    instrumental = spec.get("vocal") == "Instrumental"
    if not instrumental and not lyrics:
        raise Problem("Masukkan lirik pada tab Lyrics agar dapat dinyanyikan.")
    if len(lyrics) > 4096:
        raise Problem("Lirik ACE-Step maksimal 4.096 karakter.")
    seconds = spec.get("songSeconds", 30)
    if seconds not in (30, 60, 120):
        raise Problem("Pilih durasi 30, 60, atau 120 detik.")
    genre = spec.get("genre", "Pop")
    genre = "Pop" if genre == "Random" else genre
    vocal = {
        "Male": "warm male lead vocals",
        "Female": "clear female lead vocals",
        "Instrumental": "instrumental, no vocals",
    }.get(spec.get("vocal"), "expressive lead vocals")
    caption = ", ".join(
        [
            genre,
            vocal,
            "Indonesian song, clear sung lyrics, melodic phrasing, coherent accompaniment",
            spec.get("style", ""),
            *spec.get("tags", []),
        ]
    )[:500]
    return {
        "lyrics": "[Instrumental]" if instrumental else lyrics,
        "instrumental": instrumental,
        "caption": caption,
        "seconds": seconds,
        "bpm": 92,
    }


def generate_singing(spec, progress):
    request = compose_request(spec)
    if not singing_files_available():
        raise Problem(
            "Bobot model nyanyian ACE-Step belum terunduh/terverifikasi.", 503
        )
    progress("Memuat model nyanyian ACE-Step pada CPU; dapat memakan beberapa menit")
    with tempfile.TemporaryDirectory(prefix="kisahnada-singing-") as temp:
        temp = Path(temp)
        input_file = temp / "request.json"
        input_file.write_text(json.dumps(request))
        env = {**os.environ, "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1"}
        with (temp / "model.log").open("wb") as log:
            process = subprocess.Popen(
                [
                    str(PYTHON),
                    str(ROOT / "scripts/run-song.py"),
                    str(input_file),
                    str(temp),
                ],
                stdout=log,
                stderr=log,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
                env=env,
                **({"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}),
            )
            try:
                code = process.wait(timeout=1800)
            except subprocess.TimeoutExpired:
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True)
                else:
                    os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                raise Problem(
                    "Inferensi CPU melewati 30 menit; tidak ada fallback narasi atau instrumental.",
                    504,
                ) from None
        if code != 0 or not (temp / "result.json").exists():
            print("ACE-Step inference failed; exit code:", code, flush=True)
            raise Problem(
                "Model nyanyian gagal menghasilkan audio. Hasil tidak tersedia.", 502
            )
        info = json.loads((temp / "result.json").read_text())
        path = Path(info["path"]).resolve()
        if not path.is_relative_to(temp.resolve()) or not path.is_file():
            raise Problem("Lokasi hasil model tidak valid.", 502)
        from processing import probe

        details = probe(path)
        duration = float(details.get("format", {}).get("duration", 0))
        if (
            not any(s.get("codec_type") == "audio" for s in details.get("streams", []))
            or not math.isfinite(duration)
            or duration < 5
            or abs(duration - request["seconds"]) > max(5, request["seconds"] * 0.15)
        ):
            raise Problem("Audio model kosong atau durasinya tidak sesuai.", 502)
        return (
            path.read_bytes(),
            "audio/wav",
            {
                "type": "ai-song",
                "origin": "local-singing-ai",
                "lyrics": spec.get("lyrics", ""),
                "vocal": spec.get("vocal", "Random"),
                "model": "ACE-Step 1.5 turbo · CPU",
                "generationSeconds": duration,
            },
        )
