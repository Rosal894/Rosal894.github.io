"""Free local speech profiles, explicit rule drafts, and optional GGUF lyric inference."""

import ctypes
import io
import os
import re
import shutil
import signal
import subprocess
import tempfile
import threading
import wave
from pathlib import Path
from storage import Problem
from lyrics_provider import capabilities as groq_capabilities, generate_lyrics as groq_lyrics

ROOT = Path(__file__).resolve().parent
MODEL = Path(
    os.environ.get("KISAHNADA_LYRICS_MODEL", str(ROOT / ".models/lyrics.gguf"))
)
CLI = (
    os.environ.get("KISAHNADA_LLAMA_CLI", "")
    or shutil.which("llama-cli")
    or str(ROOT / ".local/llama/llama-cli")
)


def model_ready():
    return bool(
        Path(CLI).is_file()
        and os.access(CLI, os.X_OK)
        and MODEL.is_file()
        and MODEL.stat().st_size > 1024 * 1024
    )


def lyric_draft(spec, ai=False):
    story = (spec.get("story") or spec.get("lyrics") or "").strip()
    if not story:
        raise Problem("Tuliskan kisah atau lirik awal.")
    if ai:
        if not model_ready():
            raise Problem("Model lirik lokal belum terunduh dan terverifikasi.", 503)
        system = "Anda penulis lirik orisinal bahasa Indonesia. Tulis lirik singkat [Verse], [Chorus], [Bridge] berdasarkan cerita. Jangan mengarang fakta pribadi, nama atau tanggal. Hanya keluarkan lirik."
        content = (
            "Kisah: "
            + spec.get("story", "")
            + "\nLirik awal: "
            + spec.get("lyrics", "")
            + "\nGaya: "
            + spec.get("style", "")
            + ", "
            + ", ".join(spec.get("tags", []))
        )
        p = subprocess.Popen(
            [
                CLI,
                "-m",
                str(MODEL),
                "-sys",
                system,
                "-p",
                content,
                "-n",
                "384",
                "-c",
                "2048",
                "-t",
                "4",
                "--no-display-prompt",
                "--single-turn",
                "--no-show-timings",
                "--simple-io",
                "-co",
                "off",
            ],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True,
        )
        try:
            out, err = p.communicate(timeout=240)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGKILL)
            p.communicate()
            raise Problem("Model lirik CPU melewati batas empat menit.", 504) from None
        if p.returncode:
            raise Problem(
                "Model lirik gagal dijalankan; tidak mengganti hasil dengan template.",
                502,
            )
        text = out.decode(errors="replace").split("<|im_end|>")[0].strip()
        if len(text) < 40:
            raise Problem("Lirik model kosong atau terlalu singkat.", 502)
        return {"lyrics": text[:12000], "origin": "local-ai"}
    words = story.split()
    lines = [" ".join(words[i : i + 9]) for i in range(0, min(len(words), 72), 9)]
    return {
        "lyrics": "[Verse]\n"
        + "\n".join(lines[:4])
        + "\n\n[Chorus]\nBiar nada menjaga cerita\nYang kutulis dengan rasa\nSetiap kata menjadi suara\nKenangan tinggal dalam irama\n\n[Verse 2]\n"
        + "\n".join(lines[4:] or lines[:2])
        + "\n\n[Bridge]\nDi antara kata dan nada\nAda cerita yang kujaga",
        "origin": "local-template",
    }


class Voice(ctypes.Structure):
    _fields_ = [
        ("name", ctypes.c_char_p),
        ("languages", ctypes.c_char_p),
        ("identifier", ctypes.c_char_p),
        ("gender", ctypes.c_ubyte),
        ("age", ctypes.c_ubyte),
        ("variant", ctypes.c_ubyte),
        ("reserved", ctypes.c_ubyte),
        ("score", ctypes.c_int),
        ("spare", ctypes.c_void_p),
    ]


class SpeechEngine:
    def __init__(self):
        self.lock = threading.Lock()
        self.lib = None
        self._catalog = None
        self.rate = 0

    def load(self):
        if self.lib:
            return
        try:
            import espeakng_loader

            lib = espeakng_loader.load_library()
            if lib is None:
                raise RuntimeError()
            lib.espeak_Initialize.argtypes = [
                ctypes.c_int,
                ctypes.c_int,
                ctypes.c_char_p,
                ctypes.c_int,
            ]
            lib.espeak_Initialize.restype = ctypes.c_int
            rate = lib.espeak_Initialize(
                2, 0, str(espeakng_loader.get_data_path()).encode(), 0
            )
            if rate <= 0:
                raise RuntimeError()
            lib.espeak_ListVoices.argtypes = [ctypes.c_void_p]
            lib.espeak_ListVoices.restype = ctypes.POINTER(ctypes.POINTER(Voice))
            lib.espeak_SetVoiceByName.argtypes = [ctypes.c_char_p]
            lib.espeak_SetParameter.argtypes = [
                ctypes.c_int,
                ctypes.c_int,
                ctypes.c_int,
            ]
            lib.espeak_Synth.argtypes = [
                ctypes.c_void_p,
                ctypes.c_size_t,
                ctypes.c_uint,
                ctypes.c_int,
                ctypes.c_uint,
                ctypes.c_uint,
                ctypes.c_void_p,
                ctypes.c_void_p,
            ]
            self.lib = lib
            self.rate = rate
        except (ImportError, OSError, RuntimeError):
            raise Problem(
                "Jalankan scripts/setup-free.sh dan gunakan .venv/bin/python server.py.",
                503,
            ) from None

    def catalog(self):
        with self.lock:
            self.load()
            if self._catalog is not None:
                return self._catalog
            rows = self.lib.espeak_ListVoices(None)
            items = []
            i = 0
            while rows[i]:
                v = rows[i].contents
                i += 1
                ident = v.identifier.decode(errors="replace")
                language = (v.languages or b"")[1:].decode(errors="replace")
                if (
                    not re.fullmatch("[a-zA-Z0-9_/-]+", ident)
                    or ident.startswith(("mb/", "mbrola/"))
                    or not language
                ):
                    continue
                for key, label, pitch, span in [
                    ("natural", "Natural", 50, 50),
                    ("warm", "Warm", 38, 35),
                    ("bright", "Bright", 68, 55),
                    ("deep", "Deep", 22, 30),
                    ("soft", "Soft", 56, 25),
                ]:
                    items.append(
                        {
                            "id": ident + "::" + key,
                            "name": v.name.decode(errors="replace").replace("_", " ")
                            + " · "
                            + label,
                            "language": language,
                            "style": label,
                            "engine": "eSpeak-NG",
                            "synthetic": True,
                            "selector": ident,
                            "pitch": pitch,
                            "range": span,
                        }
                    )
            items.sort(
                key=lambda x: (
                    not x["language"].startswith("id"),
                    not x["language"].startswith("en"),
                    x["language"],
                    x["name"],
                )
            )
            self._catalog = items
            return items

    def synth(self, text, voice_id):
        if not isinstance(text, str) or not 1 <= len(text.strip()) <= 5000:
            raise Problem("Teks suara harus 1–5.000 karakter.")
        v = next((v for v in self.catalog() if v["id"] == voice_id), None)
        if not v:
            raise Problem("Profil suara tidak ditemukan.")
        text = re.sub(r"\[[^\]]*\]", "", text).replace("<", " ").replace(">", " ")
        with self.lock:
            chunks = []
            callback_type = ctypes.CFUNCTYPE(
                ctypes.c_int,
                ctypes.POINTER(ctypes.c_short),
                ctypes.c_int,
                ctypes.c_void_p,
            )

            @callback_type
            def callback(pcm, count, events):
                if pcm and count > 0:
                    chunks.append(ctypes.string_at(pcm, count * 2))
                return 0

            self.lib.espeak_SetSynthCallback.argtypes = [callback_type]
            self.lib.espeak_SetSynthCallback(callback)
            if self.lib.espeak_SetVoiceByName(v["selector"].encode()) != 0:
                raise Problem("Profil suara gagal diaktifkan.")
            for key, value in [(1, 150), (2, 95), (3, v["pitch"]), (4, v["range"])]:
                self.lib.espeak_SetParameter(key, value, 0)
            raw = text.encode() + b"\0"
            buffer = ctypes.create_string_buffer(raw)
            code = self.lib.espeak_Synth(buffer, len(raw), 0, 1, 0, 1, None, None)
            self.lib.espeak_Synchronize()
            if code != 0 or not chunks:
                raise Problem("Sintesis suara gagal.", 502)
            out = io.BytesIO()
            with wave.open(out, "wb") as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(self.rate)
                w.writeframes(b"".join(chunks))
            return out.getvalue()


SPEECH = SpeechEngine()


def free_capabilities():
    try:
        catalog = SPEECH.catalog()
    except Problem:
        catalog = []
    return {
        "localLyrics": model_ready(),
        **groq_capabilities(),
        "templateLyrics": True,
        "localVoices": bool(catalog),
        "voiceProfileCount": len(catalog),
        "voiceLanguageCount": len({v["language"] for v in catalog}),
    }


def generate_free(kind, spec, files, progress):
    if kind == "groq-lyrics":
        progress("Groq sedang menulis lirik sesuai paket akun; tanpa retry otomatis")
        return None, None, groq_lyrics(spec)
    if kind in ("free-lyrics", "template-lyrics"):
        progress(
            "Menulis dengan model CPU lokal"
            if kind == "free-lyrics"
            else "Menyusun draf template — bukan AI"
        )
        return None, None, lyric_draft(spec, kind == "free-lyrics")
    if kind != "spoken-song":
        raise Problem("Fitur gratis tidak ditemukan.", 404)
    text = spec.get("lyrics") or spec.get("story") or ""
    progress("Membuat narasi sintetis, bukan nyanyian")
    data = SPEECH.synth(text, spec.get("freeVoice", ""))
    background = next((f[3] for f in files if f[0] == "audio"), None)
    if background:
        from processing import run, validate_media

        with tempfile.TemporaryDirectory(prefix="kisahnada-mix-") as temp:
            root = Path(temp)
            voice = root / "voice.wav"
            music = root / "music"
            out = root / "mix.wav"
            voice.write_bytes(data)
            music.write_bytes(background)
            validate_media(music, "audio")
            with wave.open(io.BytesIO(data)) as w:
                duration = w.getnframes() / w.getframerate() + 1
            progress("Mencampur narasi dengan instrumental lokal")
            run(
                [
                    "ffmpeg",
                    "-loglevel",
                    "error",
                    "-nostdin",
                    "-y",
                    "-i",
                    str(voice),
                    "-stream_loop",
                    "-1",
                    "-i",
                    str(music),
                    "-filter_complex",
                    "[0:a]volume=1[v];[1:a]volume=0.16[m];[v][m]amix=inputs=2:duration=longest:normalize=0,loudnorm=I=-16:TP=-1.5:LRA=11[out]",
                    "-map",
                    "[out]",
                    "-t",
                    str(duration),
                    "-ar",
                    "44100",
                    str(out),
                ]
            )
            data = out.read_bytes()
    return (
        data,
        "audio/wav",
        {
            "type": "spoken",
            "origin": "local-speech",
            "lyrics": text,
            "vocal": spec.get("freeVoice"),
            "speechNotice": "Narasi sintetis/spoken-word, bukan nyanyian AI atau kloning suara.",
        },
    )
