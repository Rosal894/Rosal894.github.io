Unicode true
Target amd64-unicode
!include "MUI2.nsh"
!include "x64.nsh"
!include "LogicLib.nsh"
Name "KisahNada"
OutFile "${OUTPUT}"
InstallDir "$LOCALAPPDATA\Programs\KisahNada"
RequestExecutionLevel user
SetCompressor /SOLID lzma
BrandingText "KisahNada — Your story, in a song."
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\KisahNada.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Buka KisahNada"
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_LICENSE "${PAYLOAD}/MULAI_DI_SINI.txt"
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Indonesian"
Function .onInit
  ${IfNot} ${RunningX64}
    MessageBox MB_ICONSTOP "KisahNada memerlukan Windows 10/11 64-bit (x64)."
    Abort
  ${EndIf}
  System::Call 'kernel32::OpenMutexW(i 0x100000, i 0, w "Local\KisahNada-Desktop-v1") p .r0'
  ${If} $0 != 0
    System::Call 'kernel32::CloseHandle(p r0)'
    MessageBox MB_ICONSTOP "Tutup studio KisahNada sebelum memasang pembaruan."
    Abort
  ${EndIf}
FunctionEnd
Function un.onInit
  System::Call 'kernel32::OpenMutexW(i 0x100000, i 0, w "Local\KisahNada-Desktop-v1") p .r0'
  ${If} $0 != 0
    System::Call 'kernel32::CloseHandle(p r0)'
    MessageBox MB_ICONSTOP "Tutup studio KisahNada sebelum menghapus instalasi."
    Abort
  ${EndIf}
FunctionEnd
Section "KisahNada"
  SetOutPath "$INSTDIR"
  File /r "${PAYLOAD}/*"
  CreateDirectory "$SMPROGRAMS\KisahNada"
  CreateShortcut "$SMPROGRAMS\KisahNada\KisahNada.lnk" "$INSTDIR\KisahNada.exe"
  CreateShortcut "$DESKTOP\KisahNada.lnk" "$INSTDIR\KisahNada.exe"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\KisahNada" "DisplayName" "KisahNada"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\KisahNada" "UninstallString" '$\"$INSTDIR\Uninstall.exe$\"'
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\KisahNada" "DisplayVersion" "0.3.1"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\KisahNada" "InstallLocation" "$INSTDIR"
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\KisahNada" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\KisahNada" "NoRepair" 1
SectionEnd
Section "Uninstall"
  MessageBox MB_OKCANCEL "Tutup studio KisahNada sebelum melanjutkan. Data karya dan model di folder data pribadi akan dipertahankan." IDOK +2
  Abort
  Delete "$DESKTOP\KisahNada.lnk"
  Delete "$SMPROGRAMS\KisahNada\KisahNada.lnk"
  RMDir "$SMPROGRAMS\KisahNada"
  RMDir /r "$INSTDIR"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\KisahNada"
SectionEnd
