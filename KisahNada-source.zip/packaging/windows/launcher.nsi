Unicode true
Target amd64-unicode
Name "KisahNada"
OutFile "${PAYLOAD}/KisahNada.exe"
RequestExecutionLevel user
SilentInstall silent
AutoCloseWindow true
Section
  SetOutPath "$EXEDIR"
  Exec '"$EXEDIR\runtime\pythonw.exe" "$EXEDIR\desktop.py"'
  IfErrors 0 +2
    MessageBox MB_ICONSTOP "KisahNada belum bisa dibuka. Pasang ulang paket lengkap melalui KisahNada-Setup.exe."
SectionEnd
