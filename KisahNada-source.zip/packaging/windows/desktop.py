"""Native Windows launcher: bundled Python, loopback server, Edge app window."""
import ctypes
from ctypes import wintypes as W
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import urllib.request
import webbrowser

BASE = Path(__file__).resolve().parent
URL = "http://127.0.0.1:48127"


def configure():
    home = Path(os.environ["LOCALAPPDATA"]) / "KisahNada"
    home.mkdir(parents=True, exist_ok=True)
    os.environ.update(
        KISAHNADA_DESKTOP="1", KISAHNADA_DESKTOP_HOME=str(home),
        KISAHNADA_DATA_DIR=str(home / "Data"),
        KISAHNADA_SONG_HOME=str(home / "Models/acestep"),
        KISAHNADA_SONG_PYTHON=str(home / "SongRuntime/Scripts/python.exe"),
        KISAHNADA_FREE_ONLY="1", KISAHNADA_PAID_ENABLED="0",
        PYTHONUTF8="1", PYTHONIOENCODING="utf-8",
    )
    os.environ["PATH"] = str(BASE / "bin") + os.pathsep + str(BASE / "runtime") + os.pathsep + os.environ.get("PATH", "")
    sys.path.insert(0, str(BASE / "app"))
    return home


def open_app():
    candidates = [Path(os.environ.get(key, "C:/Program Files")) / "Microsoft/Edge/Application/msedge.exe" for key in ("ProgramFiles(x86)", "ProgramFiles")]
    edge = next((path for path in candidates if path.is_file()), None)
    if edge:
        subprocess.Popen([str(edge), "--app=" + URL], creationflags=subprocess.CREATE_NO_WINDOW)
    else:
        webbrowser.open(URL)


def self_test():
    """Exercise bundled native DLL/media/server, without network or model claims."""
    from server import StudioServer
    from free_engine import SPEECH
    import tempfile
    import wave
    import io
    with tempfile.TemporaryDirectory() as folder:
        server = StudioServer(("127.0.0.1", 0), folder)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            base = "http://127.0.0.1:" + str(server.server_port)
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(base + "/api/capabilities") as response:
                caps = json.load(response)
            assert caps["localVoices"] and caps["localTools"]
            assert caps["freeOnly"] and not caps["paidEnabled"]
            with opener.open(base + "/theme.js") as response:
                assert b"kisahnada-theme" in response.read()
            voices = SPEECH.catalog()
            voice = next(v for v in voices if v["language"] == "id")
            audio = SPEECH.synth("Ini adalah kisah kami.", voice["id"])
            with wave.open(io.BytesIO(audio)) as stream:
                assert stream.getnframes() > 1000
            from processing import process_local
            output, mime, _ = process_local("glow", {}, [("audio", "voice.wav", "audio/wav", audio)], lambda _: None)
            assert output and mime == "audio/wav"
            print(json.dumps({"native_windows_self_test": "passed", "voices": len(voices), "speech_bytes": len(audio), "dsp_bytes": len(output), "singing_inference": "not_tested"}))
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


def window(server, home):
    user = ctypes.WinDLL("user32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    LRESULT = ctypes.c_ssize_t
    CALLBACK = ctypes.WINFUNCTYPE(LRESULT, W.HWND, W.UINT, W.WPARAM, W.LPARAM)

    class WindowClass(ctypes.Structure):
        _fields_ = [("style", W.UINT), ("callback", CALLBACK), ("cls_extra", ctypes.c_int), ("wnd_extra", ctypes.c_int), ("instance", W.HINSTANCE), ("icon", W.HICON), ("cursor", W.HANDLE), ("background", W.HBRUSH), ("menu", W.LPCWSTR), ("name", W.LPCWSTR)]

    user.CreateWindowExW.argtypes = [W.DWORD, W.LPCWSTR, W.LPCWSTR, W.DWORD, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, W.HWND, W.HMENU, W.HINSTANCE, W.LPVOID]
    user.CreateWindowExW.restype = W.HWND
    user.DefWindowProcW.argtypes = [W.HWND, W.UINT, W.WPARAM, W.LPARAM]
    user.DefWindowProcW.restype = LRESULT
    user.DestroyWindow.argtypes = [W.HWND]
    user.ShowWindow.argtypes = [W.HWND, ctypes.c_int]
    user.UpdateWindow.argtypes = [W.HWND]
    user.SendMessageW.argtypes = [W.HWND, W.UINT, W.WPARAM, W.LPARAM]
    user.SendMessageW.restype = LRESULT
    user.TranslateMessage.argtypes = [ctypes.POINTER(W.MSG)]
    user.DispatchMessageW.argtypes = [ctypes.POINTER(W.MSG)]
    user.DispatchMessageW.restype = LRESULT
    user.MessageBoxW.argtypes = [W.HWND, W.LPCWSTR, W.LPCWSTR, W.UINT]
    kernel.GetModuleHandleW.argtypes = [W.LPCWSTR]
    kernel.GetModuleHandleW.restype = W.HINSTANCE
    instance = kernel.GetModuleHandleW(None)

    @CALLBACK
    def callback(hwnd, message, wparam, lparam):
        if message == 0x111:
            if wparam & 0xFFFF == 101:
                open_app()
            elif wparam & 0xFFFF == 102:
                os.startfile(home)
            elif wparam & 0xFFFF == 103:
                user.SendMessageW(hwnd, 0x10, 0, 0)
            return 0
        if message == 0x10:
            from desktop_setup import INSTALLER
            with server.storage.connect() as db:
                active = db.execute("SELECT count(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[0]
            if active or INSTALLER.status()["state"] == "running":
                user.MessageBoxW(hwnd, "Pemrosesan atau pemasangan model masih berlangsung. Tunggu hingga selesai sebelum menutup studio.", "KisahNada", 0x40)
                return 0
            user.DestroyWindow(hwnd)
            return 0
        if message == 2:
            user.PostQuitMessage(0)
            return 0
        return user.DefWindowProcW(hwnd, message, wparam, lparam)

    window_class = WindowClass(0, callback, 0, 0, instance, None, None, 6, None, "KisahNadaDesktopStatus")
    user.RegisterClassW.argtypes = [ctypes.POINTER(WindowClass)]
    if not user.RegisterClassW(ctypes.byref(window_class)):
        raise ctypes.WinError(ctypes.get_last_error())
    hwnd = user.CreateWindowExW(0, window_class.name, "KisahNada — Studio aktif", 0x00CA0000, 120, 120, 520, 230, None, None, instance, None)
    if not hwnd:
        raise ctypes.WinError(ctypes.get_last_error())
    user.CreateWindowExW(0, "STATIC", "KisahNada berjalan di komputer ini.\nGunakan aplikasi yang terbuka. Tutup studio setelah pekerjaan selesai.", 0x50000000, 22, 22, 465, 55, hwnd, None, instance, None)
    for ident, title, x, width in [(101, "Buka aplikasi", 22, 140), (102, "Folder data / log", 172, 145), (103, "Tutup studio", 327, 145)]:
        user.CreateWindowExW(0, "BUTTON", title, 0x50010000, x, 100, width, 35, hwnd, ident, instance, None)
    user.ShowWindow(hwnd, 1)
    user.UpdateWindow(hwnd)
    open_app()
    msg = W.MSG()
    user.GetMessageW.argtypes = [ctypes.POINTER(W.MSG), W.HWND, W.UINT, W.UINT]
    while user.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
        user.TranslateMessage(ctypes.byref(msg))
        user.DispatchMessageW(ctypes.byref(msg))


def main():
    home = configure()
    if "--self-test" in sys.argv:
        return self_test()
    log = (home / "desktop.log").open("a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = log
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateMutexW.argtypes = [W.LPVOID, W.BOOL, W.LPCWSTR]
    kernel.CreateMutexW.restype = W.HANDLE
    handle = kernel.CreateMutexW(None, False, "Local\\KisahNada-Desktop-v1")
    if ctypes.get_last_error() == 183:
        open_app()
        return
    if not handle:
        raise ctypes.WinError(ctypes.get_last_error())
    from server import StudioServer
    server = StudioServer(("127.0.0.1", 48127))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        window(server, home)
    finally:
        server.shutdown()
        server.server_close()
        thread.join()
        kernel.CloseHandle.argtypes = [W.HANDLE]
        kernel.CloseHandle(handle)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        if sys.platform == "win32":
            ctypes.windll.user32.MessageBoxW(None, "Studio belum dapat dibuka. Buka %LOCALAPPDATA%\\KisahNada\\desktop.log untuk rincian, lalu kirim pesan error tanpa API key.", "KisahNada", 0x10)
        sys.exit(1)
