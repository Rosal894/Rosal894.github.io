"use strict";
const $ = (s) => document.querySelector(s);
const esc = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const genres = [
  "Random",
  "Electronic",
  "Pop",
  "Hip-Hop",
  "Rock",
  "Rap",
  "R&B",
  "Dance",
  "Folk",
  "Country",
  "Jazz",
  "Blues",
  "Reggae",
  "Metal",
  "Punk",
  "House",
  "Drum & Bass",
  "Others",
];
const genreIcons = [
  "🎲",
  "🎹",
  "🎧",
  "🎛️",
  "🎸",
  "🎙️",
  "🎷",
  "🪩",
  "🪕",
  "🤠",
  "🎺",
  "🎼",
  "🥁",
  "🤘",
  "⚡",
  "🎚️",
  "🔊",
  "✦",
];
const moods = [
  "Love",
  "Happy",
  "Heartbreak",
  "Encourage",
  "Sad",
  "Angry",
  "Funny",
  "Passion",
  "Respect",
  "Bittersweet",
];
const moodIcons = ["❤️", "☀️", "💔", "🌱", "🌧️", "🔥", "😄", "🌹", "🤝", "🍂"];
const navs = [
  ["song", "♫", "AI Song"],
  ["cover", "≋", "AI Cover"],
  ["workspace", "▦", "Workspace"],
  ["explore", "◎", "Explore"],
  ["library", "▣", "Library"],
];
const categories = [
  "Trending",
  "MV Stories",
  "New",
  "Musician",
  "Cinematic",
  "AI Cover Videos",
  "Viral Dance",
  "Special Moments",
  "Urban Vibes",
  "Daily Life",
  "80’s Trend",
];
const voices = [
  ["Warm storyteller", "Hangat · Male", "🧑🏽", "Singers"],
  ["Velvet bloom", "Lembut · Female", "👩🏻", "Singers"],
  ["Low tide", "Dalam · Male", "🧔🏻", "Rappers"],
  ["Seoul dream", "Cerah · Female", "👩🏼", "K-pop"],
  ["Pixel star", "Ekspresif · Female", "👩🏽‍🎤", "Anime"],
  ["Harmony club", "Harmoni · Group", "👥", "Groups"],
];
let db;
let projects = [];
let busy = false;
let caps = { song: false, lyrics: false, cover: false, video: false };
let activePlayerURL;
let draft = {
  story: "",
  lyrics: "",
  title: "",
  style: "",
  genre: "Random",
  vocal: "Random",
  tags: [],
  mode: "description",
  media: [],
  source: null,
  voice: null,
  remix: "Late night",
  demo: true,
  effect: "Ken Burns",
  duration: 4,
};
try {
  Object.assign(
    draft,
    JSON.parse(localStorage.getItem("kisahnada-draft") || "{}"),
    { media: [], source: null, voice: null },
  );
} catch {}
const state = {
  page: ["song", "cover", "workspace", "explore", "library"].includes(
    location.hash.slice(1),
  )
    ? location.hash.slice(1)
    : "song",
  libraryType: "My Song",
  filter: "All",
  search: "",
  category: "Trending",
  voiceCat: "Hot",
  voiceSearch: "",
  voice: "Warm storyteller",
};
function persist() {
  const { media, source, voice, ...safe } = draft;
  try {
    localStorage.setItem("kisahnada-draft", JSON.stringify(safe));
  } catch {
    toast("Penyimpanan browser penuh. Unduh karya Anda.");
  }
}
function toast(message) {
  $("#toast").textContent = message;
  $("#toast").classList.add("visible");
  clearTimeout(toast.t);
  toast.t = setTimeout(() => $("#toast").classList.remove("visible"), 4200);
}
function modal(title, body, footer = "") {
  const m = $("#modal");
  $("#modal-content").innerHTML =
    `<div class="modal-head"><h2>${title}</h2><button id="close-modal" aria-label="Tutup">×</button></div>${body}${footer ? `<div class="modal-foot">${footer}</div>` : ""}`;
  $("#close-modal").onclick = () => m.close();
  if (!m.open) m.showModal();
}
$("#modal").addEventListener("cancel", (e) => {
  if (busy) e.preventDefault();
});
$("#modal").addEventListener("click", (e) => {
  if (e.target === $("#modal") && !busy) $("#modal").close();
});
function nav() {
  for (const target of ["#nav", "#mobile-nav"]) {
    $(target).innerHTML = navs
      .map(
        ([id, icon, label]) =>
          `<button class="nav-item ${state.page === id ? "active" : ""}" data-page="${id}" aria-current="${state.page === id ? "page" : "false"}"><span class="nav-icon">${icon}</span>${label}</button>`,
      )
      .join("");
    $(target)
      .querySelectorAll("button")
      .forEach((b) => (b.onclick = () => go(b.dataset.page)));
  }
  $("#breadcrumb").textContent = navs.find((n) => n[0] === state.page)[2];
}
function go(page, mode) {
  if (mode) draft.mode = mode;
  state.page = page;
  location.hash = page;
  render();
  window.scrollTo({ top: 0, behavior: "smooth" });
}
window.addEventListener("hashchange", () => {
  const p = location.hash.slice(1);
  if (navs.some((n) => n[0] === p) && p !== state.page) {
    state.page = p;
    render();
  }
});
function intro(eyebrow, title, subtitle, badge = "✦ YOUR STORY. YOUR SOUND.") {
  return `<div class="intro"><div><div class="eyebrow">${eyebrow}</div><h1>${title}</h1><p>${subtitle}</p></div><span class="intro-badge">${badge}</span></div>`;
}
function sidebarCard() {
  return `<aside class="studio-aside"><div class="story-card"><div class="eyebrow">FROM MOMENTS TO MELODIES</div><h2>Some stories<br>deserve a soundtrack.</h2><p>Pertemuan pertama, perjalanan kecil, atau seseorang yang selalu terasa seperti rumah.</p><div class="record-art"><div class="record"></div><img class="record-cover" src="assets/cover-0.svg" alt="Ilustrasi album pegunungan senja"></div><div class="card-bottom"><span>A MEMORY, ON REPEAT</span><span>↗</span></div></div><div class="side-tip"><h3>✧ <span>Mulai dari satu kenangan</span></h3><p>Sebutkan tempat, suasana, dan perasaanmu. Detail kecil membuat cerita terasa lebih personal.</p></div><div class="side-tip"><h3>♧ <span>Karyamu, ruang pribadimu</span></h3><p>Proyek lokal tersimpan di browser ini. Unduh untuk menyimpan salinan permanen.</p></div></aside>`;
}
function recent() {
  return `<section class="recent"><div class="section-heading"><h2>A little inspiration</h2><button id="see-workspace">Jelajahi ide ↗</button></div><div class="music-grid">${[
    ["Cerita di ujung senja", "Folk · Warm · 92 BPM", 0],
    ["Pulang adalah kamu", "Pop · Love · 100 BPM", 1],
    ["Pelan-pelan, sembuh", "Lo-fi · Bittersweet · 78 BPM", 2],
  ]
    .map(
      ([t, s, i]) =>
        `<article class="music-card"><img src="assets/cover-${i}.svg" alt="Artwork ${t}"><div><b>${t}</b><small>${s}</small></div><button class="play" data-example="${i}" aria-label="Gunakan ide ${t}">↗</button></article>`,
    )
    .join("")}</div></section>`;
}
function selectionCards() {
  return `<div class="select-row"><button class="select-card" id="genre-picker"><span class="tile-icon">${genreIcons[genres.indexOf(draft.genre)] || "✦"}</span><div><small>GENRE</small><b>${esc(draft.genre)}</b></div><span class="arrow">⌄</span></button><button class="select-card" id="vocal-picker"><span class="tile-icon">♩</span><div><small>VOCALS</small><b>${esc(draft.vocal)}</b></div><span class="arrow">⌄</span></button></div>`;
}
function styles() {
  return `<details class="style-section" ${draft.styleOpen || draft.mode !== "description" ? "open" : ""}><summary>Style of the music <span class="muted">(opsional)</span></summary><input class="text-input" id="music-style" placeholder="Contoh: gitar akustik, hangat, mellow…" value="${esc(draft.style)}" maxlength="150"><div class="chip-row" id="selected-tags">${draft.tags.map((t) => `<button class="chip selected" data-tag="${esc(t)}">${esc(t)} ×</button>`).join("")}<small class="muted">${draft.tags.length}/10 pilihan</small></div><div class="chip-row"><span class="row-label">Mood</span>${moods.map((m, i) => `<button class="chip ${draft.tags.includes(m) ? "selected" : ""}" data-tag="${m}">${moodIcons[i]} ${m}</button>`).join("")}</div><div class="chip-row"><span class="row-label">Genre</span>${genres.map((g, i) => `<button class="chip ${draft.tags.includes(g) ? "selected" : ""}" data-tag="${g}">${genreIcons[i]} ${g}</button>`).join("")}</div></details>`;
}
function upload(kind) {
  const isMedia = kind === "media";
  return `<label class="upload-zone"><span class="upload-icon">${isMedia ? "▧" : "⊕"}</span><b>${isMedia ? "Setiap foto punya cerita." : "Pilih lagu untuk cerita barumu."}</b><small>${isMedia ? "Upload foto & video kenanganmu · maksimal 10 file" : "Audio milikmu, atau pilih karya dari Library"}</small><input id="${kind}-upload" type="file" ${isMedia ? 'accept="image/*,video/*" multiple' : 'accept="audio/*"'}><small>${isMedia ? "Foto sampai 15 MB · video sampai 100 MB" : "Audio sampai 50 MB · MP3, WAV, M4A, OGG"}</small></label>${!isMedia ? '<button class="chip" id="pick-library" style="margin-top:12px">▣ Pilih dari Library</button>' : ""}`;
}
function mediaPreviews() {
  return `<div class="media-grid">${draft.media.map((m, i) => `<div class="media-item">${m.file.type.startsWith("video") ? `<video src="${m.url}" muted></video>` : `<img src="${m.url}" alt="${esc(m.file.name)}">`}<button data-remove="${i}" aria-label="Hapus ${esc(m.file.name)}">×</button></div>`).join("")}</div>`;
}
function sourcePreview() {
  return draft.source
    ? `<div class="notice">♫ ${esc(draft.source.name)} <button class="text-btn" id="remove-source">Hapus</button></div>`
    : "";
}
function songBody() {
  if (draft.mode === "description")
    return `<label class="field-label" for="story">Ceritakan kisahmu <small>Make it personal.</small><span class="right">✧</span></label><div class="story-box"><textarea id="story" placeholder="Tentang dua orang yang bertemu tanpa sengaja, lalu menemukan rumah dalam satu sama lain…">${esc(draft.story)}</textarea><div class="counter" id="word-count">${wordCount(draft.story)} / 500 kata</div></div><div class="inspiration"><span>BUTUH IDE?</span>${["♡ Kisah cinta kita", "☀ Perjalanan baru", "⌁ Rindu rumah"].map((s, i) => `<button class="chip" data-prompt="${i}">${s}</button>`).join("")}</div>${selectionCards()}${styles()}`;
  if (draft.mode === "lyrics")
    return `<label class="field-label" for="lyrics">Enter lyrics <small>Lirikmu, melodimu.</small></label><div class="story-box"><textarea id="lyrics" maxlength="12000" placeholder="[Verse]\nTuliskan lirik yang ingin kamu nyanyikan…\n\n[Chorus]\nBiar kata-kata menemukan nadanya.">${esc(draft.lyrics)}</textarea><div class="counter" id="lyric-count">${draft.lyrics.length} / 12.000 karakter</div></div><button class="chip" id="improve-lyrics" style="margin-top:12px">✧ Improved by AI ${caps.lyrics ? "" : "· belum terhubung"}</button>${selectionCards()}${styles()}`;
  if (draft.mode === "image")
    return `${upload("media")}${mediaPreviews()}<label class="field-label" for="image-story">Kisah di balik momen ini <small>Untuk arahan cerita</small></label><input class="text-input" id="image-story" placeholder="Di mana dan apa yang membuat momen ini istimewa?" value="${esc(draft.story)}">${styles()}<div class="scene-options"><label>Efek <select id="effect"><option ${draft.effect === "Ken Burns" ? "selected" : ""}>Ken Burns</option><option ${draft.effect === "Fade" ? "selected" : ""}>Fade</option><option ${draft.effect === "Slide" ? "selected" : ""}>Slide</option></select></label><label>Durasi/foto <select id="duration">${[3, 4, 5, 6].map((n) => `<option value="${n}" ${draft.duration === n ? "selected" : ""}>${n} detik</option>`).join("")}</select></label></div><p class="muted">Foto bisa diekspor menjadi slideshow WebM lokal. Analisis foto dan animasi generatif membutuhkan backend AI.</p>`;
  return `<h2 class="step"><span>01</span>Pick a song</h2>${upload("source")}${sourcePreview()}<h2 class="step"><span>02</span>Choose a new style</h2><div class="style-grid">${["Late night", "Synth", "Rock", "Mellow", "Other"].map((s, i) => `<button class="style-tile ${draft.remix === s ? "selected" : ""}" data-remix="${s}"><img src="assets/cover-${(i + 1) % 6}.svg" alt="Ilustrasi ${s}"><span>${s}</span></button>`).join("")}</div>${selectionCards()}<p class="muted">Remix audio membutuhkan backend AI. Sumber dan gaya akan dikirim hanya saat kamu membuat remix.</p>`;
}
function creationFooter() {
  return `<div class="create-area">${["description", "lyrics"].includes(draft.mode) ? `<label class="mode-note"><input type="checkbox" id="demo-mode" ${draft.demo ? "checked" : ""}> Mode lokal · demo instrumental tanpa vokal AI</label>` : ""}<label class="field-label" for="song-title">Song name <small>(opsional)</small></label><input class="text-input" id="song-title" maxlength="100" placeholder="Beri nama untuk kisahmu…" value="${esc(draft.title)}" style="margin-bottom:14px"><button class="primary full" id="create-song"><span class="spark">✦</span>${draft.mode === "image" ? "Create music & video" : draft.mode === "remix" ? "Create remix" : "Create song"}<span>↗</span></button><div id="creation-error" class="error" role="alert"></div><p class="create-note">${draft.demo && ["description", "lyrics"].includes(draft.mode) ? "Demo instrumental 24 detik · WAV · dibuat di perangkatmu" : "AI generation memerlukan koneksi layanan model"}</p></div>`;
}
function renderSong() {
  return `${intro("SMART AI SONG CREATION", "Your story, <em>in a song.</em>", "Ubah cerita, lirik, dan kenanganmu menjadi sesuatu yang bisa didengarkan.")}<div class="studio-layout"><section class="editor"><div class="editor-tabs" role="tablist">${[
    ["description", "✎", "Description"],
    ["lyrics", "≡", "Lyrics"],
    ["image", "▧", "Image & video"],
    ["remix", "≋", "Remix"],
  ]
    .map(
      ([id, icon, name]) =>
        `<button class="tab ${draft.mode === id ? "active" : ""}" role="tab" aria-selected="${draft.mode === id}" data-mode="${id}"><span>${icon}</span>${name}</button>`,
    )
    .join(
      "",
    )}</div><div class="editor-body">${songBody()}${creationFooter()}</div></section>${sidebarCard()}</div>${recent()}`;
}
function renderCover() {
  let filtered = voices.filter(
    (v) =>
      (["Hot", "New", "Other"].includes(state.voiceCat) ||
        v[3] === state.voiceCat) &&
      v[0].toLowerCase().includes(state.voiceSearch.toLowerCase()),
  );
  return `${intro("YOUR VOICE. A NEW POSSIBILITY.", "Make it <em>your voice.</em>", "Beri warna baru pada lagu dengan karakter vokal pilihanmu.")}<div class="studio-layout"><section class="editor"><div class="editor-body"><h2 class="step"><span>01</span>Pick a song</h2>${upload("source")}${sourcePreview()}<h2 class="step"><span>02</span>Choose a voice</h2><input id="voice-search" class="text-input" type="search" placeholder="Cari karakter vokal…" value="${esc(state.voiceSearch)}"><div class="chip-row">${["Hot", "My Voices", "New", "Groups", "Singers", "Rappers", "K-pop", "Anime", "Other"].map((c) => `<button class="chip ${state.voiceCat === c ? "selected" : ""}" data-voicecat="${c}">${{ Hot: "🔥", "My Voices": "🎙️", New: "✨", Groups: "👥", Singers: "🎤", Rappers: "⚡", "K-pop": "💜", Anime: "🌸", Other: "✦" }[c]} ${c}</button>`).join("")}</div>${state.voiceCat === "My Voices" ? `<button class="upload-zone" id="own-voice"><span class="upload-icon">⊕</span><b>${draft.voice ? esc(draft.voice.name) : "Tambahkan suaramu sendiri"}</b><small>Rekam atau upload contoh suara milikmu.</small></button>` : `<div class="voice-grid">${filtered.map(([n, d, f]) => `<button class="voice-tile ${state.voice === n ? "selected" : ""}" data-voice="${n}"><span class="face">${f}</span><b>${n}</b><small>${d}</small></button>`).join("")}</div>`}<div class="notice">Karakter vokal ini adalah pilihan konsep, belum model suara yang terpasang. Suara penyanyi asli hanya dapat ditambahkan melalui model yang memiliki izin penggunaan.</div><button class="primary full" id="create-cover">✦ Create AI Cover ↗</button><div class="error" id="creation-error" role="alert"></div></div></section>${sidebarCard()}</div>`;
}
function renderWorkspace() {
  const names = [
    "Cerita di ujung senja",
    "A letter to you",
    "City after midnight",
    "Golden memories",
    "Ruang untuk pulang",
    "Little things, big feelings",
    "A quiet celebration",
    "Langkah pertama",
  ];
  return `${intro("A PLACE FOR EVERY IDEA", "Your next <em>creative chapter.</em>", "Pilih titik awal. Bawa ceritamu ke arah yang baru.")}<div class="feature-grid">${[
    ["AI Music Video", "Kenangan yang bergerak.", "image", 0],
    ["AI Song", "Dari kata menjadi nada.", "description", 1],
    ["Vocal Glow Up", "Temukan warna suaramu.", "cover", 2],
  ]
    .map(
      ([n, d, m, i]) =>
        `<button class="feature" data-feature="${m}"><img src="assets/cover-${i}.svg" alt="${n}"><div class="feature-body"><h3>${n} ↗</h3><p>${d}</p></div></button>`,
    )
    .join(
      "",
    )}</div><input class="text-input search" id="template-search" type="search" placeholder="⌕ Cari inspirasi, cerita, dan suasana…" value="${esc(state.search)}"><div class="chip-row">${categories.map((c) => `<button class="chip ${state.category === c ? "selected" : ""}" data-category="${c}">${c}</button>`).join("")}</div><div class="gallery">${names
    .map((n, i) => ({ n, i }))
    .filter(({ n }) => n.toLowerCase().includes(state.search.toLowerCase()))
    .map(
      ({ n, i }) =>
        `<button class="gallery-card" data-template="${i}"><img src="assets/cover-${i % 6}.svg" alt="${n}"><h3>${n}</h3><small>${state.category} · Template cerita · ${i % 2 ? "Pop" : "Folk"}</small></button>`,
    )
    .join(
      "",
    )}</div><p class="muted">Koleksi inspirasi dan template lokal. Ini bukan feed video pengguna atau peringkat tren langsung.</p>`;
}
function renderExplore() {
  return `${intro("GO WHERE THE MUSIC TAKES YOU", "A world of <em>possibilities.</em>", "Ruang kecil untuk ide-ide yang besar.")}<section class="page-hero"><div><div class="eyebrow">EXPLORE MUSIC</div><h2>Find your own frequency.</h2><p>Temukan suasana yang terasa seperti kamu.</p><button class="primary" id="explore-music">Jelajahi inspirasi ↗</button></div><span class="big-icon">♫</span></section><div class="section-heading"><h2>Functions</h2><span class="tag">CREATIVE PLAYGROUND</span></div><div class="tool-grid">${[
    ["≋", "Remix AI", "Bayangkan ulang lagu favoritmu.", "remix"],
    ["♩", "Vocal Glow Up", "Beri ruang untuk suara terbaikmu.", "glow"],
    ["〰", "Hum to song", "Ide melodi dimulai dari senandung.", "hum"],
    ["▧", "AI Video", "Buat kenangan menjadi bergerak.", "image"],
  ]
    .map(
      ([i, n, d, id]) =>
        `<button class="tool-card" data-tool="${id}"><span>${i}</span><div><h3>${n}</h3><p>${d}</p></div></button>`,
    )
    .join(
      "",
    )}</div><div class="section-heading" style="margin-top:32px"><h2>Tools</h2></div><div class="tool-grid">${[
    ["☷", "Studio", "Kembali ke meja kreatifmu.", "studio"],
    ["▣", "Project", "Semua karya di satu tempat.", "project"],
    ["⋔", "Voc/Inst Split", "Pisahkan vokal dan instrumen.", "split"],
  ]
    .map(
      ([i, n, d, id]) =>
        `<button class="tool-card" data-tool="${id}"><span>${i}</span><div><h3>${n}</h3><p>${d}</p></div></button>`,
    )
    .join("")}</div>`;
}
function renderLibrary() {
  let list = projects.filter(
    (p) =>
      (state.libraryType === "My Video"
        ? p.type === "video"
        : p.type !== "video") &&
      (state.filter === "All" ||
        (state.filter === "Liked" && p.liked) ||
        (state.filter === "AI Song" && p.type === "ai-song") ||
        (state.filter === "AI Vocal" && p.type === "cover")),
  );
  return `${intro("YOUR PERSONAL COLLECTION", "Made by you. <em>Kept with love.</em>", "Karya, kenangan, dan ide yang ingin kamu putar lagi.")}<div class="editor-tabs"><button class="tab ${state.libraryType === "My Song" ? "active" : ""}" data-library="My Song">♫ My Song</button><button class="tab ${state.libraryType === "My Video" ? "active" : ""}" data-library="My Video">▧ My Video</button></div><div class="chip-row" style="margin-top:23px">${["All", "Liked", "AI Song", "AI Vocal"].map((f) => `<button class="chip ${state.filter === f ? "selected" : ""}" data-filter="${f}">${f === "Liked" ? "♡ " : ""}${f}</button>`).join("")}</div>${list.length ? `<div class="library-list">${list.map((p) => `<article class="library-row"><img src="assets/cover-${p.art || 0}.svg" alt="Artwork ${esc(p.title)}"><div><h3>${esc(p.title)}</h3><p>${esc(p.genre)} · ${p.type === "demo" ? "Demo instrumental lokal" : p.type === "video" ? (p.origin === "ai" ? "AI Video" : "Slideshow lokal") : p.type === "cover" ? "AI Cover" : p.type === "spoken" ? "Narasi bermusik · sintetis" : p.type === "audio-tool" ? "Audio lokal · DSP" : p.type === "stem" ? "AI Stem" : "AI Song"} · ${new Date(p.created).toLocaleDateString("id-ID")}</p></div><div class="library-actions"><button data-like="${p.id}" aria-label="Sukai lagu" aria-pressed="${!!p.liked}">${p.liked ? "♥" : "♡"}</button><button data-play="${p.id}" aria-label="Putar ${esc(p.title)}">▶</button><button data-download="${p.id}" aria-label="Unduh ${esc(p.title)}">↓</button><button data-detail="${p.id}" aria-label="Detail proyek">•••</button></div></article>`).join("")}</div>` : `<div class="empty"><span>♬</span><h3>${state.filter === "All" ? "Cerita pertamamu menunggu." : "Belum ada karya di sini."}</h3><p>${state.filter === "All" ? "Mulai dari satu kalimat. Biarkan nadanya tumbuh." : "Coba filter lain atau buat karya baru."}</p><button class="primary" id="first-song">✦ Buat lagu pertama</button></div>`}<div class="notice">Disimpan di browser perangkat ini, tanpa akun cloud. Membersihkan data browser dapat menghapus proyek. Unduh audio dan detail karya untuk cadangan.</div>`;
}
function render() {
  nav();
  $("#app").innerHTML = {
    song: renderSong,
    cover: renderCover,
    workspace: renderWorkspace,
    explore: renderExplore,
    library: renderLibrary,
  }[state.page]();
  bind();
}
function on(selector, event, fn) {
  const el = $(selector);
  if (el) el.addEventListener(event, fn);
}
function all(selector, fn) {
  document.querySelectorAll(selector).forEach(fn);
}
const prompts = [
  "Sebuah lagu tentang dua orang yang bertemu di perjalanan, melewati lima tahun bersama, dan selalu memilih untuk pulang pada satu sama lain.",
  "Lagu penuh semangat tentang meninggalkan keraguan dan memulai perjalanan baru.",
  "Tentang rindu pada rumah, masakan ibu, dan suara hujan di halaman saat masih kecil.",
];
function wordCount(s) {
  return s.trim() ? s.trim().split(/\s+/).length : 0;
}
function bind() {
  on(".style-section", "toggle", (e) => {
    if (e.target.isConnected) draft.styleOpen = e.target.open;
  });
  all(
    "[data-mode]",
    (b) =>
      (b.onclick = () => {
        draft.mode = b.dataset.mode;
        persist();
        render();
      }),
  );
  on("#story", "input", (e) => {
    const t = e.target;
    if (wordCount(t.value) > 500) {
      t.value = t.value.trim().split(/\s+/).slice(0, 500).join(" ");
      toast("Deskripsi maksimal 500 kata.");
    }
    draft.story = t.value;
    $("#word-count").textContent = `${wordCount(t.value)} / 500 kata`;
    persist();
  });
  on("#lyrics", "input", (e) => {
    draft.lyrics = e.target.value;
    $("#lyric-count").textContent = `${draft.lyrics.length} / 12.000 karakter`;
    persist();
  });
  for (const [id, k] of [
    ["#song-title", "title"],
    ["#music-style", "style"],
    ["#image-story", "story"],
  ])
    on(id, "input", (e) => {
      draft[k] = e.target.value;
      persist();
    });
  on("#demo-mode", "change", (e) => {
    draft.demo = e.target.checked;
    persist();
    render();
  });
  all(
    "[data-prompt]",
    (b) =>
      (b.onclick = () => {
        draft.story = prompts[+b.dataset.prompt];
        persist();
        render();
      }),
  );
  on("#genre-picker", "click", genrePicker);
  on("#vocal-picker", "click", vocalPicker);
  all(
    "[data-tag]",
    (b) =>
      (b.onclick = () => {
        const t = b.dataset.tag;
        if (draft.tags.includes(t))
          draft.tags = draft.tags.filter((x) => x !== t);
        else if (draft.tags.length < 10) draft.tags.push(t);
        else return toast("Pilih maksimal 10 mood dan genre.");
        persist();
        render();
      }),
  );
  if ($("#create-song")) $("#create-song").onclick = createSong;
  if ($("#improve-lyrics")) $("#improve-lyrics").onclick = improveLyrics;
  on("#media-upload", "change", uploadMedia);
  on("#source-upload", "change", (e) => setSource(e.target.files[0]));
  on("#remove-source", "click", () => {
    draft.source = null;
    render();
  });
  on("#pick-library", "click", pickLibrary);
  all(
    "[data-remove]",
    (b) =>
      (b.onclick = () => {
        URL.revokeObjectURL(draft.media[+b.dataset.remove].url);
        draft.media.splice(+b.dataset.remove, 1);
        render();
      }),
  );
  for (const id of ["effect", "duration"])
    on("#" + id, "change", (e) => {
      draft[id] = id === "duration" ? +e.target.value : e.target.value;
      persist();
    });
  all(
    "[data-remix]",
    (b) =>
      (b.onclick = () => {
        draft.remix = b.dataset.remix;
        persist();
        render();
      }),
  );
  on("#voice-search", "input", (e) => {
    const pos = e.target.selectionStart;
    state.voiceSearch = e.target.value;
    render();
    $("#voice-search").focus();
    $("#voice-search").setSelectionRange(pos, pos);
  });
  all(
    "[data-voicecat]",
    (b) =>
      (b.onclick = () => {
        state.voiceCat = b.dataset.voicecat;
        render();
      }),
  );
  all(
    "[data-voice]",
    (b) =>
      (b.onclick = () => {
        state.voice = b.dataset.voice;
        render();
      }),
  );
  on("#own-voice", "click", ownVoice);
  on("#create-cover", "click", createCover);
  all(
    "[data-feature]",
    (b) =>
      (b.onclick = () =>
        b.dataset.feature === "cover"
          ? go("cover")
          : go("song", b.dataset.feature)),
  );
  on("#see-workspace", "click", () => go("workspace"));
  on("#explore-music", "click", () => go("workspace"));
  all(
    "[data-example]",
    (b) => (b.onclick = () => useTemplate(+b.dataset.example)),
  );
  all(
    "[data-template]",
    (b) => (b.onclick = () => useTemplate(+b.dataset.template)),
  );
  all(
    "[data-category]",
    (b) =>
      (b.onclick = () => {
        state.category = b.dataset.category;
        render();
      }),
  );
  on("#template-search", "input", (e) => {
    const pos = e.target.selectionStart;
    state.search = e.target.value;
    render();
    $("#template-search").focus();
    $("#template-search").setSelectionRange(pos, pos);
  });
  all("[data-tool]", (b) => (b.onclick = () => tool(b.dataset.tool)));
  all(
    "[data-library]",
    (b) =>
      (b.onclick = () => {
        state.libraryType = b.dataset.library;
        state.filter = "All";
        render();
      }),
  );
  all(
    "[data-filter]",
    (b) =>
      (b.onclick = () => {
        state.filter = b.dataset.filter;
        render();
      }),
  );
  on("#first-song", "click", () => go("song"));
  all(
    "[data-like]",
    (b) =>
      (b.onclick = async () => {
        let p = projects.find((p) => p.id === b.dataset.like);
        p.liked = !p.liked;
        await store(p);
        render();
      }),
  );
  all(
    "[data-play]",
    (b) =>
      (b.onclick = () =>
        playProject(projects.find((p) => p.id === b.dataset.play))),
  );
  all(
    "[data-download]",
    (b) =>
      (b.onclick = () =>
        downloadProject(projects.find((p) => p.id === b.dataset.download))),
  );
  all(
    "[data-detail]",
    (b) =>
      (b.onclick = () =>
        projectDetails(projects.find((p) => p.id === b.dataset.detail))),
  );
}
function genrePicker() {
  let choice = draft.genre;
  modal(
    "Find your genre.",
    `<p class="muted">Pilih warna musik untuk ceritamu.</p><div class="option-grid">${genres.map((g, i) => `<button class="option ${g === choice ? "selected" : ""}" data-genre="${g}"><span>${genreIcons[i]}</span>${g}</button>`).join("")}</div>`,
    `<button class="primary full" id="apply-genre">Apply ↗</button>`,
  );
  all(
    "[data-genre]",
    (b) =>
      (b.onclick = () => {
        choice = b.dataset.genre;
        all("[data-genre]", (x) => x.classList.toggle("selected", x === b));
      }),
  );
  $("#apply-genre").onclick = () => {
    draft.genre = choice;
    persist();
    $("#modal").close();
    render();
  };
}
function vocalPicker() {
  let choice = draft.vocal;
  modal(
    "A voice for your story.",
    `<p class="muted">Vokal AI membutuhkan layanan generator yang terhubung.</p><div class="option-grid">${[
      ["Random", "🎲"],
      ["Male", "👨🏻"],
      ["Female", "👩🏻"],
      ["Instrumental", "🎹"],
      ["My Voice", "🎙️"],
    ]
      .map(
        ([g, i]) =>
          `<button class="option ${g === choice ? "selected" : ""}" data-vocal="${g}"><span>${i}</span>${g}</button>`,
      )
      .join("")}</div>`,
    `<button class="primary full" id="apply-vocal">Apply ↗</button>`,
  );
  all(
    "[data-vocal]",
    (b) =>
      (b.onclick = () => {
        choice = b.dataset.vocal;
        all("[data-vocal]", (x) => x.classList.toggle("selected", x === b));
      }),
  );
  $("#apply-vocal").onclick = () => {
    draft.vocal = choice;
    persist();
    $("#modal").close();
    render();
    if (choice === "My Voice") ownVoice();
  };
}
function ownVoice() {
  modal(
    "Your voice, your signature.",
    `<p class="muted">Upload rekaman bersih tanpa musik latar (10–60 detik dianjurkan). Sampel belum menjadi model suara sampai backend kloning suara dihubungkan.</p><label class="upload-zone"><span class="upload-icon">♩</span><b>Upload contoh suara</b><input id="voice-file" type="file" accept="audio/*"></label><p id="voice-filename" class="muted">${draft.voice ? esc(draft.voice.name) : "Belum ada sampel dipilih."}</p><label class="mode-note"><input type="checkbox" id="consent"> Ini suara saya atau saya memiliki izin pemilik suara.</label><div class="error" id="voice-error" role="alert"></div>`,
    `<button class="primary full" id="save-voice">Gunakan sampel ↗</button>`,
  );
  let file = null;
  $("#voice-file").onchange = (e) => {
    file = e.target.files[0];
    $("#voice-filename").textContent = file?.name || "Belum ada sampel.";
  };
  $("#save-voice").onclick = () => {
    if (
      !$("#consent").checked ||
      !file ||
      !file.type.startsWith("audio/") ||
      file.size > 25 * 1024 * 1024
    ) {
      $("#voice-error").textContent =
        "Pilih audio maksimal 25 MB dan konfirmasi izin pemakaian suara.";
      return;
    }
    draft.voice = file;
    draft.vocal = "My Voice";
    $("#modal").close();
    render();
    toast("Sampel dipilih untuk sesi ini. Model suara AI belum terhubung.");
  };
}
function uploadMedia(e) {
  let rejected = 0;
  for (const file of e.target.files) {
    const video = file.type.startsWith("video/");
    if (
      draft.media.length >= 10 ||
      !file.type.match(/^(image|video)\//) ||
      file.size > (video ? 100 : 15) * 1024 * 1024
    ) {
      rejected++;
      continue;
    }
    draft.media.push({ file, url: URL.createObjectURL(file) });
  }
  render();
  if (rejected)
    toast(
      `${rejected} file tidak ditambahkan. Periksa format, ukuran, atau batas 10 file.`,
    );
}
function setSource(file) {
  if (!file) return;
  if (!file.type.startsWith("audio/") || file.size > 50 * 1024 * 1024)
    return toast("Pilih audio maksimal 50 MB.");
  draft.source = { file, name: file.name };
  render();
}
function pickLibrary() {
  const songs = projects.filter((p) => p.type !== "video");
  modal(
    "Pick a song.",
    songs.length
      ? `<div class="library-list">${songs.map((p) => `<button class="select-card" data-pick="${p.id}"><span>♫</span>${esc(p.title)}</button>`).join("")}</div>`
      : '<p class="muted">Belum ada lagu. Buat demo instrumental atau upload audio milikmu terlebih dahulu.</p>',
  );
  all(
    "[data-pick]",
    (b) =>
      (b.onclick = () => {
        const p = projects.find((p) => p.id === b.dataset.pick);
        draft.source = {
          file: new File([p.blob], p.title + ".wav", { type: p.blob.type }),
          name: p.title,
        };
        $("#modal").close();
        render();
      }),
  );
}
function useTemplate(i) {
  const n = i % 3;
  draft.story = prompts[n];
  draft.genre = ["Folk", "Pop", "Jazz"][n];
  draft.tags = [
    ["Love", "Bittersweet"],
    ["Happy", "Encourage"],
    ["Sad", "Love"],
  ][n];
  draft.mode = "description";
  persist();
  go("song");
  toast("Ide ditambahkan. Buat cerita ini menjadi milikmu.");
}
function tool(id) {
  if (id === "studio") return go("song");
  if (id === "project") return go("library");
  if (["remix", "image"].includes(id)) return go("song", id);
  modal(
    {
      glow: "Vocal Glow Up",
      hum: "Hum to song",
      split: "Vocal / Instrument Split",
    }[id],
    `<p class="muted">${{ glow: "Peningkatan kualitas vokal", hum: "Mengubah senandung menjadi lagu", split: "Pemisahan vokal dan instrumen" }[id]} memerlukan model pemrosesan audio. Fitur ini belum tersedia pada mode lokal.</p><div class="notice">Tidak ada file yang diproses atau diunggah. Anda tetap bisa membuat demo instrumental dan slideshow tanpa layanan AI.</div>`,
    `<button class="primary full" id="back-studio">Buka studio ↗</button>`,
  );
  $("#back-studio").onclick = () => {
    $("#modal").close();
    go("song");
  };
}
function download(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 20000);
}
function downloadProject(p) {
  download(
    p.blob,
    `${p.title.replace(/[\\/:*?"<>|]/g, "-")}.${p.type === "video" ? (p.blob.type.includes("mp4") ? "mp4" : "webm") : p.blob.type.includes("mpeg") ? "mp3" : p.blob.type.includes("wav") ? "wav" : "audio"}`,
  );
}
function playProject(p) {
  if (activePlayerURL) URL.revokeObjectURL(activePlayerURL);
  activePlayerURL = URL.createObjectURL(p.blob);
  if (p.type === "video") {
    modal(
      esc(p.title),
      `<video src="${activePlayerURL}" controls autoplay style="width:100%;border-radius:10px"></video>`,
    );
    return;
  }
  $("#player").classList.remove("hidden");
  $("#player").innerHTML =
    `<b>♫ ${esc(p.title)}</b><audio controls autoplay src="${activePlayerURL}"></audio><button id="close-player" aria-label="Tutup pemutar">×</button>`;
  $("#close-player").onclick = () => {
    $("#player audio").pause();
    $("#player").classList.add("hidden");
    URL.revokeObjectURL(activePlayerURL);
  };
}
async function store(p) {
  if (!db)
    throw Error(
      "Penyimpanan browser tidak tersedia. Periksa izin penyimpanan.",
    );
  await new Promise((res, rej) => {
    const t = db.transaction("projects", "readwrite");
    t.objectStore("projects").put(p);
    t.oncomplete = res;
    t.onerror = () =>
      rej(
        Error(
          "Penyimpanan penuh atau tidak diizinkan. Unduh hasil sebelum menutup.",
        ),
      );
  });
  const i = projects.findIndex((x) => x.id === p.id);
  if (i < 0) projects.unshift(p);
  else projects[i] = p;
}
function projectDetails(p) {
  modal(
    "Behind the song.",
    `<p><b>${esc(p.title)}</b></p><p class="muted">${esc(p.genre)} · ${esc(p.vocal || "Instrumental")}<br>${p.type === "demo" ? "Dibuat dengan synthesizer lokal; bukan lagu bernyanyi atau hasil AI." : ""}</p><div class="result-lyrics">${esc(p.lyrics || p.story || "Tidak ada lirik tersimpan.")}</div>`,
    `<div style="display:flex;gap:12px"><button class="primary" id="export-project">Unduh detail ↓</button><button class="chip" id="delete-project">Hapus proyek</button></div>`,
  );
  $("#export-project").onclick = () => {
    const { blob, ...meta } = p;
    download(
      new Blob([JSON.stringify(meta, null, 2)], { type: "application/json" }),
      p.title + ".json",
    );
  };
  $("#delete-project").onclick = () => {
    modal(
      "Hapus karya ini?",
      `<p class="muted">${esc(p.title)} akan dihapus dari browser ini. Unduh dahulu jika ingin menyimpan salinannya.</p>`,
      `<button class="primary full" id="confirm-delete">Hapus permanen</button>`,
    );
    $("#confirm-delete").onclick = async () => {
      const t = db.transaction("projects", "readwrite");
      t.objectStore("projects").delete(p.id);
      t.oncomplete = () => {
        projects = projects.filter((x) => x.id !== p.id);
        $("#modal").close();
        render();
        toast("Proyek dihapus.");
      };
    };
  };
}
async function init() {
  try {
    db = await new Promise((res, rej) => {
      const r = indexedDB.open("kisahnada", 1);
      r.onupgradeneeded = () =>
        r.result.createObjectStore("projects", { keyPath: "id" });
      r.onsuccess = () => res(r.result);
      r.onerror = rej;
    });
    projects = await new Promise((res, rej) => {
      const r = db.transaction("projects").objectStore("projects").getAll();
      r.onsuccess = () => res(r.result.sort((a, b) => b.created - a.created));
      r.onerror = rej;
    });
  } catch {
    toast("Penyimpanan browser tidak tersedia. Proyek tidak dapat disimpan.");
  }
  try {
    const r = await fetch("/api/capabilities");
    if (r.ok) caps = await r.json();
  } catch {}
  render();
}
$("#settings").onclick = () =>
  modal(
    "Studio connections.",
    `<div class="eyebrow">LOCAL FIRST. ALWAYS YOURS.</div><p class="muted">Mode lokal berjalan tanpa akun: demo instrumental WAV, unggahan, Library, dan slideshow WebM. Tidak ada data yang dikirim ke layanan AI dalam mode ini.</p><div class="notice">AI Song: ${caps.song ? "dikonfigurasi" : "belum terhubung"}<br>AI Lyrics: ${caps.lyrics ? "dikonfigurasi" : "belum terhubung"}<br>AI Cover: ${caps.cover ? "dikonfigurasi" : "belum terhubung"}<br>AI Video: ${caps.video ? "dikonfigurasi" : "belum terhubung"}</div><p class="muted">Integrasi model dikonfigurasi pada server, bukan dengan API key di browser. Petunjuk ada di README. Layanan berbayar atau model lokal dengan hardware memadai diperlukan untuk generasi AI. Ketersediaan layanan jangka panjang mengikuti penyedia.</p>`,
  );
$("#about").onclick = () =>
  modal(
    "A song worth keeping.",
    `<p class="muted">KisahNada adalah studio pribadi untuk cerita, musik, dan kenangan. Dibangun dengan desain asli yang tenang, hangat, dan berfokus pada ceritamu.</p><p class="muted">Versi ini memiliki mode lokal yang dapat digunakan tanpa API. Fitur generatif ditandai dengan status koneksinya, sehingga kamu selalu tahu bagaimana karya dibuat.</p>`,
  );
function generationError(message) {
  const el = $("#creation-error");
  if (el) el.textContent = message;
  else toast(message);
}
async function createSong() {
  if (busy) return;
  const mode = draft.mode;
  if (mode === "image") {
    if (!draft.media.length)
      return generationError("Tambahkan setidaknya satu foto atau video.");
    return imageCreationOptions();
  }
  if (mode === "remix") {
    if (!draft.source) return generationError("Pilih lagu yang ingin diremix.");
    if (!caps.song)
      return generationError(
        "Remix AI belum terhubung. Audio Anda belum diproses. Hubungkan backend generator melalui petunjuk README.",
      );
    return runGeneration("song", false);
  }
  if (mode === "description" && !draft.story.trim())
    return generationError("Ceritakan sedikit kisahmu terlebih dahulu.");
  if (mode === "lyrics" && !draft.lyrics.trim())
    return generationError("Tuliskan lirik terlebih dahulu.");
  if (wordCount(draft.story) > 500)
    return generationError("Deskripsi maksimal 500 kata.");
  if (!draft.demo && !caps.song)
    return generationError(
      "Generator lagu AI belum terhubung. Gunakan mode lokal untuk demo instrumental atau hubungkan backend AI.",
    );
  if (draft.demo && draft.vocal === "My Voice") {
    generationError(
      "Mode lokal tidak mengkloning suara. Pilih Instrumental atau hubungkan layanan AI untuk My Voice.",
    );
    return;
  }
  if (!draft.demo && draft.vocal === "My Voice" && !draft.voice)
    return ownVoice();
  await runGeneration("song", draft.demo);
}
async function createCover() {
  if (busy) return;
  if (!draft.source) return generationError("Pilih lagu terlebih dahulu.");
  if (state.voiceCat === "My Voices" && !draft.voice) return ownVoice();
  if (!caps.cover)
    return generationError(
      "AI Cover belum terhubung ke model suara. File Anda belum diproses.",
    );
  await runGeneration("cover", false);
}
function payload() {
  const data = new FormData();
  const { media, source, voice, ...spec } = draft;
  spec.selectedVoice = state.voice;
  spec.voiceConsent = !!voice;
  data.append("spec", JSON.stringify(spec));
  if (source) data.append("audio", source.file);
  if (voice) data.append("voice", voice);
  for (const m of media) data.append("media", m.file);
  return data;
}
async function apiRequest(route, body) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 180000);
  try {
    const r = await fetch("/api/" + route, {
      method: "POST",
      body,
      signal: ctrl.signal,
    });
    if (!r.ok) {
      let detail = "Layanan tidak tersedia.";
      try {
        detail = (await r.json()).error || detail;
      } catch {}
      throw Error(detail);
    }
    return r;
  } catch (e) {
    if (e.name === "AbortError")
      throw Error(
        "Waktu tunggu AI habis. Coba lagi nanti; belum ada karya yang disimpan.",
      );
    throw e;
  } finally {
    clearTimeout(timer);
  }
}
async function runGeneration(kind, local, triggerSelector = null) {
  busy = true;
  const button = $(
    triggerSelector || (kind === "cover" ? "#create-cover" : "#create-song"),
  );
  const old = button.innerHTML;
  button.disabled = true;
  button.innerHTML = local
    ? "✦ Menyusun demo instrumental…"
    : "✦ Memproses dengan AI…";
  button.classList.add("loading");
  generationError("");
  try {
    let blob,
      generatedMeta = {},
      genre = draft.genre;
    if (genre === "Random") {
      genre = genres[1 + Math.floor(Math.random() * (genres.length - 2))];
    }
    if (local) {
      await new Promise((r) => setTimeout(r, 50));
      blob = await synthesize({ ...draft, genre });
    } else {
      const body = payload(),
        spec = JSON.parse(body.get("spec"));
      spec.genre = genre;
      body.set("spec", JSON.stringify(spec));
      const r = await apiRequest(kind, body);
      generatedMeta = r.projectMeta || {};
      if (!r.headers.get("Content-Type")?.startsWith("audio/"))
        throw Error("Respons generator bukan audio yang valid.");
      blob = await r.blob();
      if (blob.size < 100) throw Error("Audio yang dikembalikan kosong.");
    }
    const p = {
      id: crypto.randomUUID(),
      title:
        draft.title.trim() ||
        draft.story.trim().slice(0, 40) ||
        "Untitled story",
      genre,
      vocal: local ? "Instrumental" : draft.vocal,
      story: draft.story,
      lyrics: draft.lyrics,
      style: draft.style,
      tags: [...draft.tags],
      type: local ? "demo" : kind === "cover" ? "cover" : "ai-song",
      blob,
      ...(local ? {} : generatedMeta),
      created: Date.now(),
      art: Math.floor(Math.random() * 6),
      liked: false,
    };
    try {
      await store(p);
    } catch (e) {
      downloadProject(p);
      throw Error(e.message + " Hasil sudah diunduh sebagai cadangan.");
    }
    go("library");
    state.libraryType = "My Song";
    state.filter = "All";
    render();
    playProject(p);
    toast(
      local
        ? "Demo instrumental selesai. Ini bukan hasil AI bernyanyi."
        : "Karya selesai dan disimpan di Library.",
    );
  } catch (e) {
    generationError(e.message);
    toast(e.message);
  } finally {
    busy = false;
    if (button.isConnected) {
      button.disabled = false;
      button.innerHTML = old;
      button.classList.remove("loading");
    }
  }
}
async function improveLyrics() {
  if (!draft.lyrics.trim()) return toast("Tuliskan lirik terlebih dahulu.");
  if (!caps.lyrics)
    return modal(
      "Improved by AI",
      `<p class="muted">Layanan penulisan lirik AI belum terhubung. Lirik asli tetap tersimpan dan tidak diubah.</p><div class="notice">Untuk saat ini, gunakan penanda [Verse], [Chorus], dan [Bridge] agar struktur lagu lebih jelas. Integrasi AI dapat diaktifkan di server.</div>`,
    );
  const b = $("#improve-lyrics");
  b.disabled = true;
  try {
    const data = new FormData();
    data.append(
      "spec",
      JSON.stringify({
        lyrics: draft.lyrics,
        style: draft.style,
        tags: draft.tags,
      }),
    );
    const r = await apiRequest("lyrics", data);
    const result = await r.json();
    if (typeof result.lyrics !== "string" || !result.lyrics.trim())
      throw Error("Lirik AI kosong.");
    modal(
      "A new take on your words.",
      `<p class="muted">Tinjau sebelum mengganti lirikmu.</p><div class="result-lyrics">${esc(result.lyrics)}</div>`,
      `<button class="primary full" id="accept-lyrics">Gunakan versi ini ↗</button>`,
    );
    $("#accept-lyrics").onclick = () => {
      draft.lyrics = result.lyrics.slice(0, 12000);
      persist();
      $("#modal").close();
      render();
    };
  } catch (e) {
    toast(e.message);
  } finally {
    if (b.isConnected) b.disabled = false;
  }
}
// Deterministic local composition: PCM synthesis, no AI inference or cloned vocals.
async function synthesize(spec) {
  const rate = 22050,
    seconds = 24,
    length = rate * seconds;
  const pcm = new Float32Array(length);
  let seed = 2166136261;
  for (const c of spec.story + spec.lyrics + spec.genre + spec.tags.join(""))
    seed = Math.imul(seed ^ c.charCodeAt(0), 16777619);
  const random = () => {
    seed ^= seed << 13;
    seed ^= seed >>> 17;
    seed ^= seed << 5;
    return (seed >>> 0) / 4294967296;
  };
  const dance = /Dance|House|Electronic|Drum/.test(spec.genre),
    jazz = /Jazz|Blues/.test(spec.genre),
    sad = spec.tags.some((x) =>
      ["Sad", "Heartbreak", "Bittersweet"].includes(x),
    );
  const bpm = dance ? 124 : sad ? 78 : jazz ? 88 : 100,
    beat = 60 / bpm;
  const root = [48, 50, 53, 55][Math.floor(random() * 4)],
    scale = sad ? [0, 2, 3, 5, 7, 8, 10] : [0, 2, 4, 5, 7, 9, 11],
    progression = sad ? [0, 5, 3, 6] : [0, 4, 5, 3];
  function note(start, dur, midi, vol, type) {
    let a = Math.floor(start * rate),
      n = Math.min(Math.floor(dur * rate), length - a),
      f = 440 * Math.pow(2, (midi - 69) / 12);
    for (let i = 0; i < n; i++) {
      const t = i / rate,
        p = 2 * Math.PI * f * t;
      let v =
        type === "bass"
          ? Math.sin(p)
          : Math.sin(p) + 0.24 * Math.sin(p * 2) + 0.1 * Math.sin(p * 3);
      const env =
        Math.min(t / 0.015, 1) *
        Math.exp(-t / (dur * 0.36)) *
        Math.min((dur - t) / 0.035, 1);
      pcm[a + i] += v * env * vol;
    }
  }
  for (let bar = 0; bar * beat * 4 < seconds; bar++) {
    const base = root + scale[progression[bar % 4] % 7],
      start = bar * beat * 4;
    for (let j = 0; j < 4; j++) {
      note(start + j * beat, beat * 0.95, base - 12, 0.16, "bass");
      if (dance || j % 2 === 0) {
        const a = Math.floor((start + j * beat) * rate);
        for (let k = 0; k < rate * 0.16 && a + k < length; k++) {
          const t = k / rate;
          pcm[a + k] +=
            Math.sin(2 * Math.PI * (50 * t + 4 * (1 - Math.exp(-t * 30)))) *
            Math.exp(-t * 28) *
            0.23;
        }
      }
    }
    for (let step = 0; step < 8; step++) {
      const tone = base + [0, sad ? 3 : 4, 7, jazz ? 10 : 12][step % 4];
      note(start + (step * beat) / 2, beat * 1.6, tone + 12, 0.075, "keys");
      if (random() > 0.4)
        note(
          start + (step * beat) / 2,
          beat * 0.9,
          root + 24 + scale[Math.floor(random() * 7)],
          0.065,
          "keys",
        );
    }
  }
  let peak = 0.01;
  for (let i = 0; i < length; i++) {
    pcm[i] *= Math.min(i / rate, 1, (length - i) / (rate * 1.8));
    peak = Math.max(peak, Math.abs(pcm[i]));
  }
  const buffer = new ArrayBuffer(44 + length * 2),
    v = new DataView(buffer);
  function str(o, s) {
    for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i));
  }
  str(0, "RIFF");
  v.setUint32(4, 36 + length * 2, true);
  str(8, "WAVEfmt ");
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true);
  v.setUint16(22, 1, true);
  v.setUint32(24, rate, true);
  v.setUint32(28, rate * 2, true);
  v.setUint16(32, 2, true);
  v.setUint16(34, 16, true);
  str(36, "data");
  v.setUint32(40, length * 2, true);
  for (let i = 0; i < length; i++)
    v.setInt16(44 + i * 2, (pcm[i] / peak) * 0.85 * 32767, true);
  return new Blob([buffer], { type: "audio/wav" });
}
function imageCreationOptions() {
  const videos = draft.media.filter((m) => m.file.type.startsWith("video/"));
  modal(
    "Bring your memories to life.",
    `<p class="muted">Pilih bagaimana kamu ingin membuat video.</p><div class="notice">Slideshow lokal mengubah foto menjadi video WebM beranimasi. Ini bukan video generatif AI. ${videos.length ? "Video input perlu backend AI dan tidak disertakan pada slideshow foto." : ""}</div><label class="field-label" for="video-audio">Soundtrack</label><select class="text-input" id="video-audio"><option value="">Tanpa musik</option>${projects
      .filter((p) => p.type !== "video")
      .map((p) => `<option value="${p.id}">${esc(p.title)}</option>`)
      .join(
        "",
      )}</select><p class="muted">Pilih lagu Library sebagai soundtrack, atau buat demo instrumental terlebih dahulu.</p><div class="error" id="video-error" role="alert"></div>`,
    `<button class="primary full" id="local-slideshow">▧ Buat slideshow lokal</button><button class="chip" id="ai-video" style="margin-top:12px">✦ Generate video AI ${caps.video ? "" : "· belum terhubung"}</button>`,
  );
  $("#local-slideshow").onclick = async () => {
    if (!draft.media.some((m) => m.file.type.startsWith("image/"))) {
      $("#video-error").textContent =
        "Slideshow lokal memerlukan setidaknya satu foto.";
      return;
    }
    const b = $("#local-slideshow");
    b.disabled = true;
    $("#close-modal").disabled = true;
    b.textContent = "Memuat foto…";
    busy = true;
    try {
      const audio = projects.find((p) => p.id === $("#video-audio").value);
      const blob = await makeSlideshow(
        draft.media.filter((m) => m.file.type.startsWith("image/")),
        audio?.blob,
        (p) =>
          (b.textContent = `Merekam slideshow ${Math.round(p * 100)}% · biarkan tab terbuka`),
      );
      const p = {
        id: crypto.randomUUID(),
        title: draft.title.trim() || "Our little memories",
        type: "video",
        genre: draft.genre,
        story: draft.story,
        blob,
        created: Date.now(),
        art: 0,
      };
      try {
        await store(p);
      } catch (e) {
        downloadProject(p);
        throw e;
      }
      $("#modal").close();
      state.libraryType = "My Video";
      state.filter = "All";
      go("library");
      toast("Slideshow WebM selesai dan tersimpan.");
    } catch (e) {
      $("#video-error").textContent = e.message;
    } finally {
      busy = false;
      b.disabled = false;
      b.textContent = "▧ Buat slideshow lokal";
      $("#close-modal").disabled = false;
    }
  };
  $("#ai-video").onclick = async () => {
    if (!caps.video) {
      $("#video-error").textContent =
        "Generator video AI belum terhubung. Gunakan slideshow lokal untuk foto.";
      return;
    }
    const b = $("#ai-video");
    b.disabled = true;
    try {
      const r = await apiRequest("video", payload());
      if (!r.headers.get("Content-Type")?.startsWith("video/"))
        throw Error("Gateway video harus mengembalikan WebM.");
      const p = {
        id: crypto.randomUUID(),
        title: draft.title.trim() || "AI memories",
        type: "video",
        origin: "ai",
        genre: draft.genre,
        story: draft.story,
        blob: await r.blob(),
        ...(r.projectMeta || {}),
        created: Date.now(),
        art: 0,
      };
      await store(p);
      $("#modal").close();
      state.libraryType = "My Video";
      go("library");
    } catch (e) {
      $("#video-error").textContent = e.message;
    } finally {
      b.disabled = false;
    }
  };
}
async function makeSlideshow(media, audioBlob, progress) {
  if (!window.MediaRecorder || !HTMLCanvasElement.prototype.captureStream)
    throw Error(
      "Browser ini belum mendukung perekaman slideshow. Gunakan Chrome atau Edge terbaru.",
    );
  const mime = [
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm",
  ].find((m) => MediaRecorder.isTypeSupported(m));
  if (!mime) throw Error("Ekspor WebM tidak didukung browser ini.");
  const images = await Promise.all(
    media.map(
      (m) =>
        new Promise((res, rej) => {
          const image = new Image();
          image.onload = () => res(image);
          image.onerror = () =>
            rej(
              Error(
                "Salah satu foto tidak dapat dibaca. Gunakan JPEG atau PNG.",
              ),
            );
          image.src = m.url;
        }),
    ),
  );
  const canvas = document.createElement("canvas");
  canvas.width = 1280;
  canvas.height = 720;
  const ctx = canvas.getContext("2d");
  const stream = canvas.captureStream(24);
  let ac, src;
  try {
    if (audioBlob) {
      ac = new AudioContext();
      await ac.resume();
      const bytes = await audioBlob.arrayBuffer();
      const decoded = await ac.decodeAudioData(bytes);
      src = ac.createBufferSource();
      src.buffer = decoded;
      src.loop = true;
      const dest = ac.createMediaStreamDestination();
      src.connect(dest);
      dest.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
    }
    const recorder = new MediaRecorder(stream, {
      mimeType: mime,
      videoBitsPerSecond: 3500000,
    });
    const chunks = [];
    const done = new Promise((res, rej) => {
      recorder.ondataavailable = (e) => {
        if (e.data.size) chunks.push(e.data);
      };
      recorder.onstop = () => res(new Blob(chunks, { type: "video/webm" }));
      recorder.onerror = () => rej(Error("Perekaman gagal."));
    });
    const slideDuration = draft.duration * 1000,
      total = slideDuration * images.length;
    const start = performance.now();
    recorder.start(500);
    if (src) src.start();
    await new Promise((res) => {
      function frame(now) {
        const elapsed = now - start,
          index = Math.min(
            images.length - 1,
            Math.floor(elapsed / slideDuration),
          ),
          phase = (elapsed % slideDuration) / slideDuration;
        const img = images[index];
        ctx.fillStyle = "#1e3028";
        ctx.fillRect(0, 0, 1280, 720);
        const zoom = draft.effect === "Ken Burns" ? 1 + phase * 0.1 : 1;
        const scale = Math.max(1280 / img.width, 720 / img.height) * zoom;
        const w = img.width * scale,
          h = img.height * scale;
        ctx.save();
        if (draft.effect === "Fade")
          ctx.globalAlpha = Math.min(1, phase * 5, (1 - phase) * 5);
        ctx.drawImage(
          img,
          (1280 - w) / 2 + (draft.effect === "Slide" ? (phase - 0.5) * 35 : 0),
          (720 - h) / 2,
          w,
          h,
        );
        ctx.restore();
        ctx.fillStyle = "#101c1640";
        ctx.fillRect(0, 570, 1280, 150);
        ctx.fillStyle = "#fff9e9";
        ctx.font = "italic 34px Georgia";
        ctx.fillText(
          (draft.title || "Our little memories").slice(0, 60),
          50,
          640,
        );
        ctx.font = "12px Arial";
        ctx.fillText("K I S A H N A D A  /  PERSONAL MEMORIES", 52, 677);
        progress(Math.min(elapsed / total, 1));
        if (elapsed >= total) {
          recorder.stop();
          res();
        } else requestAnimationFrame(frame);
      }
      requestAnimationFrame(frame);
    });
    return await done;
  } finally {
    if (src)
      try {
        src.stop();
      } catch {}
    stream.getTracks().forEach((t) => t.stop());
    if (ac) await ac.close();
  }
}
window.addEventListener("beforeunload", (e) => {
  if (busy) {
    e.preventDefault();
    e.returnValue = "";
  }
});
init();
