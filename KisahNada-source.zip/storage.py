"""Private, durable accounts, project files and single-use job quotes."""

import hashlib
import hmac
import json
import re
import secrets
import sqlite3
import time
import uuid
from pathlib import Path


class Problem(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


class Storage:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.files = self.root / "files"
        self.files.mkdir(exist_ok=True, mode=0o700)
        self.path = self.root / "studio.sqlite3"
        with self.connect() as db:
            db.executescript(
                """PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,name TEXT UNIQUE NOT NULL,salt BLOB NOT NULL,password BLOB NOT NULL,created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires REAL NOT NULL);
CREATE TABLE IF NOT EXISTS projects(id TEXT NOT NULL,user_id TEXT NOT NULL,metadata TEXT NOT NULL,file TEXT NOT NULL,mime TEXT NOT NULL,size INTEGER NOT NULL,updated REAL NOT NULL,PRIMARY KEY(id,user_id));
CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,kind TEXT NOT NULL,status TEXT NOT NULL,progress TEXT NOT NULL,created REAL NOT NULL,updated REAL NOT NULL,result TEXT,error TEXT,reserved REAL NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS quotes(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,spec_hash TEXT NOT NULL,kind TEXT NOT NULL,amount REAL NOT NULL,created REAL NOT NULL,used INTEGER NOT NULL DEFAULT 0);"""
            )
            db.execute(
                "UPDATE jobs SET status='failed',error='Server dimulai ulang. Job terputus dan tidak dicoba ulang otomatis.',updated=? WHERE status IN ('queued','running')",
                (time.time(),),
            )

    def connect(self):
        db = sqlite3.connect(self.path, timeout=20)
        db.row_factory = sqlite3.Row
        return db

    def account(self, name, password, register=False):
        name = str(name).strip().lower()
        if (
            not re.fullmatch("[a-z0-9_]{3,32}", name)
            or not isinstance(password, str)
            or not 12 <= len(password) <= 200
        ):
            raise Problem(
                "Nama: 3–32 huruf kecil, angka, atau _. Password: 12–200 karakter."
            )
        with self.connect() as db:
            row = db.execute("SELECT * FROM users WHERE name=?", (name,)).fetchone()
            if register:
                if row:
                    raise Problem("Nama akun sudah digunakan.", 409)
                salt = secrets.token_bytes(16)
                digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 600000)
                uid = uuid.uuid4().hex
                db.execute(
                    "INSERT INTO users VALUES (?,?,?,?,?)",
                    (uid, name, salt, digest, time.time()),
                )
            else:
                salt = row["salt"] if row else bytes(16)
                digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 600000)
                if not row or not hmac.compare_digest(digest, row["password"]):
                    raise Problem("Nama akun atau password tidak sesuai.", 401)
                uid = row["id"]
            token = secrets.token_urlsafe(40)
            db.execute("DELETE FROM sessions WHERE expires<?", (time.time(),))
            db.execute(
                "INSERT INTO sessions VALUES (?,?,?)",
                (hashlib.sha256(token.encode()).hexdigest(), uid, time.time() + 604800),
            )
        return {"id": uid, "name": name}, token

    def session(self, token):
        if not token:
            return None
        with self.connect() as db:
            row = db.execute(
                "SELECT users.id,users.name FROM sessions JOIN users ON users.id=sessions.user_id WHERE token=? AND expires>?",
                (hashlib.sha256(token.encode()).hexdigest(), time.time()),
            ).fetchone()
        return dict(row) if row else None

    def logout(self, token):
        with self.connect() as db:
            db.execute(
                "DELETE FROM sessions WHERE token=?",
                (hashlib.sha256(token.encode()).hexdigest(),),
            )

    def project_put(self, uid, meta, data, mime):
        pid = str(meta.get("id", ""))
        if not re.fullmatch("[a-zA-Z0-9_-]{1,80}", pid):
            raise Problem("ID proyek tidak valid.")
        if (
            not data
            or len(data) > 150 * 1024**2
            or not mime.startswith(("audio/", "video/"))
        ):
            raise Problem("Audio/video harus 1 byte sampai 150 MB.")
        meta = {
            k: v
            for k, v in meta.items()
            if k
            in (
                "id",
                "title",
                "genre",
                "vocal",
                "story",
                "lyrics",
                "style",
                "tags",
                "type",
                "created",
                "art",
                "liked",
                "origin",
                "model",
                "generationSeconds",
                "speechNotice",
            )
        }
        if (
            not isinstance(meta.get("title"), str)
            or len(meta["title"]) > 200
            or len(json.dumps(meta)) > 100000
        ):
            raise Problem("Metadata proyek tidak valid.")
        filename = uuid.uuid4().hex
        path = self.files / filename
        path.write_bytes(data)
        old = None
        try:
            with self.connect() as db:
                db.execute("BEGIN IMMEDIATE")
                old = db.execute(
                    "SELECT file,size FROM projects WHERE user_id=? AND id=?",
                    (uid, pid),
                ).fetchone()
                total = db.execute(
                    "SELECT COALESCE(SUM(size),0) FROM projects WHERE user_id=?", (uid,)
                ).fetchone()[0]
                if total - (old["size"] if old else 0) + len(data) > 1024**3:
                    raise Problem("Kuota akun 1 GB penuh.", 413)
                db.execute(
                    "INSERT OR REPLACE INTO projects VALUES (?,?,?,?,?,?,?)",
                    (
                        pid,
                        uid,
                        json.dumps(meta),
                        filename,
                        mime,
                        len(data),
                        time.time(),
                    ),
                )
        except Exception:
            path.unlink(missing_ok=True)
            raise
        if old:
            (self.files / old["file"]).unlink(missing_ok=True)
        return meta

    def projects(self, uid):
        with self.connect() as db:
            rows = db.execute(
                "SELECT metadata,mime,size,updated FROM projects WHERE user_id=? ORDER BY updated DESC",
                (uid,),
            ).fetchall()
        return [
            {
                **json.loads(r["metadata"]),
                "mime": r["mime"],
                "size": r["size"],
                "updated": r["updated"],
            }
            for r in rows
        ]

    def project_file(self, uid, pid):
        with self.connect() as db:
            row = db.execute(
                "SELECT file,mime FROM projects WHERE id=? AND user_id=?", (pid, uid)
            ).fetchone()
        if not row:
            raise Problem("Proyek tidak ditemukan.", 404)
        return (self.files / row["file"]).read_bytes(), row["mime"]

    def project_delete(self, uid, pid):
        with self.connect() as db:
            row = db.execute(
                "SELECT file FROM projects WHERE id=? AND user_id=?", (pid, uid)
            ).fetchone()
            if not row:
                raise Problem("Proyek tidak ditemukan.", 404)
            db.execute("DELETE FROM projects WHERE id=? AND user_id=?", (pid, uid))
        (self.files / row["file"]).unlink(missing_ok=True)

    @staticmethod
    def fingerprint(kind, spec, files):
        h = hashlib.sha256((kind + json.dumps(spec, sort_keys=True)).encode())
        for name, filename, mime, data in files:
            h.update(name.encode())
            h.update(filename.encode())
            h.update(mime.encode())
            h.update(data)
        return h.hexdigest()

    def quote(self, uid, kind, fingerprint, amount):
        qid = uuid.uuid4().hex
        with self.connect() as db:
            db.execute("DELETE FROM quotes WHERE created<?", (time.time() - 3600,))
            db.execute(
                "INSERT INTO quotes VALUES (?,?,?,?,?,?,0)",
                (qid, uid, fingerprint, kind, amount, time.time()),
            )
        return qid

    def create_job(self, uid, kind, fingerprint, quote_id=None, daily_limit=0):
        jid = uuid.uuid4().hex
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            active = db.execute(
                "SELECT COUNT(*) FROM jobs WHERE user_id=? AND status IN ('queued','running')",
                (uid,),
            ).fetchone()[0]
            all_active = db.execute(
                "SELECT COUNT(*) FROM jobs WHERE status IN ('queued','running')"
            ).fetchone()[0]
            if active >= 2 or all_active >= 8:
                raise Problem("Antrean penuh. Tunggu proses yang sedang berjalan.", 429)
            amount = 0
            if quote_id:
                q = db.execute(
                    "SELECT * FROM quotes WHERE id=? AND user_id=?", (quote_id, uid)
                ).fetchone()
                if (
                    not q
                    or q["used"]
                    or q["created"] < time.time() - 600
                    or q["kind"] != kind
                    or q["spec_hash"] != fingerprint
                ):
                    raise Problem(
                        "Quote tidak valid, sudah dipakai, atau input berubah.", 409
                    )
                amount = q["amount"]
                day = int(time.time() // 86400) * 86400
                used = db.execute(
                    "SELECT COALESCE(SUM(reserved),0) FROM jobs WHERE created>=?",
                    (day,),
                ).fetchone()[0]
                if daily_limit <= 0 or used + amount > daily_limit + 1e-9:
                    raise Problem(
                        "Batas anggaran estimasi harian server tercapai.", 402
                    )
                db.execute("UPDATE quotes SET used=1 WHERE id=?", (quote_id,))
            db.execute(
                "INSERT INTO jobs VALUES (?,?,?,?,?,?,?,?,?,?)",
                (
                    jid,
                    uid,
                    kind,
                    "queued",
                    "Menunggu giliran",
                    time.time(),
                    time.time(),
                    None,
                    None,
                    amount,
                ),
            )
        return jid

    def job(self, uid, jid):
        with self.connect() as db:
            row = db.execute(
                "SELECT * FROM jobs WHERE user_id=? AND id=?", (uid, jid)
            ).fetchone()
        if not row:
            raise Problem("Job tidak ditemukan.", 404)
        result = dict(row)
        result["result"] = json.loads(result["result"]) if result["result"] else None
        return result

    def jobs(self, uid):
        with self.connect() as db:
            rows = db.execute(
                "SELECT id FROM jobs WHERE user_id=? ORDER BY created DESC LIMIT 30",
                (uid,),
            ).fetchall()
        return [self.job(uid, row["id"]) for row in rows]

    def claim_job(self, uid, jid):
        with self.connect() as db:
            return (
                db.execute(
                    "UPDATE jobs SET status='running',updated=? WHERE id=? AND user_id=? AND status='queued'",
                    (time.time(), jid, uid),
                ).rowcount
                == 1
            )

    def cancel_job(self, uid, jid):
        with self.connect() as db:
            if (
                db.execute(
                    "UPDATE jobs SET status='cancelled',progress='Dibatalkan',updated=? WHERE user_id=? AND id=? AND status='queued'",
                    (time.time(), uid, jid),
                ).rowcount
                != 1
            ):
                raise Problem("Hanya job yang masih antre bisa dibatalkan.", 409)

    def update_job(self, jid, status, progress="", result=None, error=None):
        with self.connect() as db:
            db.execute(
                "UPDATE jobs SET status=?,progress=?,updated=?,result=?,error=? WHERE id=?",
                (
                    status,
                    progress,
                    time.time(),
                    json.dumps(result) if result is not None else None,
                    error,
                    jid,
                ),
            )
