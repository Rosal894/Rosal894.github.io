/* Persistent server features; provider credentials never enter the browser. */
let account = null,
  currentJob = null,
  accountWaiter = null;
const baseRender = render;
render = function () {
  baseRender();
  enhanceStudio();
};
async function serverFetch(path, options = {}) {
  const r = await fetch(path, { credentials: "same-origin", ...options });
  if (!r.ok) {
    let message = "Server tidak dapat menyelesaikan permintaan.";
    try {
      message = (await r.json()).error || message;
    } catch {}
    throw Error(message);
  }
  return r;
}
function accountHeader() {
  let b = $("#account-button");
  if (!b) {
    b = document.createElement("button");
    b.id = "account-button";
    b.className = "chip";
    $("#settings").before(b);
    b.onclick = accountDialog;
  }
  b.textContent = account ? "◉ " + account.name : "Masuk";
  if ($(".profile b"))
    $(".profile b").textContent = account ? account.name : "Ruang pribadi";
  if ($(".profile small"))
    $(".profile small").textContent = account
      ? "Akun server · sinkronisasi manual"
      : "Tersimpan di perangkat ini";
}
async function loadAccount() {
  try {
    account = (await (await serverFetch("/api/account")).json()).user;
  } catch {}
  accountHeader();
}
function ensureAccount() {
  if (account) return Promise.resolve(true);
  if (!caps.server) {
    toast(
      "Jalankan backend Python untuk menggunakan akun dan pemrosesan server.",
    );
    return Promise.resolve(false);
  }
  accountDialog();
  return new Promise((resolve) => {
    accountWaiter = resolve;
  });
}
function accountDialog() {
  if (account) {
    modal(
      "Your private studio.",
      `<p class="muted">Masuk sebagai <b>${esc(account.name)}</b>. Ini akun instalasi server KisahNada, bukan akun penyedia AI.</p><div class="notice">Karya browser tidak dikirim otomatis. Gunakan ☁ di Library untuk cadangan. Belum ada reset password melalui email.</div><div id="account-error" class="error" role="alert"></div>`,
      `<button class="primary full" id="account-library">Buka Library ↗</button><button class="chip" id="logout" style="margin-top:12px">Keluar</button>`,
    );
    $("#account-library").onclick = () => {
      $("#modal").close();
      go("library");
    };
    $("#logout").onclick = async () => {
      try {
        await serverFetch("/api/account/logout", { method: "POST" });
        account = null;
        accountHeader();
        $("#modal").close();
        toast("Keluar dari server; karya browser tetap ada di perangkat ini.");
      } catch (e) {
        $("#account-error").textContent = e.message;
      }
    };
    return;
  }
  modal(
    "Keep your stories safe.",
    `<p class="muted">Akun pribadi server untuk cadangan dan job. Studio instrumental lokal tetap bisa dipakai tanpa akun.</p><form id="account-form"><label class="field-label" for="account-name">Nama akun</label><input class="text-input" id="account-name" autocomplete="username" pattern="[a-z0-9_]{3,32}" required placeholder="rosal_music"><label class="field-label" for="account-password" style="margin-top:15px">Password</label><input class="text-input" id="account-password" type="password" autocomplete="current-password" minlength="12" maxlength="200" required placeholder="Minimal 12 karakter"><div class="error" id="account-error" role="alert"></div><div class="account-actions"><button class="primary" type="submit" id="login-submit">Masuk ↗</button><button class="chip" type="button" id="register-submit">Buat akun baru</button></div></form><p class="muted">Karya lokal tetap tersimpan setelah keluar. Gunakan perangkat pribadi.</p>`,
  );
  async function submit(register) {
    if (!$("#account-form").reportValidity()) return;
    const buttons = [$("#login-submit"), $("#register-submit")];
    buttons.forEach((b) => (b.disabled = true));
    try {
      const data = await (
        await serverFetch("/api/account/" + (register ? "register" : "login"), {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: $("#account-name").value,
            password: $("#account-password").value,
          }),
        })
      ).json();
      account = data.user;
      accountHeader();
      if (accountWaiter) {
        const resolve = accountWaiter;
        accountWaiter = null;
        resolve(true);
      }
      $("#modal").close();
      enhanceStudio();
      toast("Akun server siap. Sinkronisasi hanya saat dipilih.");
    } catch (e) {
      if ($("#account-error")) $("#account-error").textContent = e.message;
    } finally {
      buttons.forEach((b) => (b.disabled = false));
    }
  }
  $("#account-form").onsubmit = (e) => {
    e.preventDefault();
    submit(false);
  };
  $("#register-submit").onclick = () => submit(true);
  $("#modal").addEventListener(
    "close",
    () => {
      if (accountWaiter) {
        accountWaiter(false);
        accountWaiter = null;
      }
    },
    { once: true },
  );
}
function approvalDialog(quote, kind) {
  return new Promise((resolve) => {
    let decided = false;
    modal(
      "Review before creating.",
      `<div class="eyebrow">PAID AI · USD</div><h3 class="price">$${Number(quote.amount).toFixed(4)}</h3><p class="muted">Estimasi ${esc(kind)} melalui ${esc(quote.provider)}. Batas harian server: $${Number(quote.dailyLimit).toFixed(2)} (UTC).</p><div class="notice">${esc(quote.pricingNote)} Tagihan sebenarnya mengikuti penyedia; tidak ada retry otomatis.</div><label class="mode-note"><input type="checkbox" id="approve-upload"> Saya menyetujui pengiriman input dan estimasi biaya ini.</label>`,
      `<button class="primary full" id="approve-paid">Setujui & proses ↗</button><button class="chip" id="cancel-paid" style="margin-top:12px">Batalkan</button>`,
    );
    $("#approve-paid").onclick = () => {
      if (!$("#approve-upload").checked)
        return toast("Setujui estimasi dan pengiriman terlebih dahulu.");
      decided = true;
      $("#modal").close();
      resolve(true);
    };
    $("#cancel-paid").onclick = () => {
      decided = true;
      $("#modal").close();
      resolve(false);
    };
    $("#modal").addEventListener(
      "close",
      () => {
        if (!decided) resolve(false);
      },
      { once: true },
    );
  });
}
async function startServerJob(kind, body, onProgress = () => {}) {
  if (!(await ensureAccount()))
    throw Error("Masuk akun diperlukan untuk pemrosesan server.");
  const quote = await (
    await serverFetch("/api/quote?kind=" + kind, { method: "POST", body })
  ).json();
  if (quote.quoteId && !(await approvalDialog(quote, kind)))
    throw Error("Dibatalkan. Tidak ada permintaan AI yang dikirim.");
  const job = await (
    await serverFetch("/api/jobs?kind=" + kind, {
      method: "POST",
      body,
      headers: quote.quoteId ? { "X-Quote-ID": quote.quoteId } : {},
    })
  ).json();
  currentJob = job.id;
  localStorage.setItem(
    "kisahnada-active-job",
    JSON.stringify({ id: job.id, user: account.id }),
  );
  return watchJob(job.id, onProgress);
}
async function watchJob(id, onProgress = () => {}) {
  const deadline = Date.now() + 35 * 60 * 1000;
  while (Date.now() < deadline) {
    const job = await (await serverFetch("/api/jobs/" + id)).json();
    onProgress(job.progress || job.status);
    let b = $("#job-status");
    if (!b) {
      b = document.createElement("button");
      b.id = "job-status";
      b.className = "chip job-status";
      $(".topbar").append(b);
      b.onclick = jobsDialog;
    }
    b.textContent = ["succeeded", "failed", "cancelled"].includes(job.status)
      ? "◷ Riwayat"
      : "◌ " + (job.progress || job.status);
    if (["succeeded", "failed", "cancelled"].includes(job.status)) {
      localStorage.removeItem("kisahnada-active-job");
      currentJob = null;
      if (job.status !== "succeeded")
        throw Error(job.error || "Job dibatalkan.");
      return job.result;
    }
    await new Promise((r) => setTimeout(r, 1200));
  }
  throw Error(
    "Pemantauan dihentikan. Periksa riwayat sebelum membuat job baru agar tidak duplikat.",
  );
}
apiRequest = async function (route, body) {
  const result = await startServerJob(route, body);
  if (result.project) {
    const r = await serverFetch("/api/projects/" + result.project.id + "/file");
    r.projectMeta = result.project;
    return r;
  }
  return new Response(JSON.stringify(result), {
    headers: { "Content-Type": "application/json" },
  });
};
async function importServerProject(meta) {
  const blob = await (
    await serverFetch("/api/projects/" + encodeURIComponent(meta.id) + "/file")
  ).blob();
  await store({ ...meta, blob });
}
async function backupProject(p) {
  if (!(await ensureAccount())) return;
  const { blob, ...meta } = p;
  const body = new FormData();
  body.append("metadata", JSON.stringify(meta));
  body.append(
    p.type === "video" ? "media" : "audio",
    blob,
    "project." +
      (blob.type.includes("mp4") ? "mp4" : p.type === "video" ? "webm" : "wav"),
  );
  await serverFetch("/api/projects", { method: "POST", body });
}
async function jobsDialog() {
  if (!(await ensureAccount())) return;
  try {
    const { jobs } = await (await serverFetch("/api/jobs")).json();
    modal(
      "Your creative sessions.",
      `<p class="muted">Job berlangsung di server. Setelah restart, job terputus ditandai gagal dan tidak dicoba ulang otomatis.</p><div class="job-list">${jobs.map((j) => `<article class="job-item"><b>${esc(j.kind)}</b><span class="tag">${esc(j.status)}</span><p>${esc(j.error || j.progress)}</p><small>Reservasi: $${j.reserved.toFixed(4)}</small>${j.status === "succeeded" && (j.result?.project || j.result?.projects) ? `<button class="chip" data-recover="${j.id}">Ambil hasil ↓</button>` : j.status === "succeeded" ? `<button class="chip" data-text-result="${j.id}">Lihat teks</button>` : ["queued", "running"].includes(j.status) ? `<button class="chip" data-watch="${j.id}">Periksa</button>${j.status === "queued" ? `<button class="chip" data-cancel-job="${j.id}">Batalkan antrean</button>` : ""}` : ""}</article>`).join("") || '<p class="muted">Belum ada job.</p>'}</div>`,
    );
    all(
      "[data-recover]",
      (b) =>
        (b.onclick = async () => {
          try {
            const j = jobs.find((x) => x.id === b.dataset.recover);
            for (const p of j.result.projects || [j.result.project])
              await importServerProject(p);
            $("#modal").close();
            go("library");
          } catch (e) {
            toast(e.message);
          }
        }),
    );
    all(
      "[data-text-result]",
      (b) =>
        (b.onclick = () => {
          const j = jobs.find((x) => x.id === b.dataset.textResult);
          modal(
            "Your words.",
            `<div class="result-lyrics">${esc(j.result.lyrics || j.result.story)}</div>`,
          );
        }),
    );
    all("[data-watch]", (b) => (b.onclick = jobsDialog));
    all(
      "[data-cancel-job]",
      (b) =>
        (b.onclick = async () => {
          try {
            await serverFetch("/api/jobs/" + b.dataset.cancelJob + "/cancel", {
              method: "POST",
            });
            jobsDialog();
          } catch (e) {
            toast(e.message);
          }
        }),
    );
  } catch (e) {
    toast(e.message);
  }
}
async function serverLibrary() {
  if (!(await ensureAccount())) return;
  try {
    const { projects: remote } = await (
      await serverFetch("/api/projects")
    ).json();
    modal(
      "Backed up, with care.",
      `<p class="muted">Cadangan akun ${esc(account.name)} di server ini. Kuota 1 GB/akun; gunakan disk persisten dan backup rutin.</p><div class="library-list">${remote.map((p) => `<article class="job-item"><b>${esc(p.title)}</b><small>${(p.size / 1024 / 1024).toFixed(1)} MB · ${esc(p.type)}</small><div class="chip-row"><button class="chip" data-import="${p.id}">Ambil ke browser ↓</button><button class="chip" data-server-delete="${p.id}">Hapus dari server</button></div></article>`).join("") || '<p class="muted">Belum ada cadangan.</p>'}</div>`,
    );
    all(
      "[data-import]",
      (b) =>
        (b.onclick = async () => {
          b.disabled = true;
          try {
            await importServerProject(
              remote.find((p) => p.id === b.dataset.import),
            );
            $("#modal").close();
            go("library");
            toast("Karya diambil ke browser.");
          } catch (e) {
            toast(e.message);
          } finally {
            b.disabled = false;
          }
        }),
    );
    all(
      "[data-server-delete]",
      (b) =>
        (b.onclick = () => {
          modal(
            "Hapus cadangan server?",
            '<p class="muted">Salinan browser tidak terhapus. Tindakan ini tidak dapat dibatalkan.</p>',
            '<button class="primary full" id="confirm-server-delete">Hapus cadangan</button>',
          );
          $("#confirm-server-delete").onclick = async () => {
            try {
              await serverFetch("/api/projects/" + b.dataset.serverDelete, {
                method: "DELETE",
              });
              serverLibrary();
            } catch (e) {
              toast(e.message);
            }
          };
        }),
    );
  } catch (e) {
    toast(e.message);
  }
}
function toolDialog(kind) {
  const info = {
    glow: [
      "Vocal Glow Up",
      "Pembersihan noise, EQ, kompresi, normalisasi FFmpeg lokal. Bukan kloning atau model AI.",
    ],
    "local-remix": [
      "Remix lokal",
      "Efek EQ, echo, kompresi/tempo. Bukan aransemen ulang AI.",
    ],
    hum: [
      "Hum to song",
      "Memerlukan model pada gateway; belum tersedia dalam mode gratis.",
    ],
    split: [
      "Voc / Inst Split",
      "Pemisahan vokal/instrumen memerlukan model AI berlisensi. API berbayar diblokir dalam mode gratis.",
    ],
  }[kind];
  modal(
    info[0],
    `<p class="muted">${info[1]}</p><label class="upload-zone"><span class="upload-icon">♫</span><b>Pilih audio milikmu</b><input type="file" id="tool-audio" accept="audio/*"><small>50 MB · maksimal 10 menit</small></label>${kind === "local-remix" ? `<select id="tool-remix-style" class="text-input" style="margin-top:12px">${["Late night", "Synth", "Rock", "Mellow", "Other"].map((x) => `<option>${x}</option>`).join("")}</select>` : ""}<div class="error" id="tool-error" role="alert"></div>`,
    '<button class="primary full" id="process-tool">Proses audio ↗</button>',
  );
  let file = null;
  $("#tool-audio").onchange = (e) => (file = e.target.files[0]);
  $("#process-tool").onclick = async () => {
    if (
      !file ||
      !file.type.startsWith("audio/") ||
      file.size > 50 * 1024 ** 2
    ) {
      $("#tool-error").textContent = "Pilih audio valid maksimal 50 MB.";
      return;
    }
    const b = $("#process-tool");
    b.disabled = true;
    const body = new FormData();
    body.append(
      "spec",
      JSON.stringify({
        title: file.name.replace(/\.[^.]+$/, "") + " · " + info[0],
        remix: $("#tool-remix-style")?.value || "Mellow",
      }),
    );
    body.append("audio", file);
    try {
      const result = await startServerJob(kind, body, (text) => {
        if (b.isConnected) b.textContent = text;
      });
      for (const p of result.projects || [result.project])
        await importServerProject(p);
      $("#modal").close();
      go("library");
      toast("Hasil tersimpan di server dan browser.");
    } catch (e) {
      if ($("#tool-error")) $("#tool-error").textContent = e.message;
      else toast(e.message);
    } finally {
      b.disabled = false;
      b.textContent = "Proses audio ↗";
    }
  };
}
const originalTool = tool;
tool = function (id) {
  if (["glow", "hum", "split"].includes(id)) return toolDialog(id);
  originalTool(id);
};
async function photoStory() {
  if (!draft.media.length) return toast("Tambahkan foto terlebih dahulu.");
  const b = $("#photo-story");
  b.disabled = true;
  const body = new FormData();
  body.append(
    "spec",
    JSON.stringify({
      story: draft.story,
      style: draft.style,
      tags: draft.tags,
    }),
  );
  draft.media
    .filter((m) => m.file.type.startsWith("image/"))
    .slice(0, 5)
    .forEach((m) => body.append("media", m.file));
  try {
    const result = await startServerJob("story", body);
    modal(
      "A story in your moments.",
      `<p class="muted">Interpretasi AI perlu ditinjau; bukan fakta terverifikasi.</p><div class="result-lyrics">${esc(result.story)}</div>`,
      '<button class="primary full" id="use-photo-story">Gunakan cerita untuk lagu ↗</button>',
    );
    $("#use-photo-story").onclick = () => {
      draft.story = result.story.split(/\s+/).slice(0, 500).join(" ");
      draft.mode = "description";
      persist();
      $("#modal").close();
      render();
    };
  } catch (e) {
    toast(e.message);
  } finally {
    b.disabled = false;
  }
}
function enhanceStudio() {
  accountHeader();
  if (!$("#app").children.length) return;
  if (state.page === "library" && !$("#server-library")) {
    const bar = document.createElement("div");
    bar.className = "chip-row";
    bar.innerHTML =
      '<button class="chip" id="server-library">☁ Cadangan server</button><button class="chip" id="job-history">◷ Riwayat proses</button>';
    $(".editor-tabs").after(bar);
    $("#server-library").onclick = serverLibrary;
    $("#job-history").onclick = jobsDialog;
    all(".library-row", (row) => {
      const id = row.querySelector("[data-detail]").dataset.detail,
        b = document.createElement("button");
      b.textContent = "☁";
      b.setAttribute("aria-label", "Simpan ke server");
      b.onclick = async () => {
        b.disabled = true;
        try {
          await backupProject(projects.find((p) => p.id === id));
          toast("Cadangan tersimpan di akun server.");
        } catch (e) {
          toast(e.message);
        } finally {
          b.disabled = false;
        }
      };
      row.querySelector(".library-actions").append(b);
    });
    const note = $(".shell main>.notice");
    if (note)
      note.textContent =
        "Karya lokal tetap di browser. Gunakan ☁ untuk cadangan server atau unduh file. Menghapus data browser tidak menghapus cadangan server.";
  }
  if (
    state.page === "song" &&
    ["description", "lyrics"].includes(draft.mode) &&
    !$("#song-duration")
  ) {
    const field = document.createElement("div");
    field.className = "duration-field";
    field.innerHTML = `<label class="field-label" for="song-duration">Durasi lagu AI</label><select id="song-duration" class="text-input">${[30, 60, 120].map((n) => `<option value="${n}" ${(draft.songSeconds || 30) === n ? "selected" : ""}>${n} detik</option>`).join("")}</select><small class="muted">Biaya API ditinjau sebelum digunakan; mode gratis tidak memakai API.</small>`;
    $(".create-area").prepend(field);
    $("#song-duration").onchange = (e) => {
      draft.songSeconds = +e.target.value;
      persist();
    };
  }
  if (state.page === "song" && draft.mode === "image" && !$("#photo-story")) {
    const b = document.createElement("button");
    b.id = "photo-story";
    b.className = "chip";
    b.textContent = "✧ Ceritakan foto dengan AI";
    b.onclick = photoStory;
    $(".media-grid").after(b);
  }
  if (
    state.page === "song" &&
    draft.mode === "remix" &&
    !$("#local-remix-button")
  ) {
    const b = document.createElement("button");
    b.id = "local-remix-button";
    b.className = "chip";
    b.textContent = "≋ Coba efek remix lokal";
    b.onclick = () => toolDialog("local-remix");
    $(".create-area").prepend(b);
  }
}
function enhanceVideoDialog() {
  const b = document.createElement("button");
  b.id = "server-video";
  b.className = "primary full";
  b.style.marginTop = "12px";
  b.textContent = "▧ Render foto & klip di server";
  $("#local-slideshow").after(b);
  const note = document.createElement("p");
  note.className = "muted";
  note.textContent =
    "Renderer lokal menerima JPEG/PNG/WebP dan klip video, efek serta soundtrack. Bukan video generatif AI.";
  b.after(note);
  b.onclick = async () => {
    const audio = projects.find((p) => p.id === $("#video-audio").value),
      data = new FormData();
    data.append(
      "spec",
      JSON.stringify({
        title: draft.title || "Our little memories",
        duration: draft.duration,
        effect: draft.effect,
        genre: draft.genre,
        story: draft.story,
      }),
    );
    draft.media.forEach((m) => data.append("media", m.file));
    if (audio) data.append("audio", audio.blob, "soundtrack.wav");
    b.disabled = true;
    try {
      const result = await startServerJob("slideshow", data, (text) => {
        if (b.isConnected) b.textContent = text;
      });
      await importServerProject(result.project);
      $("#modal").close();
      state.libraryType = "My Video";
      state.filter = "All";
      go("library");
      toast("Video foto & klip tersimpan di server.");
    } catch (e) {
      if ($("#video-error")) $("#video-error").textContent = e.message;
      else toast(e.message);
    } finally {
      b.disabled = false;
      b.textContent = "▧ Render foto & klip di server";
    }
  };
}
const baseImageOptions = imageCreationOptions;
imageCreationOptions = function () {
  baseImageOptions();
  enhanceVideoDialog();
};
async function restoreJobNotice() {
  try {
    const r = JSON.parse(
      localStorage.getItem("kisahnada-active-job") || "null",
    );
    if (r && account && r.user === account.id) {
      const b = document.createElement("button");
      b.className = "chip";
      b.textContent = "◷ Periksa proses sebelumnya";
      b.onclick = jobsDialog;
      $(".topbar").append(b);
    }
  } catch {}
}
loadAccount().then(restoreJobNotice);
if ($("#app").children.length) enhanceStudio();
