const { chromium } = require("playwright");
const assert = require("node:assert/strict");
(async () => {
  const browser = await chromium.launch({
    executablePath: "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1100 },
  });
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("http://127.0.0.1:8001");
  await page.locator("#story").waitFor();
  await page.screenshot({ path: "/tmp/kisahnada-desktop.png", fullPage: true });
  await page.locator("#story").fill("kata ".repeat(501));
  assert.equal(
    await page.locator("#word-count").textContent(),
    "500 / 500 kata",
  );
  await page
    .locator("#story")
    .fill("Tentang rumah kecil dan cinta yang selalu tumbuh bersama.");
  await page.locator("#song-title").fill("Rumah Kita");
  await page.reload();
  await page.locator("#story").waitFor();
  assert.equal(await page.locator("#song-title").inputValue(), "Rumah Kita");
  await page.locator("#genre-picker").click();
  await page.locator('[data-genre="Folk"]').click();
  await page.locator("#apply-genre").click();
  assert.match(await page.locator("#genre-picker").textContent(), /Folk/);
  await page.locator(".style-section summary").click();
  for (const tag of [
    "Love",
    "Happy",
    "Heartbreak",
    "Encourage",
    "Sad",
    "Angry",
    "Funny",
    "Passion",
    "Respect",
    "Bittersweet",
    "Pop",
  ])
    await page
      .locator(
        `.style-section .chip-row:not(#selected-tags) [data-tag="${tag}"]`,
      )
      .click();
  assert.equal(await page.evaluate(() => draft.tags.length), 10);
  await page.locator("#create-instrumental").click();
  await page.locator(".library-row").waitFor();
  assert.match(await page.locator(".library-row").textContent(), /Rumah Kita/);
  assert.match(
    await page.locator(".library-row").textContent(),
    /Demo instrumental lokal/,
  );
  const wav = await page.evaluate(async () => {
    const b = projects[0].blob;
    const d = new DataView(await b.arrayBuffer());
    return {
      size: b.size,
      header: String.fromCharCode(
        ...new Uint8Array(await b.slice(0, 4).arrayBuffer()),
      ),
      rate: d.getUint32(24, true),
      frames: d.getUint32(40, true) / 2,
    };
  });
  assert.equal(wav.header, "RIFF");
  assert.equal(wav.frames / wav.rate, 24);
  assert(wav.size > 1000000);
  await page.locator("[data-like]").click();
  await page.locator('[data-filter="Liked"]').click();
  assert.equal(await page.locator(".library-row").count(), 1);
  const [download] = await Promise.all([
    page.waitForEvent("download"),
    page.locator("[data-download]").click(),
  ]);
  assert.equal(download.suggestedFilename(), "Rumah Kita.wav");
  await page.reload();
  await page.locator(".library-row").waitFor();
  assert.equal(await page.locator(".library-row").count(), 1);
  await page.locator('#nav [data-page="cover"]').click();
  await page.locator("[data-free-preview]").first().waitFor();
  assert.equal(await page.locator(".free-voice-grid .voice-tile").count(), 5);
  await page.locator("[data-free-preview]").first().click();
  await page.locator("#modal audio").waitFor();
  await page.waitForFunction(
    () => document.querySelector("#modal audio")?.readyState >= 1,
  );
  await page.locator("#close-modal").click();
  await page.locator('#nav [data-page="workspace"]').click();
  await page.locator("#template-search").fill("City");
  assert.equal(await page.locator(".gallery-card").count(), 1);
  await page.locator(".gallery-card").click();
  assert(await page.locator("#story").inputValue());
  await page.locator('[data-mode="lyrics"]').click();
  await page.locator("#lyrics").fill("[Verse]\nKita bersama selamanya");
  assert.match(
    await page.locator("#improve-lyrics").textContent(),
    /template gratis/,
  );
  assert(await page.locator("#local-ai-lyrics").isDisabled());
  assert(await page.locator("#create-song").isDisabled());
  await page.locator('[data-mode="image"]').click();
  const svg = await page.request.get(
    "http://127.0.0.1:8001/assets/cover-0.svg",
  );
  await page.locator("#media-upload").setInputFiles({
    name: "memory.svg",
    mimeType: "image/svg+xml",
    buffer: await svg.body(),
  });
  assert.equal(await page.locator(".media-item").count(), 1);
  await page.locator("#duration").selectOption("3");
  await page.locator("#create-song").click();
  await page.locator("#video-audio").selectOption({ index: 1 });
  await page.locator("#local-slideshow").click();
  try {
    await page.locator(".library-row").waitFor({ timeout: 20000 });
  } catch (error) {
    console.error("Slideshow diagnostics", await page.evaluate(() => ({page:state.page, mode:draft.mode, busy, error:document.querySelector('#video-error')?.textContent, recorder:document.querySelector('#local-slideshow')?.textContent})), errors);
    throw error;
  }
  assert.match(
    await page.locator(".library-row").textContent(),
    /Slideshow lokal/,
  );
  const video = await page.evaluate(async () => {
    const p = projects.find((p) => p.type === "video");
    const v = document.createElement("video");
    v.src = URL.createObjectURL(p.blob);
    await new Promise((r, j) => {
      v.onloadedmetadata = r;
      v.onerror = j;
    });
    return { size: p.blob.size, width: v.videoWidth, height: v.videoHeight };
  });
  assert(video.size > 10000);
  assert.equal(video.width, 1280);
  assert.equal(video.height, 720);
  await page.locator('#nav [data-page="explore"]').click();
  assert.equal(await page.locator(".tool-card").count(), 7);
  await page.locator('[data-tool="hum"]').click();
  assert.match(
    await page.locator("#modal-content").textContent(),
    /belum tersedia/,
  );
  await page.locator("#close-modal").click();
  await page.setViewportSize({ width: 390, height: 844 });
  await page.locator('#mobile-nav [data-page="song"]').click();
  await page.locator('[data-mode="description"]').click();
  assert.equal(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
    true,
  );
  await page.screenshot({ path: "/tmp/kisahnada-mobile.png", fullPage: true });
  assert.deepEqual(errors, []);
  console.log(
    "PASS: desktop/mobile navigation, word and tag limits, persistent draft, WAV synthesis, library persistence/like/download, native free voice preview, templates/search, missing-model lyric/singing guards, uploaded-photo slideshow with soundtrack and WebM decoding. No browser exceptions.",
  );
  await browser.close();
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
