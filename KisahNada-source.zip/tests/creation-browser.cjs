const {chromium} = require("playwright");
const assert = require("node:assert/strict");
const {spawn} = require("node:child_process");
const fs = require("node:fs"), os = require("node:os"), path = require("node:path");
(async () => {
  const root = path.resolve(__dirname, ".."), data = fs.mkdtempSync(path.join(os.tmpdir(), "kisahnada-create-"));
  const child = spawn(path.join(root, ".venv/bin/python"), ["server.py"], {cwd: root, env: {...process.env, PORT: "8004", KISAHNADA_DATA_DIR: data, KISAHNADA_FREE_ONLY: "1", KISAHNADA_GROQ_KEY: "", GROQ_API_KEY: "", KISAHNADA_GROQ_FREE_PLAN_CONFIRMED: "0"}, stdio: "ignore"});
  let browser;
  try {
    for (let i = 0; i < 100; i++) {
      try { if ((await fetch("http://127.0.0.1:8004/api/capabilities")).ok) break; } catch {}
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    browser = await chromium.launch({executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox", "--disable-dev-shm-usage"]});
    const page = await browser.newPage({viewport: {width: 1440, height: 1100}, colorScheme: "dark"}), errors = [];
    page.on("pageerror", error => errors.push(error.message));
    await page.goto("http://127.0.0.1:8004");
    await page.locator(".creation-workspace").waitFor();
    await page.waitForFunction(() => caps.server && !!db);
    assert.equal(await page.locator(".studio-song").count(), 0);
    assert(await page.locator("#create-song").isDisabled());
    await page.screenshot({path: "/workspace/artifacts/KisahNada-Studio-v0.3-dark.png", fullPage: true});
    await page.locator("#theme-toggle").click();
    await page.screenshot({path: "/workspace/artifacts/KisahNada-Studio-v0.3-light.png", fullPage: true});
    await page.locator('[data-creator-idea="1"]').click();
    assert.match(await page.locator("#story").inputValue(), /keraguan/);
    assert.match(await page.locator("#genre-picker").textContent(), /Rock/);
    await page.evaluate(async () => {
      const blob = await synthesize({...draft, genre: "Pop"});
      for (const [i, title] of ["Demo Hujan", "Demo Senja"].entries()) await store({id: "studio-test-" + i, title, genre: "Pop", type: "demo", blob, liked: false, created: Date.now() - i});
      render();
    });
    assert.equal(await page.locator(".studio-song").count(), 2);
    assert.match(await page.locator(".studio-song").first().textContent(), /Demo instrumental/);
    await page.locator("#studio-search").fill("Hujan");
    assert.equal(await page.locator(".studio-song").count(), 1);
    await page.locator(".studio-song [data-like]").click();
    await page.locator("#studio-search").fill("");
    await page.locator('[data-studio-filter="liked"]').click();
    assert.equal(await page.locator(".studio-song").count(), 1);
    const [download] = await Promise.all([page.waitForEvent("download"), page.locator(".studio-song [data-download]").click()]);
    assert.equal(download.suggestedFilename(), "Demo Hujan.wav");
    await page.evaluate(() => {
      window.testCreateCalls = [];
      caps.localSinging = true; caps.groqLyrics = true;
      draft.story = "Kami bertemu di Bandung."; draft.lyrics = ""; draft.mode = "description";
      startServerJob = async kind => { testCreateCalls.push(kind); return {lyrics: "[Verse]\nDi Bandung kita bertemu", origin: "groq"}; };
      createLocalSinging = async () => { testCreateCalls.push({singingLyrics: draft.lyrics}); };
      render();
    });
    await page.locator("#create-song").click();
    await page.locator("#story-lyric-review").waitFor();
    assert.equal(await page.evaluate(() => draft.lyrics), "");
    await page.locator("#close-modal").click();
    assert.deepEqual(await page.evaluate(() => testCreateCalls), ["groq-lyrics"]);
    assert.equal(await page.locator("#create-song").count(), 1);
    assert.equal(await page.evaluate(() => projects.length), 2);
    await page.locator("#create-song").click();
    await page.locator("#story-lyric-review").fill("[Verse]\nLirik yang saya sunting sendiri");
    await page.locator("#accept-story-song").click();
    assert.deepEqual((await page.evaluate(() => testCreateCalls)).at(-1), {singingLyrics: "[Verse]\nLirik yang saya sunting sendiri"});
    await page.evaluate(() => { draft.mode = "description"; render(); });
    await page.locator("#create-song").click();
    await page.evaluate(() => { draft.story = "Cerita baru yang berbeda"; });
    const count = await page.evaluate(() => testCreateCalls.length);
    await page.locator("#accept-story-song").click();
    assert.match(await page.locator("#story-lyric-error").textContent(), /berubah/);
    assert.equal(await page.evaluate(() => testCreateCalls.length), count);
    await page.locator("#close-modal").click();
    await page.evaluate(() => { draft.lyrics = ""; startServerJob = async kind => { testCreateCalls.push(kind); throw Error("Kuota uji habis"); }; render(); });
    await page.locator("#create-song").click();
    await page.locator("#creation-error").filter({hasText: "Kuota uji habis"}).waitFor();
    assert.equal((await page.evaluate(() => testCreateCalls)).at(-1), "groq-lyrics");
    assert.equal(await page.evaluate(() => draft.lyrics), "");
    const beforeUnsupportedVoice = await page.evaluate(() => testCreateCalls.length);
    await page.evaluate(() => { draft.vocal = "My Voice"; render(); });
    await page.locator("#create-song").click();
    assert.match(await page.locator("#toast").textContent(), /Kloning suara belum didukung/);
    assert.equal(await page.evaluate(() => testCreateCalls.length), beforeUnsupportedVoice);
    await page.evaluate(() => { draft.vocal = "Random"; });
    await page.evaluate(() => { caps.groqLyrics = false; caps.localLyrics = false; render(); });
    await page.locator("#create-song").click();
    await page.locator("#write-story-lyrics").click();
    assert(await page.locator("#lyrics").isVisible());
    await page.setViewportSize({width: 390, height: 844});
    await page.locator('[data-mode="description"]').click();
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    assert.deepEqual(errors, []);
    console.log("PASS: creation layout, themes, real demo Library/search/like/download, lyric review/cancel/edit, changed-story guard, quota failure without fallback, mobile layout. AI provider/singing flow uses mocks only.");
  } finally {
    await browser?.close(); child.kill("SIGTERM");
    await new Promise(resolve => child.exitCode !== null ? resolve() : child.once("exit", resolve));
    fs.rmSync(data, {recursive:true,force:true});
  }
})().catch(error => { console.error(error); process.exit(1); });
