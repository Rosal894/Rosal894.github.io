"""Free-plan guards and real adapter protocol, without contacting a paid service."""
import io
import json
import os
import sys
import unittest
import urllib.error
from email.message import Message
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lyrics_provider import ENDPOINT, NoRedirect, capabilities, generate_lyrics
from storage import Problem
from test_server import Client
from server import StudioServer
import tempfile
import threading


class GroqTest(unittest.TestCase):
    def setUp(self):
        self.env = patch.dict(os.environ, {
            "KISAHNADA_GROQ_KEY": "unit-test-key",
            "GROQ_API_KEY": "",
            "KISAHNADA_GROQ_FREE_PLAN_CONFIRMED": "1",
            "KISAHNADA_GROQ_MODEL": "llama-3.3-70b-versatile",
        })
        self.env.start()
        self.addCleanup(self.env.stop)
        self.transport = patch("lyrics_provider.urllib.request.build_opener")
        self.open = self.transport.start().return_value.open
        self.addCleanup(self.transport.stop)
        self.reply({"choices": [{"message": {"content": "[Verse]\nDi Bandung kita bertemu"}, "finish_reason": "stop"}]})

    def reply(self, obj):
        response = MagicMock()
        response.read.return_value = json.dumps(obj).encode()
        response.headers = Message()
        response.headers["Content-Type"] = "application/json"
        self.open.return_value.__enter__.return_value = response
        return response

    def test_missing_key_or_plan_never_dispatches(self):
        for key, confirmed in [("", "1"), ("unit-test-key", "0")]:
            with self.subTest(key_present=bool(key)), patch.dict(os.environ, {
                "KISAHNADA_GROQ_KEY": key,
                "KISAHNADA_GROQ_FREE_PLAN_CONFIRMED": confirmed,
            }):
                with self.assertRaises(Problem) as error:
                    generate_lyrics({"story": "Bandung"})
                self.assertEqual(error.exception.status, 503)
                self.assertFalse(capabilities()["groqLyrics"])
        self.open.assert_not_called()

    def test_protocol_and_provenance_without_secret_disclosure(self):
        result = generate_lyrics({"story": "Bandung", "tags": ["Love", "Pop"]})
        self.assertEqual(result["origin"], "groq")
        self.assertIn("Bandung", result["lyrics"])
        request = self.open.call_args.args[0]
        self.assertEqual(request.full_url, ENDPOINT)
        self.assertEqual(request.get_header("Authorization"), "Bearer unit-test-key")
        payload = json.loads(request.data)
        self.assertEqual(payload["model"], "llama-3.3-70b-versatile")
        self.assertFalse(payload["stream"])
        self.assertEqual(json.loads(payload["messages"][1]["content"])["story"], "Bandung")
        self.assertNotIn("unit-test-key", json.dumps(result) + json.dumps(capabilities()))
        self.open.assert_called_once()

    def test_quota_payment_auth_and_network_failures_are_not_retried(self):
        for code in (401, 402, 403, 429):
            with self.subTest(code=code):
                self.open.reset_mock()
                self.open.side_effect = urllib.error.HTTPError(ENDPOINT, code, "unit-test-key", {}, io.BytesIO(b"unit-test-key"))
                with self.assertRaises(Problem) as error:
                    generate_lyrics({"story": "Bandung"})
                self.assertEqual(error.exception.status, 429 if code == 429 else 502)
                self.assertNotIn("unit-test-key", str(error.exception))
                self.open.assert_called_once()
        self.open.reset_mock()
        self.open.side_effect = urllib.error.URLError("unit-test-key")
        with self.assertRaises(Problem) as error:
            generate_lyrics({"story": "Bandung"})
        self.assertNotIn("unit-test-key", str(error.exception))
        self.open.assert_called_once()

    def test_invalid_or_truncated_response_is_not_accepted(self):
        for result in ({}, {"choices": []}, {"choices": [{"message": {"content": 7}}]}, {"choices": [{"message": {"content": "x"}, "finish_reason": "length"}]}, {"choices": [{"message": {"content": "x" * 4097}}]}):
            with self.subTest(result_type=str(result)[:50]):
                self.reply(result)
                with self.assertRaises(Problem):
                    generate_lyrics({"story": "Bandung"})
        response = self.reply({})
        response.read.return_value = b"x" * (1024 * 1024 + 1)
        with self.assertRaises(Problem):
            generate_lyrics({"story": "Bandung"})

    def test_invalid_inputs_and_redirects_never_dispatch(self):
        for spec in ({"story": "word " * 501}, {"lyrics": "x" * 12001}, {"story": "Hi", "tags": ["x"] * 11}, {}):
            with self.assertRaises(Problem):
                generate_lyrics(spec)
        self.open.assert_not_called()
        with self.assertRaises(Problem):
            NoRedirect().redirect_request(None, None, None, None, None, "https://other.example")

    def test_free_server_route_and_truthful_quote(self):
        self.transport.stop()  # The localhost test client needs the real opener.
        with tempfile.TemporaryDirectory() as directory:
            server = StudioServer(("127.0.0.1", 0), directory)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                client = Client(f"http://127.0.0.1:{server.server_port}")
                client.json("/api/account/register", {"name": "groq_test", "password": "private test password"})
                quote = client.form("/api/quote?kind=groq-lyrics", {"story": "Bandung"})
                self.assertIn("Groq", quote["provider"])
                self.assertIsNone(quote["quoteId"])
                self.assertNotIn("lokal", quote["provider"])
                self.open.assert_not_called()
                with patch.dict(os.environ, {"KISAHNADA_GROQ_FREE_PLAN_CONFIRMED": "0"}):
                    with self.assertRaises(urllib.error.HTTPError) as error:
                        client.form("/api/jobs?kind=groq-lyrics", {"story": "Bandung"})
                    self.assertEqual(error.exception.code, 503)
            finally:
                server.shutdown()
                server.server_close()
                thread.join()
