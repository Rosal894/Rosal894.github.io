import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import song_engine
from storage import Problem


class SingingTest(unittest.TestCase):
    def test_request_targets_actual_sung_lyrics(self):
        spec = {
            "lyrics": "[Verse]\nDi sini kita bersama",
            "vocal": "Female",
            "genre": "Pop",
            "tags": ["Love"],
            "songSeconds": 30,
        }
        r = song_engine.compose_request(spec)
        self.assertEqual(r["lyrics"], spec["lyrics"])
        self.assertIn("Indonesian", r["caption"])
        self.assertIn("female", r["caption"])
        self.assertFalse(r["instrumental"])
        self.assertEqual(r["seconds"], 30)

    def test_missing_checkpoints_does_not_return_narration(self):
        with patch("song_engine.singing_files_available", return_value=False):
            with self.assertRaises(Problem) as e:
                song_engine.generate_singing(
                    {"lyrics": "Lirik kita", "vocal": "Male"}, lambda _: None
                )
            self.assertEqual(e.exception.status, 503)

    def test_input_limits_and_unsupported_cloning(self):
        for spec in [
            {"story": "Only story"},
            {"lyrics": "x" * 4097},
            {"lyrics": "test", "songSeconds": 600},
            {"lyrics": "test", "vocal": "My Voice"},
        ]:
            with self.assertRaises(Problem):
                song_engine.compose_request(spec)

    def test_checkpoint_marker_requires_real_files_and_sizes(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            python = root / "python"
            python.touch()
            checkpoints = root / "checkpoints"
            checkpoints.mkdir()
            with patch.object(song_engine, "CHECKPOINTS", checkpoints), patch.object(
                song_engine, "PYTHON", python
            ):
                self.assertFalse(song_engine.singing_files_available())
                files = []
                for folder in song_engine.REQUIRED:
                    p = checkpoints / folder / "model.safetensors"
                    p.parent.mkdir()
                    p.write_bytes(b"test fixture, not a real model")
                    files.append(
                        {
                            "path": folder + "/model.safetensors",
                            "size": p.stat().st_size,
                        }
                    )
                (checkpoints / "verified-model.json").write_text(
                    json.dumps({"repository": "ACE-Step/Ace-Step1.5", "files": files})
                )
                self.assertTrue(song_engine.singing_files_available())
                runtime_marker = root / "setup-ready.json"
                with patch.dict("os.environ", {"KISAHNADA_SONG_RUNTIME_MARKER": str(runtime_marker)}):
                    self.assertFalse(song_engine.singing_files_available())
                (checkpoints / files[0]["path"]).write_bytes(b"truncated")
                self.assertFalse(song_engine.singing_files_available())

    def test_cpu_inference_api_imports_real_runtime(self):
        result = subprocess.run(
            [
                str(song_engine.PYTHON),
                "-c",
                'import torch; from acestep.handler import AceStepHandler; from acestep.inference import GenerationParams,GenerationConfig,generate_music; assert not torch.cuda.is_available(); p=GenerationParams(vocal_language="id",thinking=False); assert p.vocal_language=="id"; print("CPU API imports OK; singing inference not tested")',
            ],
            capture_output=True,
            timeout=90,
        )
        self.assertEqual(result.returncode, 0, result.stderr.decode()[-1000:])
        self.assertIn(b"CPU API imports OK", result.stdout)
