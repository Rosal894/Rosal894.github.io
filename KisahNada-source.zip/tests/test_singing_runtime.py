import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from singing_runtime import require_worker_python, runtime_marker_valid, SOURCE_COMMIT, SOURCE_SHA256
from desktop_setup import SongInstaller


class SingingRuntimeTest(unittest.TestCase):
    def test_requires_python312_and_rejects_previous_python313_bundle(self):
        for version, accepted in [([3, 12], True), ([3, 13], False), ([3, 14], False)]:
            with self.subTest(version=version), patch("singing_runtime.subprocess.run", return_value=subprocess.CompletedProcess([], 0, json.dumps(version))):
                if accepted:
                    self.assertEqual(require_worker_python("worker.exe"), version)
                else:
                    with self.assertRaises(RuntimeError):
                        require_worker_python("worker.exe")

    def test_probe_checks_actual_child_interpreter_version(self):
        if sys.version_info[:2] == (3, 12):
            self.assertEqual(require_worker_python(sys.executable), [3, 12])
        else:
            with self.assertRaises(RuntimeError):
                require_worker_python(sys.executable)

    def test_runtime_marker_rejects_partial_or_incompatible_install(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "setup-ready.json"
            self.assertFalse(runtime_marker_valid(path))
            marker = {"protocol": 1, "python": [3, 12], "source_commit": SOURCE_COMMIT, "source_sha256": SOURCE_SHA256, "cpu_imports_verified": True}
            path.write_text(json.dumps(marker))
            self.assertTrue(runtime_marker_valid(path))
            for key, wrong in [("python", [3, 13]), ("cpu_imports_verified", False), ("source_sha256", "wrong")]:
                path.write_text(json.dumps({**marker, key: wrong}))
                self.assertFalse(runtime_marker_valid(path))

    def test_installed_model_status_survives_server_restart(self):
        installer = SongInstaller()
        with patch("song_engine.singing_files_available", return_value=True):
            self.assertEqual(installer.status()["state"], "succeeded")
        with patch("song_engine.singing_files_available", return_value=False):
            self.assertEqual(installer.status()["state"], "idle")

    def test_bundled_worker_version_respects_pinned_upstream_python_range(self):
        root = Path(__file__).resolve().parents[1]
        lock = json.loads((root / "packaging/windows/dependencies.lock.json").read_text())
        version = tuple(map(int, lock["singing_python"]["version"].split(".")[:2]))
        self.assertGreaterEqual(version, (3, 11))
        self.assertLess(version, (3, 13))
