import io
import tempfile
import unittest
import wave
from pathlib import Path
from unittest.mock import patch
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from free_engine import SPEECH, lyric_draft, generate_free
from storage import Problem
from test_server import wav


class FreeTest(unittest.TestCase):
    def test_template_is_not_ai_and_preserves_words(self):
        r = lyric_draft({"story": "Kami bertemu di Bandung"})
        self.assertEqual(r["origin"], "local-template")
        self.assertIn("Bandung", r["lyrics"])
        self.assertIn("[Chorus]", r["lyrics"])

    def test_missing_model_does_not_fake_ai(self):
        with patch("free_engine.model_ready", return_value=False):
            with self.assertRaises(Problem) as e:
                lyric_draft({"story": "Kisah"}, True)
            self.assertEqual(e.exception.status, 503)

    def test_native_voice_catalog_and_distinct_real_audio(self):
        c = SPEECH.catalog()
        self.assertEqual(len(c), 705)
        self.assertEqual(len({v["language"] for v in c}), 140)
        ind = [v for v in c if v["language"] == "id"]
        self.assertEqual(len(ind), 5)
        results = []
        for style in ("Natural", "Deep"):
            voice = next(v for v in ind if v["style"] == style)
            data = SPEECH.synth("Ini adalah kisah kami.", voice["id"])
            with wave.open(io.BytesIO(data)) as w:
                self.assertEqual(w.getnchannels(), 1)
                self.assertGreater(w.getnframes() / w.getframerate(), 1)
            results.append(data)
        self.assertNotEqual(*results)
        with self.assertRaises(Problem):
            SPEECH.synth("Hi", "arbitrary/voice")

    def test_spoken_word_is_labelled_and_decodable(self):
        voice = next(v for v in SPEECH.catalog() if v["language"] == "id")
        data, mime, meta = generate_free(
            "spoken-song",
            {"lyrics": "Kenangan kita masih ada.", "freeVoice": voice["id"]},
            [("audio", "bed.wav", "audio/wav", wav())],
            lambda _: None,
        )
        self.assertEqual(meta["type"], "spoken")
        self.assertEqual(meta["origin"], "local-speech")
        with wave.open(io.BytesIO(data)) as w:
            self.assertEqual(w.getframerate(), 44100)
            self.assertGreater(w.getnframes(), 1000)
