const { chromium } = require("playwright");
const assert = require("node:assert/strict");
const { spawn } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
(async () => {
  const root = path.resolve(__dirname, ".."),
    data = fs.mkdtempSync(
      path.join(os.tmpdir(), "kisahnada-restored-browser-"),
    );
  const child = spawn(path.join(root, ".venv/bin/python"), ["server.py"], {
    cwd: root,
    env: {
      ...process.env,
      PORT: "8003",
      KISAHNADA_DATA_DIR: data,
      KISAHNADA_FREE_ONLY: "1",
      KISAHNADA_PAID_ENABLED: "1",
      KISAHNADA_ELEVENLABS_KEY: "test-only-no-billing",
      KISAHNADA_DAILY_LIMIT_USD: "10",
      KISAHNADA_PRICES: '{"song":0.2}',
      KISAHNADA_GROQ_KEY: "",
      GROQ_API_KEY: "",
      KISAHNADA_GROQ_FREE_PLAN_CONFIRMED: "0",
    },
    stdio: "ignore",
  });
  let browser;
  try {
    let ready = false;
    for (let i = 0; i < 100; i++) {
      try {
        let r = await fetch("http://127.0.0.1:8003/api/capabilities");
        if (r.ok) {
          const c = await r.json();
          assert(c.freeOnly);
          assert(!c.paidEnabled);
          assert(c.localVoices);
          assert.equal(c.groqLyrics, false);
          assert.equal(c.voiceProfileCount, 705);
          ready = true;
          break;
        }
      } catch {}
      await new Promise((r) => setTimeout(r, 100));
    }
    assert(ready);
    browser = await chromium.launch({
      executablePath: "/usr/bin/chromium",
      headless: true,
      args: ["--no-sandbox", "--disable-dev-shm-usage"],
    });
    const page = await browser.newPage({
        viewport: { width: 1280, height: 1000 },
      }),
      errors = [];
    page.on("pageerror", (e) => errors.push(e.message));
    await page.goto("http://127.0.0.1:8003");
    assert.equal(await page.locator("html").getAttribute("data-theme"), "light");
    await page.locator("#theme-toggle").click();
    assert.equal(await page.locator("html").getAttribute("data-theme"), "dark");
    assert.equal(await page.locator("body").evaluate(el => getComputedStyle(el).backgroundColor), "rgb(16, 24, 19)");
    await page.reload();
    assert.equal(await page.locator("html").getAttribute("data-theme"), "dark");
    await page.locator("#theme-toggle").click();
    assert.equal(await page.locator("html").getAttribute("data-theme"), "light");
    await page
      .locator("#story")
      .fill("Kami bertemu di Bandung. Kami menyukai hujan sore.");
    assert(await page.locator("#create-song").isDisabled());
    assert(await page.locator("#local-ai-lyrics").isDisabled());
    assert(await page.locator("#groq-lyrics").isDisabled());
    await page.locator("#template-lyrics").click();
    await page.locator("#account-name").fill("free_creator");
    await page
      .locator("#account-password")
      .fill("this-is-only-a-test-password");
    await page.locator("#register-submit").click();
    await page.locator("#accept-free-lyrics").waitFor();
    assert.match(
      await page.locator("#modal-content").textContent(),
      /bukan inferensi AI/,
    );
    await page.locator("#accept-free-lyrics").click();
    assert.match(await page.locator("#lyrics").inputValue(), /Bandung/);
    let modelDownloads = 0;
    await page.route("**/api/desktop/song-setup", async route => {
      const posting = route.request().method() === "POST";
      if (posting) {
        assert.equal(route.request().postDataJSON().confirmDownload, true);
        modelDownloads++;
      }
      await route.fulfill({json: {available: true, state: modelDownloads ? "failed" : "idle", message: modelDownloads ? "Uji UI: unduhan ditolak, tidak ada model diunduh." : "Menunggu konfirmasi unduhan."}});
    });
    await page.evaluate(() => { caps.desktopModelSetup = true; render(); });
    await page.locator("#desktop-song-setup").click();
    await page.locator("#song-setup-status").filter({hasText: "Menunggu konfirmasi"}).waitFor();
    assert.equal(modelDownloads, 0);
    await page.locator("#song-setup-start").click();
    await page.locator("#song-setup-status").filter({hasText: "unduhan ditolak"}).waitFor();
    assert.equal(modelDownloads, 1);
    assert(await page.locator("#song-setup-start").isEnabled());
    await page.locator("#close-modal").click();
    await page.unroute("**/api/desktop/song-setup");
    await page.evaluate(() => { caps.desktopModelSetup = false; render(); });
    await page.locator('#nav [data-page="cover"]').click();
    await page.locator("[data-free-preview]").first().waitFor();
    assert.equal(await page.locator(".free-voice-grid .voice-tile").count(), 5);
    await page.locator("#free-language").selectOption("");
    assert.equal(
      await page.locator(".free-voice-grid .voice-tile").count(),
      40,
    );
    await page.locator("#free-voice-search").fill("Indonesian");
    assert.equal(await page.locator(".free-voice-grid .voice-tile").count(), 5);
    await page.locator("#free-voice-search").fill("");
    await page.locator("#free-language").selectOption("id");
    await page
      .locator(".voice-tile")
      .filter({ hasText: "Deep" })
      .locator("[data-free-voice]")
      .click();
    await page.locator("[data-free-preview]").first().click();
    await page.locator("#modal audio").waitFor();
    await page.waitForFunction(
      () => document.querySelector("#modal audio")?.readyState >= 1,
    );
    assert(
      (await page.locator("#modal audio").evaluate((a) => a.duration)) > 1,
    );
    const [download] = await Promise.all([
      page.waitForEvent("download"),
      page.locator("#download-free-preview").click(),
    ]);
    assert.equal(download.suggestedFilename(), "kisahnada-voice-preview.wav");
    await page.locator("#close-modal").click();
    await page
      .locator("#free-spoken-lyrics")
      .fill("Ini cerita kami. Kenangan dalam nada, akan selalu ada.");
    await page.locator("#free-spoken-create").click();
    await page
      .locator(".library-row")
      .filter({ hasText: "Narasi bermusik" })
      .waitFor({ timeout: 30000 });
    const metadata = await page.evaluate(() => ({
      type: projects[0].type,
      mime: projects[0].blob.type,
      size: projects[0].blob.size,
    }));
    assert.equal(metadata.type, "spoken");
    assert.equal(metadata.mime, "audio/wav");
    assert(metadata.size > 10000);
    await page.locator('[aria-label="Simpan ke server"]').click();
    await page.waitForFunction(() =>
      document
        .querySelector("#toast")
        .textContent.includes("Cadangan tersimpan"),
    );
    await page.evaluate(async () => {
      await new Promise((resolve, reject) => {
        const tx = db.transaction("projects", "readwrite");
        tx.objectStore("projects").clear();
        tx.oncomplete = resolve;
        tx.onerror = reject;
      });
      projects = [];
      render();
    });
    assert.equal(await page.locator(".library-row").count(), 0);
    await page.locator("#server-library").click();
    await page.locator("[data-import]").first().click();
    await page.locator(".library-row").waitFor();
    await page.locator('#nav [data-page="explore"]').click();
    await page.locator('[data-tool="glow"]').click();
    const bytes = Buffer.from(
      await page.evaluate(async () =>
        Array.from(new Uint8Array(await projects[0].blob.arrayBuffer())),
      ),
    );
    await page
      .locator("#tool-audio")
      .setInputFiles({
        name: "voice.wav",
        mimeType: "audio/wav",
        buffer: bytes,
      });
    await page.locator("#process-tool").click();
    await page
      .locator(".library-row")
      .filter({ hasText: "Vocal Glow Up" })
      .waitFor({ timeout: 30000 });
    await page.locator("#job-history").click();
    assert.match(await page.locator(".job-list").textContent(), /succeeded/);
    await page.locator("#close-modal").click();
    const guard = await page.evaluate(async () => {
      let f = new FormData();
      f.append("spec", JSON.stringify({ story: "No billing" }));
      let r = await fetch("/api/quote?kind=song", { method: "POST", body: f });
      return r.status;
    });
    assert.equal(guard, 403);
    await page.locator("#settings").click();
    assert.match(
      await page.locator("#modal-content").textContent(),
      /Integrasi berbayar diblokir/,
    );
    await page.locator("#close-modal").click();
    await page.setViewportSize({ width: 390, height: 844 });
    await page.locator('#mobile-nav [data-page="cover"]').click();
    assert(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    );
    assert.deepEqual(errors, []);
    console.log(
      "PASS: restored account, native voice catalog/preview/download, template acceptance, spoken music, server backup/browser recovery, FFmpeg glow/history, billing lock, missing singing-model guard and responsive layout. No real AI inference claimed.",
    );
  } finally {
    if (browser) await browser.close();
    child.kill("SIGTERM");
    await new Promise((r) => child.once("exit", r));
    fs.rmSync(data, { recursive: true, force: true });
  }
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
