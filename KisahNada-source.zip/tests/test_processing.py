import io
import subprocess
import tempfile
import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from processing import process_local, probe
from storage import Problem
from test_server import wav


class MediaTest(unittest.TestCase):
    def test_mixed_photos_clips_and_soundtrack(self):
        from PIL import Image

        photo = io.BytesIO()
        Image.new("RGB", (320, 240), (80, 100, 60)).save(photo, format="PNG")
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "clip.webm"
            subprocess.run(
                [
                    "ffmpeg",
                    "-loglevel",
                    "error",
                    "-f",
                    "lavfi",
                    "-i",
                    "color=c=orange:s=320x240:d=0.5",
                    "-c:v",
                    "libvpx-vp9",
                    "-threads",
                    "1",
                    str(path),
                ],
                check=True,
            )
            data, mime, meta = process_local(
                "slideshow",
                {"duration": 3, "effect": "Fade"},
                [
                    ("media", "photo.png", "image/png", photo.getvalue()),
                    ("media", "clip.webm", "video/webm", path.read_bytes()),
                    ("audio", "bed.wav", "audio/wav", wav()),
                ],
                lambda _: None,
            )
            out = Path(temp) / "out.webm"
            out.write_bytes(data)
            info = probe(out)
            v = next(x for x in info["streams"] if x["codec_type"] == "video")
            self.assertEqual((v["width"], v["height"]), (1280, 720))
            self.assertTrue(any(x["codec_type"] == "audio" for x in info["streams"]))
            self.assertAlmostEqual(float(info["format"]["duration"]), 6, delta=0.2)
            self.assertEqual(meta["origin"], "renderer")

    def test_bad_audio_is_not_success(self):
        with self.assertRaises(Problem):
            process_local(
                "glow",
                {},
                [("audio", "fake.mp3", "audio/mpeg", b"not audio")],
                lambda _: None,
            )
