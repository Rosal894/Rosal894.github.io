import http.cookiejar
import io
import json
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
import wave
from pathlib import Path
from unittest.mock import patch
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from server import StudioServer
from providers import Providers, multipart
from storage import Storage, Problem


def wav():
    out = io.BytesIO()
    with wave.open(out, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(8000)
        w.writeframes(b"\1\0" * 8000)
    return out.getvalue()


class Client:
    def __init__(self, base):
        self.base = base
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar())
        )

    def request(self, path, data=None, headers=None, method=None):
        return self.opener.open(
            urllib.request.Request(
                self.base + path, data=data, headers=headers or {}, method=method
            )
        )

    def json(self, path, data=None, method=None):
        with self.request(
            path,
            json.dumps(data).encode() if data is not None else None,
            {"Content-Type": "application/json"},
            method,
        ) as r:
            return json.load(r)

    def form(self, path, spec, files=None, headers=None, field="spec"):
        data, mime = multipart({field: json.dumps(spec)}, files or [])
        with self.request(path, data, {"Content-Type": mime, **(headers or {})}) as r:
            return json.load(r)


class ServerTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.p = Providers()
        cls.p.enabled = False
        cls.p.gateway = ""
        cls.p.eleven = ""
        cls.p.openai = ""
        cls.p.features = set()
        cls.server = StudioServer(("127.0.0.1", 0), cls.temp.name, cls.p)
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()
        cls.temp.cleanup()

    def client(self, name):
        c = Client(self.base)
        c.json(
            "/api/account/register", {"name": name, "password": "private test password"}
        )
        return c

    def test_page_and_capabilities(self):
        c = Client(self.base)
        for path, value in [
            ("/", b"KisahNada"),
            ("/app.js", b"synthesize"),
            ("/free.js", b"createLocalSinging"),
            ("/creation.js", b"creationResults"),
            ("/assets/cover-0.svg", b"<svg"),
        ]:
            with c.request(path) as r:
                self.assertEqual(r.status, 200)
                self.assertIn(value, r.read())
                self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")
        caps = c.json("/api/capabilities")
        self.assertTrue(caps["freeOnly"])
        self.assertFalse(caps["paidEnabled"])
        self.assertFalse(caps["localSinging"])

    def test_desktop_setup_requires_confirmation_and_supported_platform(self):
        c = self.client("desktop_setup")
        status = c.json("/api/desktop/song-setup")
        self.assertFalse(status["available"])
        for body, expected in [({}, 400), ({"confirmDownload": True}, 503)]:
            with self.assertRaises(urllib.error.HTTPError) as error:
                c.json("/api/desktop/song-setup", body)
            self.assertEqual(error.exception.code, expected)

    def test_private_files_and_auth(self):
        c = Client(self.base)
        with self.assertRaises(urllib.error.HTTPError) as e:
            c.json("/api/desktop/song-setup")
        self.assertEqual(e.exception.code, 401)
        for path in [
            "/server.py",
            "/.env",
            "/.git/config",
            "/.studio/studio.sqlite3",
            "/README.md",
            "/assets/%2e%2e/server.py",
            "/api/unknown",
        ]:
            with self.assertRaises(urllib.error.HTTPError) as e:
                c.request(path)
            self.assertEqual(e.exception.code, 404)
        with self.assertRaises(urllib.error.HTTPError) as e:
            c.request("/api/projects")
        self.assertEqual(e.exception.code, 401)

    def test_accounts_and_logout(self):
        c = self.client("account_test")
        self.assertEqual(c.json("/api/account")["user"]["name"], "account_test")
        c.json("/api/account/logout", {}, "POST")
        self.assertIsNone(c.json("/api/account")["user"])
        c.json(
            "/api/account/login",
            {"name": "account_test", "password": "private test password"},
        )
        self.assertTrue(c.json("/api/account")["user"])

    def test_ownership_and_project_recovery(self):
        a = self.client("owner_one")
        b = self.client("owner_two")
        meta = {
            "id": "project-123",
            "title": "Rumah Kita",
            "type": "demo",
            "created": 1700000000000,
        }
        a.form(
            "/api/projects",
            meta,
            [("audio", "song.wav", "audio/wav", wav())],
            field="metadata",
        )
        self.assertEqual(len(a.json("/api/projects")["projects"]), 1)
        self.assertEqual(b.json("/api/projects")["projects"], [])
        with a.request("/api/projects/project-123/file") as r:
            self.assertEqual(r.read(), wav())
        for method, path in [
            ("GET", "/api/projects/project-123/file"),
            ("DELETE", "/api/projects/project-123"),
        ]:
            with self.assertRaises(urllib.error.HTTPError) as e:
                b.request(path, method=method)
            self.assertEqual(e.exception.code, 404)
        a.json("/api/projects/project-123", method="DELETE")
        self.assertEqual(a.json("/api/projects")["projects"], [])

    def test_free_lock_even_with_paid_provider_config(self):
        c = self.client("free_lock")
        previous = (self.p.enabled, self.p.eleven, self.p.prices, self.p.daily)
        self.p.enabled = True
        self.p.eleven = "test-only"
        self.p.prices = {"song": 0.2, "lyrics": 0.01}
        self.p.daily = 10
        try:
            with patch.object(self.p, "generate") as generate:
                with self.assertRaises(urllib.error.HTTPError) as e:
                    c.form("/api/quote?kind=song", {"story": "Cerita kita"})
                self.assertEqual(e.exception.code, 403)
                generate.assert_not_called()
        finally:
            self.p.enabled, self.p.eleven, self.p.prices, self.p.daily = previous

    def test_server_validation_and_csrf(self):
        c = self.client("validate_test")
        for spec in [
            {"story": "kata " * 501},
            {"story": "valid", "tags": ["x"] * 11},
            {"story": "valid", "songSeconds": 600},
        ]:
            with self.assertRaises(urllib.error.HTTPError) as e:
                c.form("/api/quote?kind=song", spec)
            self.assertEqual(e.exception.code, 400)
        with self.assertRaises(urllib.error.HTTPError) as e:
            c.request(
                "/api/account/logout",
                b"{}",
                {"Content-Type": "application/json", "Origin": "https://evil.invalid"},
            )
        self.assertEqual(e.exception.code, 403)

    def test_local_jobs_and_isolation(self):
        a = self.client("job_owner")
        b = self.client("job_other")
        job = a.form(
            "/api/jobs?kind=glow",
            {"title": "Clean vocal"},
            [("audio", "voice.wav", "audio/wav", wav())],
        )
        with self.assertRaises(urllib.error.HTTPError) as e:
            b.request("/api/jobs/" + job["id"])
        self.assertEqual(e.exception.code, 404)
        for _ in range(100):
            result = a.json("/api/jobs/" + job["id"])
            if result["status"] in ("succeeded", "failed"):
                break
            time.sleep(0.05)
        self.assertEqual(result["status"], "succeeded", result["error"])
        pid = result["result"]["project"]["id"]
        with a.request("/api/projects/" + pid + "/file") as r:
            with wave.open(io.BytesIO(r.read())) as w:
                self.assertEqual(w.getframerate(), 44100)
                self.assertGreater(w.getnframes(), 0)

    def test_template_job_is_free_and_honest(self):
        c = self.client("template_test")
        spec = {"story": "Kenangan di Bandung"}
        quote = c.form("/api/quote?kind=template-lyrics", spec)
        self.assertEqual(quote["amount"], 0)
        self.assertIsNone(quote["quoteId"])
        job = c.form("/api/jobs?kind=template-lyrics", spec)
        for _ in range(50):
            r = c.json("/api/jobs/" + job["id"])
            if r["status"] == "succeeded":
                break
            time.sleep(0.05)
        self.assertEqual(r["status"], "succeeded")
        self.assertEqual(r["result"]["origin"], "local-template")
        self.assertIn("Bandung", r["result"]["lyrics"])
        self.assertEqual(r["reserved"], 0)


class StorageTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.s = Storage(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_password_hash_session_and_restart(self):
        user, token = self.s.account("rosal", "test password long", True)
        self.assertEqual(self.s.session(token)["id"], user["id"])
        with self.s.connect() as db:
            self.assertNotEqual(
                db.execute("SELECT password FROM users").fetchone()[0],
                b"test password long",
            )
        job = self.s.create_job(user["id"], "glow", "x")
        self.s = Storage(self.temp.name)
        self.assertEqual(self.s.job(user["id"], job)["status"], "failed")
        self.s.logout(token)
        self.assertIsNone(self.s.session(token))

    def test_atomic_quote_budget_replay_and_input_binding(self):
        q = self.s.quote("a", "song", "hash", 0.06)
        job = self.s.create_job("a", "song", "hash", q, 0.1)
        with self.assertRaises(Problem):
            self.s.create_job("a", "song", "hash", q, 0.1)
        q = self.s.quote("b", "song", "hash", 0.06)
        with self.assertRaises(Problem) as e:
            self.s.create_job("b", "song", "hash", q, 0.1)
        self.assertEqual(e.exception.status, 402)
        q = self.s.quote("b", "song", "hash", 0.01)
        with self.assertRaises(Problem) as e:
            self.s.create_job("b", "song", "changed", q, 0.1)
        self.assertEqual(e.exception.status, 409)
        self.assertTrue(self.s.claim_job("a", job))
        self.assertFalse(self.s.claim_job("a", job))

    def test_queue_cancel_limits(self):
        job = self.s.create_job("a", "glow", "1")
        self.s.create_job("a", "glow", "2")
        with self.assertRaises(Problem):
            self.s.create_job("a", "glow", "3")
        self.s.cancel_job("a", job)
        self.assertFalse(self.s.claim_job("a", job))


class ProviderTest(unittest.TestCase):
    def provider(self):
        with patch.dict(
            "os.environ",
            {
                "KISAHNADA_OPENAI_KEY": "test",
                "KISAHNADA_ELEVENLABS_KEY": "test",
                "KISAHNADA_PAID_ENABLED": "1",
                "KISAHNADA_PRICES": '{"song":0.2,"lyrics":0.01,"story":0.02,"video":0.1}',
                "KISAHNADA_DAILY_LIMIT_USD": "1",
            },
            clear=True,
        ):
            return Providers()

    def test_estimate_and_unsupported_voice(self):
        p = self.provider()
        self.assertAlmostEqual(p.estimate("song", {"songSeconds": 60})["amount"], 0.21)
        self.assertAlmostEqual(p.estimate("video", {"videoSeconds": 4})["amount"], 0.4)
        with self.assertRaises(Problem):
            p.estimate("song", {"vocal": "My Voice"})

    def test_native_adapter_contract_uses_fake_transport_only(self):
        p = self.provider()
        text = {
            "choices": [
                {
                    "message": {
                        "content": "[Verse]\nKita selalu pulang\n[Chorus]\nCinta yang tenang"
                    }
                }
            ]
        }
        with patch("providers.request_json", return_value=text) as chat, patch(
            "providers.request", return_value=(wav(), "audio/wav")
        ) as music:
            result, mime, meta = p.generate(
                "song",
                {
                    "story": "Kisah kita",
                    "genre": "Pop",
                    "vocal": "Female",
                    "songSeconds": 30,
                },
                [],
                lambda _: None,
            )
            self.assertEqual(result[:4], b"RIFF")
            self.assertIn("selalu", meta["lyrics"])
            self.assertIn("/v1/chat/completions", chat.call_args.args[0])
            self.assertEqual(music.call_args.args[1]["model_id"], "music_v1")
            self.assertEqual(
                sum(
                    x["duration_ms"]
                    for x in music.call_args.args[1]["composition_plan"]["sections"]
                ),
                30000,
            )

    def test_vision_and_nonfinite_budget(self):
        p = self.provider()
        with patch(
            "providers.request_json",
            return_value={
                "choices": [{"message": {"content": "Dua orang tampak di taman."}}]
            },
        ) as chat:
            self.assertTrue(
                p.text(
                    {"story": "Kenangan kami"},
                    [("media", "pic.png", "image/png", b"test")],
                    True,
                )
            )
            self.assertEqual(
                chat.call_args.args[1]["messages"][1]["content"][1]["type"], "image_url"
            )
        with patch.dict("os.environ", {"KISAHNADA_DAILY_LIMIT_USD": "nan"}, clear=True):
            with self.assertRaises(RuntimeError):
                Providers()
