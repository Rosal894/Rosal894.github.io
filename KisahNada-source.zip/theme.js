/* Apply before CSS paints; explicit choice survives navigation and restart. */
(() => {
  const key = "kisahnada-theme", system = matchMedia("(prefers-color-scheme: dark)");
  let selected;
  try { selected = localStorage.getItem(key); } catch {}
  function apply(value) {
    const theme = value === "dark" || value === "light" ? value : system.matches ? "dark" : "light";
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme;
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", theme === "dark" ? "#101813" : "#f7f6f2");
    const button = document.getElementById("theme-toggle");
    if (button) {
      button.textContent = theme === "dark" ? "☀" : "☾";
      button.setAttribute("aria-label", theme === "dark" ? "Gunakan tema terang" : "Gunakan tema gelap");
      button.setAttribute("aria-pressed", String(theme === "dark"));
      button.title = theme === "dark" ? "Tema terang" : "Tema gelap";
    }
  }
  apply(selected);
  document.addEventListener("DOMContentLoaded", () => {
    apply(selected);
    document.getElementById("theme-toggle").onclick = () => {
      selected = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
      try { localStorage.setItem(key, selected); } catch {}
      apply(selected);
    };
  });
  system.addEventListener("change", () => { if (!selected) apply(); });
})();
