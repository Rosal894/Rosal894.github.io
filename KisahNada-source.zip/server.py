#!/usr/bin/env python3
"""KisahNada private local studio, free-only default, persistent jobs and projects."""
import concurrent.futures
import email.policy
import io
import json
import os
import re
import shutil
import tempfile
import threading
import time
import urllib.parse
import uuid
import zipfile
from email.parser import BytesParser
from http.cookies import SimpleCookie
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from storage import Storage, Problem
from processing import process_local, probe
from providers import Providers
from free_engine import SPEECH, free_capabilities, generate_free
from song_engine import compose_request, generate_singing, singing_files_available
from lyrics_provider import require_free_configuration
from desktop_setup import INSTALLER

ROOT = Path(__file__).resolve().parent
MAX_UPLOAD = 150 * 1024**2
LOCAL_KINDS = {"glow", "local-remix", "slideshow"}
FREE_KINDS = {"free-lyrics", "template-lyrics", "spoken-song", "free-song", "groq-lyrics"}
AI_KINDS = {"song", "lyrics", "cover", "video", "story", "hum", "split"}
LIMIT_LOCK = threading.Lock()
ATTEMPTS = {}
PREVIEW_ATTEMPTS = {}


def parse_multipart(data, content_type):
    if (
        not content_type.startswith("multipart/form-data;")
        or "\r" in content_type
        or "\n" in content_type
    ):
        raise Problem("Gunakan multipart/form-data.", 415)
    message = BytesParser(policy=email.policy.default).parsebytes(
        ("Content-Type: " + content_type + "\r\nMIME-Version: 1.0\r\n\r\n").encode()
        + data
    )
    if not message.is_multipart():
        raise Problem("Format unggahan tidak valid.")
    parts = list(message.iter_parts())
    fields = {}
    files = []
    if len(parts) > 16:
        raise Problem("Terlalu banyak bagian unggahan.")
    for part in parts:
        name = part.get_param("name", header="content-disposition")
        value = part.get_payload(decode=True)
        if name not in ("spec", "metadata", "audio", "media", "voice") or value is None:
            raise Problem("Field unggahan tidak valid.")
        if part.get_filename() is not None:
            mime = part.get_content_type()
            if not mime.startswith(("audio/", "image/", "video/")):
                raise Problem("Format file tidak didukung.", 415)
            files.append((name, part.get_filename()[:200], mime, value))
        else:
            if name in fields or len(value) > 100000:
                raise Problem("Field ganda atau terlalu besar.")
            try:
                fields[name] = json.loads(value)
            except (ValueError, UnicodeError):
                raise Problem("JSON input tidak valid.") from None
    return fields, files


def validate_spec(kind, spec, files):
    if not isinstance(spec, dict):
        raise Problem("Spesifikasi harus objek JSON.")
    for key, limit in [
        ("story", 15000),
        ("lyrics", 12000),
        ("title", 100),
        ("style", 150),
        ("genre", 50),
        ("vocal", 30),
    ]:
        if not isinstance(spec.get(key, ""), str) or len(spec.get(key, "")) > limit:
            raise Problem("Field " + key + " tidak valid.")
    if len(spec.get("story", "").split()) > 500:
        raise Problem("Cerita maksimal 500 kata.")
    tags = spec.get("tags", [])
    if (
        not isinstance(tags, list)
        or len(tags) > 10
        or any(not isinstance(x, str) or len(x) > 50 for x in tags)
    ):
        raise Problem("Maksimal 10 pilihan gaya yang valid.")
    for key, allowed, default in [
        ("songSeconds", (30, 60, 120), 60),
        ("videoSeconds", (4, 8, 12), 4),
        ("duration", (3, 4, 5, 6), 4),
    ]:
        if (
            type(spec.get(key, default)) is not int
            or spec.get(key, default) not in allowed
        ):
            raise Problem("Durasi tidak valid.")
    if len(files) > 12 or sum(len(f[3]) for f in files) > MAX_UPLOAD:
        raise Problem("Unggahan terlalu besar.", 413)
    audio = [f for f in files if f[0] == "audio"]
    media = [f for f in files if f[0] == "media"]
    voice = [f for f in files if f[0] == "voice"]
    if len(audio) > 1 or len(media) > 10 or len(voice) > 1:
        raise Problem("Terlalu banyak file.")
    for field, filename, mime, data in files:
        limit = (
            25
            if field == "voice"
            else 50 if field == "audio" else 15 if mime.startswith("image/") else 100
        ) * 1024**2
        if not data or len(data) > limit:
            raise Problem("Ukuran file melewati batas.", 413)
        if field in ("audio", "voice") and not mime.startswith("audio/"):
            raise Problem("Pilih audio yang valid.")
    if voice and spec.get("voiceConsent") is not True:
        raise Problem("Persetujuan pemilik suara diperlukan.")
    if kind in ("cover", "hum", "split", "glow", "local-remix") and not audio:
        raise Problem("Pilih audio sumber.")
    if kind in ("slideshow", "story") and not media:
        raise Problem("Pilih foto/video terlebih dahulu.")
    if kind in ("song", "lyrics", "template-lyrics", "free-lyrics", "groq-lyrics") and not (
        spec.get("story", "").strip() or spec.get("lyrics", "").strip()
    ):
        raise Problem("Tuliskan cerita atau lirik dahulu.")
    if kind in ("cover", "hum", "split") and audio:
        with tempfile.TemporaryDirectory(prefix="kisahnada-probe-") as tmp:
            p = Path(tmp) / "source"
            p.write_bytes(audio[0][3])
            info = probe(p)
            try:
                seconds = float(info["format"]["duration"])
            except (KeyError, ValueError):
                raise Problem("Durasi audio tidak dapat dibaca.") from None
            if not 0 < seconds <= 600:
                raise Problem("Audio maksimal 10 menit.")
            spec["inputSeconds"] = seconds
    return spec


class StudioServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, root=None, providers=None):
        self.storage = Storage(
            root or os.environ.get("KISAHNADA_DATA_DIR", str(ROOT / ".studio"))
        )
        self.providers = providers or Providers()
        self.free_only = os.environ.get("KISAHNADA_FREE_ONLY", "1") != "0"
        self.pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="studio-job"
        )
        super().__init__(address, Handler)

    def server_close(self):
        super().server_close()
        self.pool.shutdown(wait=True, cancel_futures=False)

    def execute(self, uid, jid, kind, spec, files):
        storage = self.storage
        if not storage.claim_job(uid, jid):
            return

        def progress(text):
            storage.update_job(jid, "running", text)

        try:
            progress("Memulai pemrosesan")
            if kind == "free-song":
                blob, mime, meta = generate_singing(spec, progress)
            elif kind in FREE_KINDS:
                blob, mime, meta = generate_free(kind, spec, files, progress)
            elif kind in LOCAL_KINDS:
                blob, mime, meta = process_local(kind, spec, files, progress)
            else:
                blob, mime, meta = self.providers.generate(kind, spec, files, progress)
            if blob is None:
                storage.update_job(jid, "succeeded", "Selesai", result=meta)
                return
            if kind == "split":
                try:
                    archive = zipfile.ZipFile(io.BytesIO(blob))
                    entries = [e for e in archive.infolist() if not e.is_dir()]
                    if (
                        not 1 <= len(entries) <= 12
                        or sum(e.file_size for e in entries) > MAX_UPLOAD
                    ):
                        raise Problem("Arsip stem terlalu besar atau tidak valid.", 502)
                    projects = []
                    for entry in entries:
                        suffix = Path(entry.filename).suffix.lower()
                        mime = {
                            ".mp3": "audio/mpeg",
                            ".wav": "audio/wav",
                            ".flac": "audio/flac",
                            ".ogg": "audio/ogg",
                        }.get(suffix)
                        if not mime:
                            continue
                        p = {
                            "id": uuid.uuid4().hex,
                            "title": (spec.get("title") or "Separated")
                            + " · "
                            + Path(entry.filename).stem[:70],
                            "type": "stem",
                            "origin": "ai",
                            "genre": spec.get("genre", ""),
                            "created": int(time.time() * 1000),
                            "art": 0,
                            "lyrics": "",
                        }
                        storage.project_put(uid, p, archive.read(entry), mime)
                        projects.append(p)
                    if not projects:
                        raise Problem("Tidak ada stem audio dalam arsip.", 502)
                    storage.update_job(
                        jid, "succeeded", "Selesai", result={"projects": projects}
                    )
                except (zipfile.BadZipFile, RuntimeError):
                    raise Problem("Arsip stem tidak valid.", 502) from None
                return
            p = {
                **{
                    k: spec.get(k) for k in ("genre", "style", "tags", "story", "vocal")
                },
                **meta,
                "id": uuid.uuid4().hex,
                "title": spec.get("title")
                or ("Video kenangan" if mime.startswith("video/") else "Karya baru"),
                "created": int(time.time() * 1000),
                "art": 0,
                "liked": False,
            }
            storage.project_put(uid, p, blob, mime)
            storage.update_job(
                jid, "succeeded", "Selesai", result={"project": p, "mime": mime}
            )
        except Problem as e:
            storage.update_job(jid, "failed", "Gagal", error=str(e))
        except Exception as e:
            print("Job failed:", jid, type(e).__name__, flush=True)
            storage.update_job(
                jid,
                "failed",
                "Gagal",
                error="Pemrosesan gagal; job tidak diulang otomatis.",
            )


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def setup(self):
        super().setup()
        self.connection.settimeout(45)

    def end_headers(self):
        for key, value in [
            ("X-Content-Type-Options", "nosniff"),
            ("Referrer-Policy", "same-origin"),
            ("Cache-Control", "no-store"),
            ("X-Frame-Options", "DENY"),
        ]:
            self.send_header(key, value)
        super().end_headers()

    def json_response(self, status, value, cookie=None):
        data = json.dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(data)

    def binary(self, data, mime):
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def session_token(self):
        try:
            cookie = SimpleCookie(self.headers.get("Cookie", ""))
            return cookie["kn_session"].value if "kn_session" in cookie else ""
        except Exception:
            return ""

    def user(self, required=True):
        user = self.server.storage.session(self.session_token())
        if required and not user:
            raise Problem("Masuk akun server terlebih dahulu.", 401)
        return user

    def cookie(self, token):
        return (
            f"kn_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age={604800 if token else 0}"
            + ("; Secure" if os.environ.get("KISAHNADA_SECURE_COOKIE") == "1" else "")
        )

    def check_origin(self):
        origin = self.headers.get("Origin")
        if (
            self.headers.get("Sec-Fetch-Site") == "cross-site"
            or origin
            and urllib.parse.urlparse(origin).netloc != self.headers.get("Host")
        ):
            raise Problem("Origin tidak diizinkan.", 403)
        if self.headers.get("Transfer-Encoding"):
            raise Problem("Transfer encoding tidak didukung.")

    def read_body(self, limit=MAX_UPLOAD):
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise Problem("Ukuran tidak valid.") from None
        if not 0 < size <= limit:
            raise Problem("Ukuran unggahan tidak valid/terlalu besar.", 413)
        data = self.rfile.read(size)
        if len(data) != size:
            raise Problem("Unggahan terputus.")
        return data

    def read_json(self):
        if not self.headers.get("Content-Type", "").startswith("application/json"):
            raise Problem("Gunakan JSON.", 415)
        try:
            data = json.loads(self.read_body(100000))
            if not isinstance(data, dict):
                raise ValueError()
            return data
        except (ValueError, UnicodeError):
            raise Problem("JSON tidak valid.") from None

    def do_GET(self):
        try:
            self.get()
        except Problem as e:
            self.json_response(e.status, {"error": str(e)})
        except (BrokenPipeError, ConnectionResetError):
            pass

    def get(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/desktop/song-setup":
            self.user()
            return self.json_response(200, INSTALLER.status())
        if path == "/api/capabilities":
            return self.json_response(
                200,
                {
                    **{
                        k: (v and not self.server.free_only)
                        for k, v in self.server.providers.capabilities().items()
                    },
                    **free_capabilities(),
                    "localSinging": singing_files_available(),
                    "desktopModelSetup": INSTALLER.available,
                    "freeOnly": self.server.free_only,
                    "server": True,
                    "localTools": bool(
                        shutil.which("ffmpeg") and shutil.which("ffprobe")
                    ),
                    "paidEnabled": self.server.providers.enabled
                    and not self.server.free_only,
                },
            )
        if path == "/api/free/voices":
            return self.json_response(
                200,
                {
                    "voices": [
                        {
                            k: v
                            for k, v in x.items()
                            if k not in ("selector", "pitch", "range")
                        }
                        for x in SPEECH.catalog()
                    ],
                    "notice": "Suara sintetis eSpeak-NG; lima variasi per suara dasar, bukan penyanyi.",
                },
            )
        if path == "/api/account":
            return self.json_response(200, {"user": self.user(False)})
        if path == "/api/projects":
            return self.json_response(
                200, {"projects": self.server.storage.projects(self.user()["id"])}
            )
        m = re.fullmatch("/api/projects/([a-zA-Z0-9_-]+)/file", path)
        if m:
            return self.binary(
                *self.server.storage.project_file(self.user()["id"], m[1])
            )
        if path == "/api/jobs":
            return self.json_response(
                200, {"jobs": self.server.storage.jobs(self.user()["id"])}
            )
        m = re.fullmatch("/api/jobs/([a-f0-9]{32})", path)
        if m:
            return self.json_response(
                200, self.server.storage.job(self.user()["id"], m[1])
            )
        if path.startswith("/api/"):
            raise Problem("Endpoint tidak ditemukan.", 404)
        if path not in (
            "/",
            "/index.html",
            "/app.js",
            "/studio.js",
            "/free.js",
            "/creation.js",
            "/theme.js",
            "/styles.css",
            "/favicon.ico",
        ) and not re.fullmatch(
            r"/assets/[a-zA-Z0-9_-]+\.svg", urllib.parse.unquote(path)
        ):
            raise Problem("Berkas tidak ditemukan.", 404)
        super().do_GET()

    def do_POST(self):
        try:
            self.check_origin()
            self.post()
        except Problem as e:
            self.json_response(e.status, {"error": str(e)})
        except (BrokenPipeError, ConnectionResetError):
            pass

    def post(self):
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/desktop/song-setup":
            self.user()
            if self.read_json().get("confirmDownload") is not True:
                raise Problem("Konfirmasi unduhan model terlebih dahulu.")
            return self.json_response(202, INSTALLER.start())
        if path == "/api/free/preview":
            with LIMIT_LOCK:
                ip = self.client_address[0]
                now = time.time()
                recent = [t for t in PREVIEW_ATTEMPTS.get(ip, []) if now - t < 60]
                if len(recent) >= 20:
                    raise Problem("Terlalu banyak preview. Tunggu satu menit.", 429)
                PREVIEW_ATTEMPTS[ip] = recent + [now]
            data = self.read_json()
            if (
                not isinstance(data.get("text"), str)
                or not 1 <= len(data["text"]) <= 200
            ):
                raise Problem("Preview maksimal 200 karakter.")
            return self.binary(
                SPEECH.synth(data["text"], data.get("voiceId", "")), "audio/wav"
            )
        if path in ("/api/account/register", "/api/account/login"):
            with LIMIT_LOCK:
                ip = self.client_address[0]
                now = time.time()
                recent = [t for t in ATTEMPTS.get(ip, []) if now - t < 60]
                if len(recent) >= 10:
                    raise Problem(
                        "Terlalu banyak percobaan masuk. Tunggu satu menit.", 429
                    )
                ATTEMPTS[ip] = recent + [now]
            data = self.read_json()
            user, token = self.server.storage.account(
                data.get("name", ""),
                data.get("password", ""),
                path.endswith("register"),
            )
            return self.json_response(200, {"user": user}, self.cookie(token))
        if path == "/api/account/logout":
            self.server.storage.logout(self.session_token())
            return self.json_response(200, {"ok": True}, self.cookie(""))
        if path in ("/api/song", "/api/lyrics", "/api/cover", "/api/video"):
            raise Problem(
                "Gunakan estimasi dan antrean job; tidak ada generasi yang dijalankan.",
                428,
            )
        if path == "/api/projects":
            uid = self.user()["id"]
            fields, files = parse_multipart(
                self.read_body(), self.headers.get("Content-Type", "")
            )
            if (
                len(files) != 1
                or files[0][0] not in ("audio", "media")
                or not isinstance(fields.get("metadata"), dict)
            ):
                raise Problem("Metadata/satu hasil media diperlukan.")
            f = files[0]
            return self.json_response(
                200,
                {
                    "project": self.server.storage.project_put(
                        uid, fields["metadata"], f[3], f[2]
                    )
                },
            )
        if path in ("/api/quote", "/api/jobs"):
            uid = self.user()["id"]
            kind = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get(
                "kind", [""]
            )[0]
            if kind not in AI_KINDS | LOCAL_KINDS | FREE_KINDS:
                raise Problem("Jenis job tidak dikenal.")
            fields, files = parse_multipart(
                self.read_body(), self.headers.get("Content-Type", "")
            )
            spec = validate_spec(kind, fields.get("spec"), files)
            if kind == "groq-lyrics":
                require_free_configuration()
            if kind == "free-song":
                compose_request(spec)
                if not singing_files_available():
                    raise Problem(
                        "Bobot model nyanyian ACE-Step belum terunduh/terverifikasi.",
                        503,
                    )
            fingerprint = self.server.storage.fingerprint(kind, spec, files)
            if kind in AI_KINDS and self.server.free_only:
                raise Problem(
                    "Mode gratis aktif. API berbayar diblokir pada server.", 403
                )
            quote = (
                self.server.providers.estimate(kind, spec)
                if kind in AI_KINDS
                else {
                    "amount": 0,
                    "currency": "USD",
                    "provider": "Pemrosesan lokal di server",
                    "dailyLimit": 0,
                    "pricingNote": "Tanpa biaya API; sumber daya hosting tetap diperlukan.",
                }
            )
            if kind == "groq-lyrics":
                quote.update(
                    provider="Groq · paket gratis dikonfirmasi pemilik",
                    pricingNote="Mengirim cerita/lirik ke Groq. Kuota dan tagihan mengikuti akun penyedia; server tidak dapat memeriksa paket akun. Tidak ada retry atau fallback berbayar otomatis.",
                )
            if path == "/api/quote":
                return self.json_response(
                    200,
                    {
                        **quote,
                        "quoteId": (
                            self.server.storage.quote(
                                uid, kind, fingerprint, quote["amount"]
                            )
                            if kind in AI_KINDS
                            else None
                        ),
                        "expiresIn": 600,
                    },
                )
            qid = self.headers.get("X-Quote-ID")
            if kind in AI_KINDS and not qid:
                raise Problem("Setujui estimasi biaya terlebih dahulu.", 428)
            jid = self.server.storage.create_job(
                uid,
                kind,
                fingerprint,
                qid if kind in AI_KINDS else None,
                self.server.providers.daily,
            )
            self.server.pool.submit(self.server.execute, uid, jid, kind, spec, files)
            return self.json_response(202, {"id": jid, "status": "queued"})
        m = re.fullmatch("/api/jobs/([a-f0-9]{32})/cancel", path)
        if m:
            self.server.storage.cancel_job(self.user()["id"], m[1])
            return self.json_response(200, {"ok": True})
        raise Problem("Endpoint tidak ditemukan.", 404)

    def do_DELETE(self):
        try:
            self.check_origin()
            uid = self.user()["id"]
            m = re.fullmatch(
                "/api/projects/([a-zA-Z0-9_-]+)", urllib.parse.urlparse(self.path).path
            )
            if not m:
                raise Problem("Endpoint tidak ditemukan.", 404)
            self.server.storage.project_delete(uid, m[1])
            self.json_response(200, {"ok": True})
        except Problem as e:
            self.json_response(e.status, {"error": str(e)})


if __name__ == "__main__":
    host = os.environ.get("KISAHNADA_HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8001"))
    print(f"KisahNada studio listening on {host}:{port}", flush=True)
    StudioServer((host, port)).serve_forever()
