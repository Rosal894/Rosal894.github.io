# Third-party notices

- eSpeak-NG 1.52.0, GPL-3.0-or-later, installed through pinned espeakng-loader 0.2.4. Source: https://github.com/espeak-ng/espeak-ng/tree/1.52.0 . License text retained at docs/licenses/espeak-ng-GPL-3.0.txt. Profiles are parameter variations, not singer likenesses. No binaries committed.
- llama.cpp official build b11960, commit 8642541b2, MIT: https://github.com/ggml-org/llama.cpp/tree/b11960 . Installer pins official archive SHA256. Binaries remain in ignored .local/.
- Qwen2.5-1.5B-Instruct-GGUF, Apache-2.0: https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF . Weights not yet downloaded; installer records revision/LFS hash.
- ACE-Step 1.5 source commit ca1e85fe9430179831e6bc6be790c332190a3866, MIT: https://github.com/ace-step/ACE-Step-1.5/tree/ca1e85fe9430179831e6bc6be790c332190a3866 . Source/runtime in ignored .local/ and .venv-song/. Weights not yet downloaded.
- FFmpeg supplied by environment, run as a separate process. Inspect build/license with ffmpeg -version and ffmpeg -L.

Retain applicable licenses and source availability when redistributing installed runtimes or snapshots. No third-party singers' recordings or celebrity voice models are bundled.
# Paket desktop Windows

Installer pribadi menyertakan CPython resmi dari paket NuGet `python` (lisensi PSF), eSpeak-NG dari `espeakng-loader` (GPLv3), FFmpeg/FFprobe build GPL BtbN (GPLv3), serta Microsoft VC runtime dari wheel `msvc-runtime` (Microsoft runtime redistribution terms; distribusi wheel Christoph Gohlke). Lisensi komponen disertakan dalam folder `licenses`, `runtime/LICENSE.txt` dan metadata wheel. Versi, sumber dan hash tercatat di `packaging/windows/dependencies.lock.json`. NSIS melisensikan installer output untuk distribusi; compiler tidak dimasukkan ke aplikasi. ACE-Step dan bobot diunduh secara terpisah hanya setelah konfirmasi pengguna.

Source upstream: https://github.com/python/cpython, https://github.com/espeak-ng/espeak-ng/tree/1.52.0, https://github.com/BtbN/FFmpeg-Builds, https://github.com/FFmpeg/FFmpeg, https://github.com/cgohlke/msvc-runtime. Paket ini untuk percobaan pribadi; sebelum mendistribusikan ulang secara publik, sediakan corresponding source dan seluruh kewajiban redistribusi komponen yang berlaku.
