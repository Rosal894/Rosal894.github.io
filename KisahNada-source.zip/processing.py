"""Local FFmpeg DSP/rendering; not generative AI."""

import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from storage import Problem


def run(args, timeout=240):
    if args[0] == "ffmpeg":
        safe = []
        for arg in args:
            if arg == "-i":
                safe += ["-protocol_whitelist", "file,pipe"]
            safe.append(arg)
        args = safe
    try:
        return subprocess.run(
            args, check=True, capture_output=True, timeout=timeout,
            **({"creationflags": subprocess.CREATE_NO_WINDOW} if os.name == "nt" else {}),
        ).stdout
    except subprocess.TimeoutExpired:
        raise Problem("Pemrosesan terlalu lama. Gunakan file lebih singkat.") from None
    except subprocess.CalledProcessError:
        raise Problem(
            "File tidak dapat diproses. Pastikan format dan isinya valid."
        ) from None


def probe(path):
    return json.loads(
        run(
            [
                "ffprobe",
                "-protocol_whitelist",
                "file,pipe",
                "-v",
                "error",
                "-show_format",
                "-show_streams",
                "-of",
                "json",
                str(path),
            ],
            30,
        )
    )


def validate_media(path, kind):
    result = probe(path)
    if not any(s.get("codec_type") == kind for s in result.get("streams", [])):
        raise Problem("Stream media tidak valid: " + kind)
    return result


def process_local(kind, spec, files, progress):
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        raise Problem("FFmpeg/FFprobe belum tersedia.", 503)
    with tempfile.TemporaryDirectory(prefix="kisahnada-") as temp:
        root = Path(temp)
        inputs = []
        for i, (field, name, mime, data) in enumerate(files):
            p = root / f"input-{i}"
            p.write_bytes(data)
            inputs.append((field, mime, p))
        audio = next((p for f, m, p in inputs if f == "audio"), None)
        output = root / "output.wav"
        if kind in ("glow", "local-remix"):
            if audio is None:
                raise Problem("Pilih sumber audio.")
            info = validate_media(audio, "audio")
            if float(info.get("format", {}).get("duration", 0)) > 600:
                raise Problem("Audio maksimal 10 menit.")
            filters = "highpass=f=70,afftdn=nf=-25,equalizer=f=3000:t=q:w=1:g=2,acompressor=threshold=0.15:ratio=2.5:attack=15:release=120,loudnorm=I=-16:TP=-1.5:LRA=11"
            if kind == "local-remix":
                filters = {
                    "Late night": "lowpass=f=6000,aecho=0.8:0.5:65:0.25",
                    "Synth": "aecho=0.8:0.6:35|70:0.3|0.2,highpass=f=100",
                    "Rock": "equalizer=f=180:t=q:w=1:g=3,acompressor=threshold=0.1:ratio=4",
                    "Mellow": "lowpass=f=4500,atempo=0.92",
                    "Other": "anull",
                }.get(spec.get("remix"), "anull") + ",loudnorm=I=-16:TP=-1.5:LRA=11"
            progress("Memproses audio lokal dengan FFmpeg")
            run(
                [
                    "ffmpeg",
                    "-loglevel",
                    "error",
                    "-nostdin",
                    "-y",
                    "-i",
                    str(audio),
                    "-t",
                    "600",
                    "-af",
                    filters,
                    "-ar",
                    "44100",
                    str(output),
                ]
            )
            return (
                output.read_bytes(),
                "audio/wav",
                {"origin": "dsp", "type": "audio-tool", "lyrics": ""},
            )
        if kind != "slideshow":
            raise Problem("Alat lokal tidak ditemukan.", 404)
        media = [(m, p) for f, m, p in inputs if f == "media"]
        seconds = spec.get("duration", 4)
        if not 1 <= len(media) <= 10 or seconds not in (3, 4, 5, 6):
            raise Problem("Pilih 1–10 foto/video dan durasi scene 3–6 detik.")
        segments = []
        for i, (mime, p) in enumerate(media):
            progress(f"Merender scene {i+1}/{len(media)}")
            validate_media(p, "video")
            segment = root / f"scene-{i}.webm"
            args = ["ffmpeg", "-loglevel", "error", "-nostdin", "-y"]
            if mime.startswith("image/"):
                if p.read_bytes()[:100].lstrip().startswith(b"<"):
                    raise Problem("Renderer server menerima JPEG/PNG/WebP, bukan SVG.")
                args += ["-loop", "1"]
            else:
                args += ["-stream_loop", "-1"]
            vf = "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,setsar=1,fps=24"
            effect = spec.get("effect", "Ken Burns")
            if effect == "Ken Burns" and mime.startswith("image/"):
                vf += ",zoompan=z='1+0.0008*on':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s=1280x720:fps=24"
            if effect == "Fade":
                vf += f",fade=t=in:st=0:d=0.4,fade=t=out:st={seconds-.4}:d=0.4"
            if effect == "Slide":
                vf = "scale=1360:760:force_original_aspect_ratio=increase,crop=1280:720:x='40+30*sin(t)':y=20,setsar=1,fps=24"
            run(
                args
                + [
                    "-i",
                    str(p),
                    "-t",
                    str(seconds),
                    "-vf",
                    vf,
                    "-an",
                    "-c:v",
                    "libvpx-vp9",
                    "-deadline",
                    "realtime",
                    "-cpu-used",
                    "6",
                    "-threads",
                    "2",
                    "-pix_fmt",
                    "yuv420p",
                    str(segment),
                ]
            )
            segments.append(segment)
        listing = root / "concat.txt"
        listing.write_text("".join(f"file '{p.as_posix()}'\n" for p in segments))
        out = root / "result.webm"
        args = [
            "ffmpeg",
            "-loglevel",
            "error",
            "-nostdin",
            "-y",
            "-f",
            "concat",
            "-safe",
            "0",
            "-i",
            str(listing),
        ]
        if audio:
            validate_media(audio, "audio")
            args += [
                "-stream_loop",
                "-1",
                "-i",
                str(audio),
                "-map",
                "0:v:0",
                "-map",
                "1:a:0",
                "-c:a",
                "libopus",
                "-b:a",
                "128k",
            ]
        run(args + ["-t", str(seconds * len(media)), "-c:v", "copy", str(out)])
        return (
            out.read_bytes(),
            "video/webm",
            {"origin": "renderer", "type": "video", "lyrics": ""},
        )
