"""Explicit, authenticated desktop-only installation of the real singing runtime."""
import os
import subprocess
import sys
import threading
from pathlib import Path
from storage import Problem

ROOT = Path(__file__).resolve().parent


class SongInstaller:
    def __init__(self):
        self.lock = threading.Lock()
        self.state = {"state": "idle", "message": "Model nyanyian belum dipasang."}
        self.process = None

    @property
    def available(self):
        return sys.platform == "win32" and os.environ.get("KISAHNADA_DESKTOP") == "1"

    def status(self):
        from song_engine import singing_files_available
        with self.lock:
            if self.state["state"] != "running" and singing_files_available():
                return {"available": self.available, "state": "succeeded", "message": "Runtime dan model terpasang. Hasil nyanyian tetap perlu diuji dengan lagu pendek."}
            return {"available": self.available, **self.state}

    def start(self):
        if not self.available:
            raise Problem("Pemasang model otomatis tersedia pada paket Windows desktop.", 503)
        existing = self.status()
        if existing["state"] == "succeeded":
            return existing
        with self.lock:
            if self.state["state"] == "running":
                return {"available": True, **self.state}
            self.state = {"state": "running", "message": "Menyiapkan runtime CPU dan unduhan model resmi…"}
        threading.Thread(target=self.run, daemon=True).start()
        return self.status()

    def run(self):
        try:
            with self.lock:
                self.process = subprocess.Popen(
                    [str(Path(sys.executable).with_name("python.exe")), "-u", str(ROOT / "scripts/install-desktop-song.py")],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                    text=True, encoding="utf-8", errors="replace",
                    creationflags=subprocess.CREATE_NO_WINDOW,
                )
            for line in self.process.stdout:
                line = line.strip()
                if line:
                    home = Path(os.environ["KISAHNADA_DESKTOP_HOME"])
                    with (home / "song-install.log").open("a", encoding="utf-8") as log:
                        log.write(line + "\n")
                    with self.lock:
                        self.state["message"] = line[-500:]
            code = self.process.wait()
            from song_engine import singing_files_available
            with self.lock:
                self.state = {
                    "state": "succeeded" if code == 0 and singing_files_available() else "failed",
                    "message": "Model terverifikasi. Mulai lagu pendek 30 detik; hasil perlu didengarkan." if code == 0 and singing_files_available() else "Pemasangan belum berhasil. Periksa koneksi internet, ruang disk dan log pemasangan; klik Coba lagi secara manual.",
                }
        except Exception:
            with self.lock:
                self.state = {"state": "failed", "message": "Pemasang tidak dapat dijalankan. Buka folder data untuk log."}


INSTALLER = SongInstaller()
